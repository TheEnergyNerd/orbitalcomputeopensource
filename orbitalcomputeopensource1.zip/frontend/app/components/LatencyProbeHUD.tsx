"use client";

// Component stubbed out - Cesium removed, using Three.js OrbitalScene instead
export default function LatencyProbeHUD() {
  return null;
}
