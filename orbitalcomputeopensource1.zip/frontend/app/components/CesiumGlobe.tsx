"use client";

// Component stubbed out - Cesium removed, using Three.js OrbitalScene instead
export default function CesiumGlobe() {
  return null;
}
