import { 
  YearParams, 
  YearlyBreakdown, 
  SLAConfig, 
  GpuHourPricing, 
  TokenPricing, 
  WorkloadType,
  GroundScenario,
  GroundScenarioConfig,
  SMRToggleParams
} from './types';
import { calculateCongestion } from './congestion';
import { computeEdgeInferenceCosts } from './edgeInference';
import { 
  computeSatelliteHybridCost,
  DEFAULT_CONFIG,
  PHYSICS_CONSTANTS,
  STARLINK_EMPIRICAL,
  WORKLOAD_PROFILES,
  DEFAULT_INTERCONNECT,
  DEFAULT_FUSION_PARAMS,
  DEFAULT_POWER_SCALING,
  calculateScaledMass,
  SpaceFusionParams
} from './orbitalPhysics';
import { calculateRegionalGroundCost, GroundCostResult, getGlobalDemandPflops } from './ground_supply_model';
import { generateGroundSupplyTrajectory, calculateConstraintFromSupply, stepGroundSupply, INITIAL_SUPPLY_STATE, GroundSupplyState } from './ground_queue_model';
import { calculateGroundConstraintPenalties } from './ground_constraint_penalties';
import { calculateBuildoutConstraints, BuildoutState, BuildoutResult } from './ground_buildout';
import { stepMobilizationState, DEFAULT_MOBILIZATION_PARAMS, MobilizationScenarioParams, MobilizationState } from './ground_ramping_mobilization';
import { ComputeEfficiency, getDefaultComputeEfficiency } from './compute_efficiency';
import { assertCostAccounting, validateTrajectoryCostAccounting } from './cost_accounting';
import { validateGflopsPerWatt, COMPUTE_UNITS } from './units';
import { sanitizeFinite, sanitizeSeries } from '../utils/sanitize';
import { calculateNetworkingScaling } from './networking_scaling';
import { stepLaunchLearning, LaunchLearningState } from './launch_learning';
import { calculateSystemSpecificPower } from './specific_power';
import { calculateThermalSystem, DEFAULT_THERMAL_PARAMS } from './thermal_physics';
import { designConstellation, SATELLITE_CONSTRAINTS } from './constellation_sizing';
import { getStaticParams } from './modes/static';
import { getDemandProjection, getFacilityLoadGW, getDemandNewGW, getITLoadGW } from './trajectory';

const CONSTANTS = {
  HOURS_PER_YEAR: 8760,
  GROUND_HARDWARE_COST_PFLOP_2025: 15000, 
  GROUND_HARDWARE_LIFETIME: 3,
  MIN_DELIVERED_GFLOPS_PER_W: 20, // Minimum delivered efficiency to prevent validation errors from severe thermal constraints
};

export const DEFAULT_SMR_PARAMS: SMRToggleParams = {
  enabled: false,
  smrDeploymentStartYear: 2030,
  smrRampUpYears: 5,
  electricityCostWithSMR: 50,
  gridConstraintRelief: 0.90,
  coolingConstraintRelief: 0.50,
  waterConstraintRelief: 0.30,
  landConstraintRelief: 0.60,
  smrCapexPremium: 1.15,
};

export const GROUND_SCENARIOS: Record<GroundScenario, GroundScenarioConfig> = {
  unconstrained: {
    name: 'Unconstrained',
    description: 'SMRs + geographic arbitrage solve power/water constraints',
    constraintCap: 1.5,
    gridGrowthRate: 0.02,
    coolingGrowthRate: 0.01,
    waterGrowthRate: 0.01,
    landGrowthRate: 0.01,
  },
  moderate: {
    name: 'Moderate',
    description: 'Partial adaptation, some persistent friction',
    constraintCap: 3.0,
    gridGrowthRate: 0.03,
    coolingGrowthRate: 0.02,
    waterGrowthRate: 0.015,
    landGrowthRate: 0.015,
  },
  constrained: {
    name: 'Constrained (Aggressive Baseline)',
    description: 'Accelerated AI demand pressure on infrastructure',
    constraintCap: null,
    gridGrowthRate: 0.07,      // 7%/year (was 5%)
    coolingGrowthRate: 0.04,   // 4%/year (was 3%)
    waterGrowthRate: 0.03,     // 3%/year (was 2%)
    landGrowthRate: 0.03,      // 3%/year (was 2%)
  },
  severe: {
    name: 'Severe',
    description: 'Constrained + carbon tax + water scarcity crisis',
    constraintCap: null,
    gridGrowthRate: 0.09,      // 9%/year (was 7%)
    coolingGrowthRate: 0.06,   // 6%/year (was 5%)
    waterGrowthRate: 0.05,     // 5%/year (was 4%)
    landGrowthRate: 0.04,      // 4%/year (was 3%)
  },
};

function calculateGroundConstraint(
  year: number,
  scenarioKey: GroundScenario,
  enabled: boolean
): { multiplier: number, breakdown: { grid: number, cooling: number, water: number, land: number } } {
  if (!enabled) return { multiplier: 1.0, breakdown: { grid: 1.0, cooling: 1.0, water: 1.0, land: 1.0 } };
  
  const scenario = GROUND_SCENARIOS[scenarioKey];
  const yearsFromBase = Math.max(0, year - 2025);
  
  const grid = Math.pow(1 + scenario.gridGrowthRate, yearsFromBase);
  const cooling = Math.pow(1 + scenario.coolingGrowthRate, yearsFromBase);
  const water = Math.pow(1 + scenario.waterGrowthRate, yearsFromBase);
  const land = Math.pow(1 + scenario.landGrowthRate, yearsFromBase);
  
  let multiplier = grid * cooling * water * land;
  if (scenario.constraintCap !== null) {
    multiplier = Math.min(multiplier, scenario.constraintCap);
  }
  
  return {
    multiplier,
    breakdown: { grid, cooling, water, land }
  };
}

function validateComputeEfficiency(
  gflopsPerWatt: number,
  level: 'chip' | 'system' | 'datacenter' = 'system'
): { valid: boolean; warning?: string } {
  const ranges = {
    chip: { min: 100, max: 10000 },       // Chip-level (up to 10k for future FP8)
    system: { min: 30, max: 5000 },       // System-level  
    datacenter: { min: 10, max: 1000 },   // Full datacenter
  };
  
  const range = ranges[level];
  if (gflopsPerWatt < range.min || gflopsPerWatt > range.max) {
    return {
      valid: false,
      warning: `gflopsPerWatt=${gflopsPerWatt.toFixed(0)} outside expected range for ${level} level (${range.min}-${range.max})`,
    };
  }
  return { valid: true };
}

const SLA_TIERS: Record<string, SLAConfig> = {
  'basic': {
    availabilityTarget: 0.99,
    maxLatencyToGroundMs: 100,
    minBandwidthGbps: 1,
    maxRecoveryTimeMinutes: 60,
    creditPerViolationPct: 10,
  },
  'standard': {
    availabilityTarget: 0.999,
    maxLatencyToGroundMs: 50,
    minBandwidthGbps: 10,
    maxRecoveryTimeMinutes: 15,
    creditPerViolationPct: 25,
  },
  'premium': {
    availabilityTarget: 0.9999,
    maxLatencyToGroundMs: 20,
    minBandwidthGbps: 100,
    maxRecoveryTimeMinutes: 5,
    creditPerViolationPct: 50,
  },
};

function applyStaticFreeze(params: YearParams): YearParams {
  if (!params.isStaticMode) return params;
  
  return {
    ...params,
    launchCostKg: 1500,
    specificPowerWKg: 36.5,
    groundEffectiveGflopsPerW_2025: 30, 
    orbitEffectiveGflopsPerW_2025: 25, 
    groundConstraintsEnabled: true,
    powerGridMultiplier: 1.0,
    coolingMultiplier: 1.0,
    waterScarcityEnabled: false,
    landScarcityEnabled: false,
    deployableArea2025M2: 75,
    deployableArea2040M2: 75,
  };
}

// Cache for monotonicity check
let prevLaunchCostCache: Map<number, number> = new Map();

export function getLaunchCostPerKg(year: number, base2025: number): number {
  if (year <= 2025) {
    prevLaunchCostCache.set(year, base2025);
    return base2025;
  }
  
  const COMMERCIAL_MARKUP = 2.5;
  const INSURANCE_PCT = 0.05;
  const INTEGRATION_COST_PER_LAUNCH = 500000; // $500k per launch
  const ASSUMED_PAYLOAD_KG = 100000; // 100t payload for integration cost amortization
  
  // Internal SpaceX cost trajectory (marginal cost)
  // Normalize base2025 to internal cost scale
  const internalBase2025 = base2025 / (COMMERCIAL_MARKUP * (1 + INSURANCE_PCT)) - (INTEGRATION_COST_PER_LAUNCH / ASSUMED_PAYLOAD_KG);
  const normalizedBase = Math.max(internalBase2025, 600); // Ensure reasonable internal cost
  
  const internalWaypoints: [number, number][] = [
    [2025, normalizedBase],
    [2026, 800],
    [2027, 400],
    [2028, 200],
    [2030, 75],
    [2035, 30],
    [2040, 20],
    [2045, 15],
    [2050, 10]   // Internal cost floor
  ];
  
  // Find internal cost
  let internalCostPerKg = normalizedBase;
  for (let i = 0; i < internalWaypoints.length - 1; i++) {
    const [y1, c1] = internalWaypoints[i];
    const [y2, c2] = internalWaypoints[i + 1];
    if (year >= y1 && year <= y2) {
      const t = (year - y1) / (y2 - y1);
      internalCostPerKg = c1 * Math.pow(c2 / c1, t);
      break;
    }
  }
  if (year > internalWaypoints[internalWaypoints.length - 1][0]) {
    internalCostPerKg = internalWaypoints[internalWaypoints.length - 1][1];
  }
  
  // Apply commercial markup
  const withMarkup = internalCostPerKg * COMMERCIAL_MARKUP;
  const withInsurance = withMarkup * (1 + INSURANCE_PCT);
  const integrationPerKg = INTEGRATION_COST_PER_LAUNCH / ASSUMED_PAYLOAD_KG;
  const commercialCostPerKg = withInsurance + integrationPerKg;
  
  // Floor: commercial cost never below $30/kg (realistic minimum)
  let result = Math.max(commercialCostPerKg, 30);
  
  // Enforce monotonicity: never increase from previous year
  const prevYear = year - 1;
  const prevCost = prevLaunchCostCache.get(prevYear);
  if (prevCost !== undefined && result > prevCost) {
    result = prevCost; // Clamp to previous year's cost
  }
  
  prevLaunchCostCache.set(year, result);
  return result;
}

function calculateTokenPricing(
  costPerPflopYear: number,
  modelConfig: {
    params: number;
    precision: 'fp16' | 'fp8' | 'int8';
  }
): TokenPricing {
  const baseFLOPS = modelConfig.params * 2;
  const precisionMultiplier = {
    'fp16': 1.0,
    'fp8': 0.5,
    'int8': 0.5,
  }[modelConfig.precision];
  const flopsPerToken = baseFLOPS * precisionMultiplier;
  const secondsPerYear = 8760 * 3600;
  const flopsPerPflopYear = 1e15 * secondsPerYear;
  const tokensPerPflopYear = flopsPerPflopYear / flopsPerToken;
  const costPerToken = costPerPflopYear / tokensPerPflopYear;
  
  return {
    modelParams: modelConfig.params,
    precision: modelConfig.precision,
    flopsPerToken,
    tokensPerPflopYear,
    costPerToken,
    costPer1kTokens: costPerToken * 1000,
    costPer1mTokens: costPerToken * 1e6,
  };
}

function calculateGpuHourPricing(
  costPerPflopYear: number,
  params: {
    pflopsPerGpu: number;
    utilizationTarget: number;
    operatorMarginPct: number;
    sla: SLAConfig;
    location: 'orbital' | 'ground';
  },
  costBreakdown?: {  // Optional breakdown to derive power/cooling/interconnect
    power?: number;
    thermal?: number;
    interconnect?: number;
    ops?: number;
    compute?: number;
    site?: number;
    [key: string]: number | undefined;
  }
): GpuHourPricing {
  const hoursPerYear = 8760;
  const costPerGpuYear = costPerPflopYear * params.pflopsPerGpu;
  const effectiveHours = hoursPerYear * params.utilizationTarget;
  const basePerHour = costPerGpuYear / effectiveHours;
  
  // Derive breakdown from cost components if provided
  let powerPerHour = 0;
  let coolingPerHour = 0;
  let interconnectPerHour = 0;
  let opsPerHour = 0;
  let computePerHour = basePerHour;
  
  if (costBreakdown) {
    const totalBase = (costBreakdown.power || 0) + (costBreakdown.thermal || 0) + 
                      (costBreakdown.interconnect || 0) + (costBreakdown.ops || 0) + 
                      (costBreakdown.compute || 0);
    if (totalBase > 0) {
      // Scale breakdown components to GPU-hour
      const scale = costPerGpuYear / (totalBase * params.pflopsPerGpu) / effectiveHours;
      powerPerHour = (costBreakdown.power || 0) * params.pflopsPerGpu * scale;
      coolingPerHour = (costBreakdown.thermal || 0) * params.pflopsPerGpu * scale;
      interconnectPerHour = (costBreakdown.interconnect || 0) * params.pflopsPerGpu * scale;
      opsPerHour = (costBreakdown.ops || 0) * params.pflopsPerGpu * scale;
      computePerHour = (costBreakdown.compute || 0) * params.pflopsPerGpu * scale;
    }
  } else {
    // Fallback: estimate ops as 5% of base
    opsPerHour = basePerHour * 0.05;
  }
  
  const nines = -Math.log10(1 - params.sla.availabilityTarget);
  const sparesRatio = 1 + 0.05 * nines;
  const sparesPerHour = computePerHour * (sparesRatio - 1);
  const violationProb = 1 - params.sla.availabilityTarget;
  const expectedCreditPerHour = violationProb * params.sla.creditPerViolationPct / 100;
  const slaRiskBuffer = basePerHour * expectedCreditPerHour * 2;
  const totalCostPerHour = computePerHour + powerPerHour + coolingPerHour + interconnectPerHour + opsPerHour + sparesPerHour + slaRiskBuffer;
  const margin = totalCostPerHour * params.operatorMarginPct;
  const pricePerGpuHour = totalCostPerHour + margin;
  
  return {
    gpuType: 'H100-equivalent',
    location: params.location,
    sla: params.sla,
    pricePerGpuHour,
    costBreakdown: {
      hardwareAmortization: computePerHour,
      power: powerPerHour,
      cooling: coolingPerHour,
      interconnect: interconnectPerHour,
      operations: opsPerHour,
      spares: sparesPerHour,
      slaRiskBuffer,
      margin,
    },
    effectiveUtilization: params.utilizationTarget,
    sparesRatio,
  };
}

export interface ComputeUnits {
  pflopDefinition: 'fp64' | 'fp32' | 'bf16' | 'fp16' | 'fp8';
  sustainedVsPeak: 'sustained' | 'peak';
  gflopsPerWattLevel: 'chip' | 'board' | 'node' | 'system';
  includesNetworkingOverhead: boolean;
}

export const MODEL_UNITS: ComputeUnits = {
  pflopDefinition: 'fp16',              // H100-class FP16
  sustainedVsPeak: 'sustained',         // Not peak, actual delivered
  gflopsPerWattLevel: 'system',         // Including power conversion, cooling
  includesNetworkingOverhead: false,    // Networking separate
};

function assertComputePowerConsistency(
  gflopsPerWatt: number,
  computePowerKw: number,
  effectivePflops: number,
  units: ComputeUnits = MODEL_UNITS
): { valid: boolean; ratio: number; expectedKw: number; discrepancy: number } {
  // 1 PFLOP = 1e6 GFLOPS
  // Power (W) = GFLOPS / (GFLOPS/W) = (effectivePflops * 1e6) / gflopsPerWatt
  // Power (kW) = Power (W) / 1000
  // gflopsPerWatt is at system level (includes power conversion, cooling)
  const expectedKw = (effectivePflops * 1e6) / gflopsPerWatt / 1000;
  const discrepancy = computePowerKw / expectedKw;
  
  return {
    valid: discrepancy > 0.5 && discrepancy < 2.0,  // Within 2x
    ratio: discrepancy,
    expectedKw,
    discrepancy,
  };
}

const BASE_SITE_2025 = 1500; // Base site cost in 2025 ($/PFLOP-year)

function calculateGroundTotal(
  year: number,
  params: YearParams,
  energyCostBase: number,
  hardwareCostBase: number,
  isStaticMode: boolean,
  effectiveScenario: GroundScenarioConfig,
  latencyPenalty: number = 1.0,
  smrParams?: SMRToggleParams,
  firstCapYear?: number | null,
  actualEnergyCostPerPflopYear?: number,
  actualElectricityPricePerMwh?: number
) {
  const yearsFromBase = Math.max(0, year - 2025);
  
  let siteCostBase = BASE_SITE_2025;

  const enabled = params.groundConstraintsEnabled && !params.isStaticMode;
  
  // SMR Toggle logic
  const smrEnabled = smrParams?.enabled && year >= (smrParams.smrDeploymentStartYear || 2030);
  let smrRampFactor = 0;
  let constraintRelief = { grid: 0, cooling: 0, water: 0, land: 0 };
  
  if (smrEnabled && smrParams) {
    const yearsActive = year - smrParams.smrDeploymentStartYear;
    smrRampFactor = Math.min(1, yearsActive / smrParams.smrRampUpYears);
    
    // Apply constraint relief
    constraintRelief = {
      grid: smrParams.gridConstraintRelief * smrRampFactor,
      cooling: smrParams.coolingConstraintRelief * smrRampFactor,
      water: smrParams.waterConstraintRelief * smrRampFactor,
      land: smrParams.landConstraintRelief * smrRampFactor,
    };
    
    siteCostBase = BASE_SITE_2025 * (1 + (smrParams.smrCapexPremium - 1) * smrRampFactor);
  }

  // REFACTORED: Split energy (no multiplier) vs capacity/delivery premium (with multiplier)
  // 
  // Energy cost: Raw electricity price * kWh (NO constraint multiplier)
  // - Represents actual market electricity price
  // - Grows with electricity price trajectory, not infrastructure scarcity
  const energyCost = actualEnergyCostPerPflopYear ?? energyCostBase;
  const effectiveElectricityPrice = actualElectricityPricePerMwh ?? 120;

  if (!enabled) {
    // No constraints: all costs at base, no premium
    const total = (energyCost + siteCostBase + hardwareCostBase) * latencyPenalty;
    return {
      energyCost: energyCost * latencyPenalty,
      siteCost: siteCostBase * latencyPenalty,
      hardwareCost: hardwareCostBase * latencyPenalty,
      capacityDeliveryPremium: 0, // No premium when constraints disabled
      timeToEnergizePenalty: 0, // No queue delay when constraints disabled
      totalCostPerPflopYear: total,
      constraintMultiplier: 1.0,
      breakdown: { 
        grid: 1.0, 
        cooling: 1.0, 
        water: 1.0, 
        land: 1.0, 
        energyMultiplier: 1.0, 
        siteMultiplier: 1.0,
        capacityDeliveryMultiplier: 1.0,
      },
      smrEnabled,
      smrRampFactor,
      effectiveElectricityCost: effectiveElectricityPrice,
      constraintRelief
    };
  }

  // CRITICAL FIX: Calculate constraint premium as ADDITIVE term, not multiplier
  // Calculate constraint severity from supply/demand dynamics
  const rawConstraint = Math.pow(1.47, yearsFromBase);
  let constraintSeverity = Math.sqrt(rawConstraint - 1); // Severity factor (0..inf)
  
  if (smrEnabled && smrParams) {
    const avgRelief = (constraintRelief.grid + constraintRelief.cooling + constraintRelief.water + constraintRelief.land) / 4;
    constraintSeverity = constraintSeverity * (1 - avgRelief);
  }
  
  // GROUND COST ACCOUNTING: Explicit separation of components (ADDITIVE ONLY)
  // 
  // 1. siteCapexAmortPerPflopYear: Pure amortized capex
  //    - Buildings + power delivery inside site + cooling plant
  //    - Base cost, NOT affected by constraint
  const siteCapexAmortPerPflopYear = siteCostBase;
  
  // 2. capacityDeliveryPremiumPerPflopYear: Scarcity price for firm MW at right place/time
  //    - Independent ADDITIVE component, derived from constraint severity
  //    - Includes: land acquisition premium, cooling infrastructure premium, grid connection premium, water rights
  //    - Formula: premium = base * severity (additive, not multiplicative)
  const capacityDeliveryPremiumPerPflopYear = siteCostBase * constraintSeverity;
  
  // 3. timeToEnergizePenaltyPerPflopYear: Financing cost of waiting (WACC + delay years)
  //    - Independent component, derived from queue delay
  //    - Uses WACC and delay years to calculate opportunity cost
  const TARGET_WAIT_YEARS = 2;
  const estimatedWaitYears = yearsFromBase > 5 ? Math.min(5, yearsFromBase * 0.3) : 0;
  const WACC = 0.10; // 10% WACC
  const waitPenaltyFactor = estimatedWaitYears > TARGET_WAIT_YEARS 
    ? 1 + WACC * (estimatedWaitYears - TARGET_WAIT_YEARS) // WACC per year over target
    : 1.0;
  const timeToEnergizePenaltyPerPflopYear = siteCostBase * (waitPenaltyFactor - 1);
  
  // CRITICAL: Remove double counting
  // Do NOT include timeToEnergizePenalty in headline cost used for crossover
  // (capacity gating in market share already accounts for backlog)
  // Compute both base and effective costs:
  const siteCostPerPflopYear_base = siteCapexAmortPerPflopYear + capacityDeliveryPremiumPerPflopYear;
  const siteCostPerPflopYear_effective = siteCapexAmortPerPflopYear + timeToEnergizePenaltyPerPflopYear + capacityDeliveryPremiumPerPflopYear;
  
  // Validation: siteCost_effective must equal sum of components
  const siteCostCheck = Math.abs(siteCostPerPflopYear_effective - (siteCapexAmortPerPflopYear + timeToEnergizePenaltyPerPflopYear + capacityDeliveryPremiumPerPflopYear));
  if (siteCostCheck > 0.01) {
    throw new Error(`Site cost accounting error: siteCost_effective=${siteCostPerPflopYear_effective} != sum(components)=${siteCapexAmortPerPflopYear + timeToEnergizePenaltyPerPflopYear + capacityDeliveryPremiumPerPflopYear}, diff=${siteCostCheck}`);
  }
  
  const hardware = hardwareCostBase;

  // Headline cost for crossover: base only (excludes delay penalty, which is handled via capacity gating)
  const total = (energyCost + siteCostPerPflopYear_base + hardware) * latencyPenalty;
  // Effective/all-in cost: includes delay penalty (for reference/debug)
  const totalEffective = (energyCost + siteCostPerPflopYear_effective + hardware) * latencyPenalty;
  
  return {
    energyCost: energyCost * latencyPenalty, // Energy NOT multiplied by constraint
    siteCost: siteCostPerPflopYear_base * latencyPenalty, // Site = base components (excludes delay penalty)
    hardwareCost: hardware * latencyPenalty,
    siteCapexAmortPerPflopYear: siteCapexAmortPerPflopYear * latencyPenalty, // Explicit: pure capex amortization
    capacityDeliveryPremium: capacityDeliveryPremiumPerPflopYear * latencyPenalty, // Explicit: scarcity premium
    timeToEnergizePenalty: timeToEnergizePenaltyPerPflopYear * latencyPenalty, // Explicit: WACC-based penalty (not in headline cost)
    totalCostPerPflopYear: total, // Base cost (excludes delay penalty - handled via capacity gating)
    totalCostPerPflopYearEffective: totalEffective, // Effective/all-in cost (includes delay penalty)
    constraintMultiplier: 1.0, // NOT APPLIED - kept for backward compat only
    breakdown: { 
      grid: 1.0, // Not applied
      cooling: 1.0, // Not applied
      water: 1.0, // Not applied
      land: 1.0, // Not applied
      energyMultiplier: 1.0, // Never applied
      siteMultiplier: 1.0, // Not applied
      capacityDeliveryMultiplier: 1.0, // Not applied
    },
    constraints: {
      method: 'adders',
      capacityDeliveryPremium: capacityDeliveryPremiumPerPflopYear * latencyPenalty,
      delayPenalty: timeToEnergizePenaltyPerPflopYear * latencyPenalty,
      appliedMultipliers: {
        constraintMultiplierUsed: false,
        energyMultiplierUsed: false,
        siteMultiplierUsed: false,
      },
      debug: {
        doubleCountCheck: {
          mode: 'adders',
          multiplierApplied: false,
          addersApplied: (capacityDeliveryPremiumPerPflopYear > 0) || (timeToEnergizePenaltyPerPflopYear > 0),
          invariantOk: true,
          notes: 'calculateGroundTotal uses adders only (capacityDeliveryPremium + timeToEnergizePenalty)',
        },
      },
    },
    smrEnabled,
    smrRampFactor,
    effectiveElectricityCost: effectiveElectricityPrice,
    constraintRelief,
  };
}

export function computePhysicsCost(rawParams: YearParams, firstCapYear: number | null = null): YearlyBreakdown {
  const params = applyStaticFreeze(rawParams);
  
  const {
    year,
    isStaticMode,
    launchCostKg: baseLaunchCost,
    specificPowerWKg: trajSpecificPower,
    groundEffectiveGflopsPerW_2025: rawGroundEffectiveGflopsPerW_2025,
    orbitEffectiveGflopsPerW_2025: rawOrbitEffectiveGflopsPerW_2025,
    pueGround,
    pueOrbital,
    capacityFactorGround,
    targetGW,
    satellitePowerKW,
    groundConstraintsEnabled,
    powerGridMultiplier,
    coolingMultiplier,
    waterScarcityEnabled,
    landScarcityEnabled,
    spaceTrafficEnabled,
    orbitalAltitude,
    useRadHardChips,
    sunFraction,
    groundScenario,
    smrMitigationEnabled,
    workloadType,
    elonScenarioEnabled,
    globalLatencyRequirementEnabled,
    spaceManufacturingEnabled,
    aiWinterEnabled
  } = params;
  
  // CRITICAL FIX: Handle parameter name migration
  // Old names: flopsPerWattGround, flopsPerWattOrbital (DEPRECATED - delete conversion logic)
  // New names: groundEffectiveGflopsPerW_2025, orbitEffectiveGflopsPerW_2025
  // Parameters are ALREADY in GFLOPS/W (not FLOPS/W) - no conversion needed
  const actualGroundInput = rawGroundEffectiveGflopsPerW_2025 ?? (params as any).gflopsPerWattGround2025 ?? (params as any).flopsPerWattGround;
  const actualOrbitInput = rawOrbitEffectiveGflopsPerW_2025 ?? (params as any).gflopsPerWattOrbital2025 ?? (params as any).flopsPerWattOrbital;

  // CANONICAL COMPUTE EFFICIENCY: Single source of truth for GFLOPS/W
  // Parameter is interpreted as GFLOPS/W (not FLOPS/W) - no 1e9/1e12 conversions
  let groundEfficiencyResult;
  let orbitalEfficiencyResult;
  
  // Ground: Use canonical ComputeEfficiency function
  // CRITICAL FIX: Parameter is ALREADY in GFLOPS/W (not FLOPS/W)
  // No unit conversion - treat input as effective GFLOPS/W directly
  if (!actualGroundInput || !isFinite(actualGroundInput) || actualGroundInput <= 0) {
    // Invalid input - use default
    groundEfficiencyResult = getDefaultComputeEfficiency('NVIDIA H100 SXM', year, 'FP16');
  } else {
    // Input is effective GFLOPS/W - derive chip peak assuming standard factors
    // effective = chipPeak * utilization / systemOverhead
    // So: chipPeak = effective * systemOverhead / utilization
    const systemOverheadFactor = 1.18; // PUE 1.18 equivalent
    const utilizationFactor = 0.70;
    const chipPeakGflopsPerW = actualGroundInput * systemOverheadFactor / utilizationFactor;
    
    // FAIL-FAST INVARIANT: Chip peak must be in realistic range [1, 20000] GFLOPS/W
    if (chipPeakGflopsPerW < 1 || chipPeakGflopsPerW > 20000) {
      throw new Error(
        `GROUND COMPUTE EFFICIENCY UNIT MISMATCH: ` +
        `chipPeakGflopsPerW=${chipPeakGflopsPerW.toFixed(2)} is outside valid range [1, 20000] GFLOPS/W. ` +
        `Input: actualGroundInput=${actualGroundInput}, ` +
        `This suggests a units error. Expected range: 30-5000 GFLOPS/W for system-level efficiency.`
      );
    }
    
    groundEfficiencyResult = ComputeEfficiency({
      chipPeakGflopsPerW,
      utilizationFactor,
      systemOverheadFactor,
    });
    
    // FAIL-FAST INVARIANT: Effective GFLOPS/W must be in realistic range [1, 5000] GFLOPS/W
    if (groundEfficiencyResult.effectiveGflopsPerW < 1 || groundEfficiencyResult.effectiveGflopsPerW > 5000) {
      throw new Error(
        `GROUND COMPUTE EFFICIENCY OUT OF RANGE: ` +
        `effectiveGflopsPerW=${groundEfficiencyResult.effectiveGflopsPerW.toFixed(2)} is outside valid range [1, 5000] GFLOPS/W. ` +
        `Input: actualGroundInput=${actualGroundInput}, ` +
        `chipPeakGflopsPerW=${chipPeakGflopsPerW.toFixed(2)}. ` +
        `This suggests a units error or invalid input.`
      );
    }
  }
  
  // Orbital: Same logic - parameter is ALREADY in GFLOPS/W (not FLOPS/W)
  // No unit conversion - treat input as effective GFLOPS/W directly
  if (!actualOrbitInput || !isFinite(actualOrbitInput) || actualOrbitInput <= 0) {
    // Invalid input - use default
    orbitalEfficiencyResult = getDefaultComputeEfficiency('H100-equivalent (rad-tolerant)', year, 'FP16');
  } else {
    // Input is effective GFLOPS/W - derive chip peak
    const systemOverheadFactor = 1.18;
    const utilizationFactor = 0.65;
    const chipPeakGflopsPerW = actualOrbitInput * systemOverheadFactor / utilizationFactor;
    
    // FAIL-FAST INVARIANT: Chip peak must be in realistic range [1, 20000] GFLOPS/W
    if (chipPeakGflopsPerW < 1 || chipPeakGflopsPerW > 20000) {
      throw new Error(
        `ORBITAL COMPUTE EFFICIENCY UNIT MISMATCH: ` +
        `chipPeakGflopsPerW=${chipPeakGflopsPerW.toFixed(2)} is outside valid range [1, 20000] GFLOPS/W. ` +
        `Input: actualOrbitInput=${actualOrbitInput}, ` +
        `This suggests a units error. Expected range: 25-4000 GFLOPS/W for system-level efficiency.`
      );
    }
    
    orbitalEfficiencyResult = ComputeEfficiency({
      chipPeakGflopsPerW,
      utilizationFactor,
      systemOverheadFactor,
    });
    
    // FAIL-FAST INVARIANT: Effective GFLOPS/W must be in realistic range [1, 5000] GFLOPS/W
    if (orbitalEfficiencyResult.effectiveGflopsPerW < 1 || orbitalEfficiencyResult.effectiveGflopsPerW > 5000) {
      throw new Error(
        `ORBITAL COMPUTE EFFICIENCY OUT OF RANGE: ` +
        `effectiveGflopsPerW=${orbitalEfficiencyResult.effectiveGflopsPerW.toFixed(2)} is outside valid range [1, 5000] GFLOPS/W. ` +
        `Input: actualOrbitInput=${actualOrbitInput}, ` +
        `chipPeakGflopsPerW=${chipPeakGflopsPerW.toFixed(2)}. ` +
        `This suggests a units error or invalid input.`
      );
    }
  }
  
  // HARD ASSERT: Ground efficiency must always be populated and finite
  if (!groundEfficiencyResult || !isFinite(groundEfficiencyResult.effectiveGflopsPerW) || groundEfficiencyResult.effectiveGflopsPerW <= 0) {
    throw new Error(
      `CRITICAL: Ground compute efficiency is invalid. ` +
      `actualGroundInput=${actualGroundInput}, ` +
      `rawGroundEffectiveGflopsPerW_2025=${rawGroundEffectiveGflopsPerW_2025}, ` +
      `gflopsPerWattGround2025=${(params as any).gflopsPerWattGround2025}, ` +
      `groundEfficiencyResult=${JSON.stringify(groundEfficiencyResult)}`
    );
  }
  
  // CRITICAL FIX: Standardize compute-efficiency level definitions
  // Standard definitions:
  // - peakGflopsPerWatt: chip peak (no utilization, no overhead, no derates)
  // - systemEffectiveGflopsPerWatt: peak * utilization / systemOverheadFactor (SYSTEM-LEVEL EFFECTIVE)
  // - deliveredGflopsPerWatt: systemEffective * thermalCapFactor * radiationDerate * availability
  
  // Ground: systemEffective only (no delivery derates)
  const groundEffectiveGflopsPerW = validateGflopsPerWatt(
    groundEfficiencyResult.effectiveGflopsPerW,
    'ground efficiency calculation'
  );
  
  // Orbital: Track all three levels
  const orbitPeakGflopsPerWatt = orbitalEfficiencyResult.debug.chipPeakGflopsPerW;
  const orbitSystemEffectiveGflopsPerWatt = validateGflopsPerWatt(
    orbitalEfficiencyResult.effectiveGflopsPerW,
    'orbital systemEffective efficiency calculation'
  );
  
  // NOTE: deliveredGflopsPerWatt will be calculated after thermal system is computed
  // It will be: systemEffective * thermalCapFactor * radiationDerate * availability

  // AI Winter: Constraints grow 50% slower
  const effectiveGroundScenario = aiWinterEnabled && year >= 2028 ? {
    ...GROUND_SCENARIOS[groundScenario],
    gridGrowthRate: GROUND_SCENARIOS[groundScenario].gridGrowthRate * 0.5,
    coolingGrowthRate: GROUND_SCENARIOS[groundScenario].coolingGrowthRate * 0.5,
    waterGrowthRate: GROUND_SCENARIOS[groundScenario].waterGrowthRate * 0.5,
    landGrowthRate: GROUND_SCENARIOS[groundScenario].landGrowthRate * 0.5,
  } : GROUND_SCENARIOS[groundScenario];

  // Elon Scenario: Discounts
  const launchDiscount = elonScenarioEnabled ? 0.50 : 1.0;
  const powerDiscount = elonScenarioEnabled ? 0.70 : 1.0;
  const networkingDiscount = elonScenarioEnabled ? 0.10 : 1.0;
  const operatorMargin = elonScenarioEnabled ? 0.05 : 0.20;

  // Global Latency: 3x ground overprovisioning penalty
  const groundLatencyPenalty = (globalLatencyRequirementEnabled && year >= 2028) ? 3.0 : 1.0;

  // Space Manufacturing: Mass reduction
  let massMultiplier = 1.0;
  if (spaceManufacturingEnabled && year >= 2032) {
    const yearsSinceStart = year - 2032;
    const ramp = Math.min(1.0, yearsSinceStart / 5);
    massMultiplier = 1.0 - (0.60 * ramp);
  }

  // EMERGENCY FIX: Use simple fixed 2025 base values
  // These are the known-correct values from the emergency fix
  // Don't try to calculate from flopsPerWatt - just use these constants
  const BASE_ENERGY_2025 = 581;      // $/PFLOP-year (fixed 2025 base)
  const BASE_SITE_2025 = 1500;      // $/PFLOP-year (fixed 2025 base)
  const ENERGY_COST_BASE_2025 = BASE_ENERGY_2025; // Use fixed base, not calculated
  
  // For reference/display (not used in constraint calculation)
  const BASE_ELECTRICITY_PRICE_2025 = 120; // $/MWh (2025 baseline)
  let groundElectricityPricePerMwh = BASE_ELECTRICITY_PRICE_2025; 
  if (!params.isStaticMode) {
    groundElectricityPricePerMwh *= Math.pow(1.02, year - 2025);
  }
  
  const effectivePueGround = pueGround + ((year - 2025) * 0.01);
  // Convert GFLOPS/W to power: 1 PFLOP = 1e6 GFLOPS, so power (W) = (1e6 GFLOPS) / (GFLOPS/W)
  const groundEnergyMWhPerPflopYear = (8760 * 1e6 / groundEffectiveGflopsPerW) * effectivePueGround / 1e6;
  const groundEnergyCostPerPflopYear = groundEnergyMWhPerPflopYear * (groundElectricityPricePerMwh) * capacityFactorGround;

  const computeGroundHardwareCost = (y: number, baseCost: number) => {
    const yearIndex = y - 2025;
    let cost = baseCost;
    for (let i = 0; i < yearIndex; i++) {
      let annualDecline;
      if (i < 3) annualDecline = 0.10;
      else if (i < 6) annualDecline = 0.05;
      else if (i < 10) annualDecline = 0.02;
      else annualDecline = 0.005;
      cost *= (1 - annualDecline);
    }
    return cost;
  };
  const groundLifetime = params.groundHardwareLifetimeYears ?? CONSTANTS.GROUND_HARDWARE_LIFETIME;
  const groundHardwareCapexPerPflopYear = computeGroundHardwareCost(year, CONSTANTS.GROUND_HARDWARE_COST_PFLOP_2025) / groundLifetime;

  const smrParams = params.smrToggleEnabled ? (params.smrToggleParams || DEFAULT_SMR_PARAMS) : undefined;
  
  let groundResult;
  let groundTotalCost: number;
  let energyConstraintMultiplier: number;
  let constraintBreakdown: {
    grid: number;
    cooling: number;
    water: number;
    land: number;
    energyMultiplier: number;
    siteMultiplier: number;
    capacityDeliveryMultiplier?: number;
  };
  
  const useRegionalModel = params.useRegionalGroundModel === true && params.groundConstraintsEnabled && !params.isStaticMode;
  const useBuildoutModel = params.useBuildoutModel === true && params.groundConstraintsEnabled && !params.isStaticMode && !useRegionalModel;
  const useQueueModel = (params.useQueueBasedConstraint !== false) && params.groundConstraintsEnabled && !params.isStaticMode && !useRegionalModel && !useBuildoutModel;
  
  if (useQueueModel) {
    const supplyTrajectory = generateGroundSupplyTrajectory(2025, year);
    const currentSupplyState = supplyTrajectory[supplyTrajectory.length - 1];
    
    // Calculate WACC-based penalties and multipliers
    const penalties = calculateGroundConstraintPenalties(
      currentSupplyState,
      groundEffectiveGflopsPerW,
      effectivePueGround,
      capacityFactorGround
    );
    
    const BASE_SITE_2025 = 1500;
    
    // Energy cost: Use actual calculated value (NOT multiplied by constraint)
    // CRITICAL FIX: Do NOT apply PUE multiplier - energy cost is base only
    // PUE stress should be reflected in capacityDeliveryPremium, not energy multiplier
    const energyCostBase = groundEnergyCostPerPflopYear;
    const energyCost = energyCostBase; // Base energy cost only - no multiplier
    
    // GROUND COST ACCOUNTING: Explicit separation of components (queue model)
    const siteCostBase = BASE_SITE_2025;
    
    // 1. siteCapexAmortPerPflopYear: Pure amortized capex (NOT affected by constraint)
    const siteCapexAmortPerPflopYear = siteCostBase;
    
    // 2. capacityDeliveryPremiumPerPflopYear: Scarcity price (independent, from site multiplier)
    const capacityDeliveryPremiumPerPflopYear = siteCostBase * (penalties.siteMultiplier - 1);
    
    // 3. timeToEnergizePenaltyPerPflopYear: WACC carry + lost margin (independent, from queue delay)
    const timeToEnergizePenaltyPerPflopYear = penalties.timeToEnergizePenaltyPerPflopYear;
    
    // CRITICAL: Remove double counting
    // Do NOT include timeToEnergizePenalty in headline cost used for crossover
    // (capacity gating in market share already accounts for backlog)
    // Compute both base and effective costs:
    const siteCostPerPflopYear_base = siteCapexAmortPerPflopYear + capacityDeliveryPremiumPerPflopYear;
    const siteCostPerPflopYear_effective = siteCapexAmortPerPflopYear + timeToEnergizePenaltyPerPflopYear + capacityDeliveryPremiumPerPflopYear;
    
    // Validation
    const siteCostCheck = Math.abs(siteCostPerPflopYear_effective - (siteCapexAmortPerPflopYear + timeToEnergizePenaltyPerPflopYear + capacityDeliveryPremiumPerPflopYear));
    if (siteCostCheck > 0.01) {
      throw new Error(`Site cost accounting error (queue model): siteCost_effective=${siteCostPerPflopYear_effective} != sum(components)=${siteCapexAmortPerPflopYear + timeToEnergizePenaltyPerPflopYear + capacityDeliveryPremiumPerPflopYear}, diff=${siteCostCheck}`);
    }
    
    const hardwareCost = groundHardwareCapexPerPflopYear;
    
    // Headline cost for crossover: base only (excludes delay penalty, which is handled via capacity gating)
    groundTotalCost = (energyCost + siteCostPerPflopYear_base + hardwareCost) * groundLatencyPenalty;
    // Effective/all-in cost: includes delay penalty (for reference/debug)
    const groundTotalCostEffective = (energyCost + siteCostPerPflopYear_effective + hardwareCost) * groundLatencyPenalty;
    
    // CRITICAL FIX: Remove all multipliers - use additive terms only
    // Multipliers are NOT applied to any dollar amounts
    // All constraint effects are captured in capacityDeliveryPremium and timeToEnergizePenalty
    energyConstraintMultiplier = 1.0; // Never applied - for backward compat only
    
    // Constraint breakdown: all multipliers set to 1.0 (not applied)
    // These are kept for debug/decomposition but never multiplied into costs
    constraintBreakdown = {
      grid: 1.0, // Not applied - constraint effects in capacityDeliveryPremium
      cooling: 1.0, // Not applied - constraint effects in capacityDeliveryPremium
      water: 1.0, // Not applied - constraint effects in capacityDeliveryPremium
      land: 1.0, // Not applied - constraint effects in capacityDeliveryPremium
      energyMultiplier: 1.0, // Never applied - energy cost is base only
      siteMultiplier: 1.0, // Not applied - constraint effects in capacityDeliveryPremium
      capacityDeliveryMultiplier: 1.0, // Not applied - constraint effects in capacityDeliveryPremium
    };
    
    groundResult = {
      energyCost: energyCost * groundLatencyPenalty, // Energy with PUE multiplier
      siteCost: siteCostPerPflopYear_base * groundLatencyPenalty, // Site = base components (excludes delay penalty)
      hardwareCost: hardwareCost * groundLatencyPenalty,
      siteCapexAmortPerPflopYear: siteCapexAmortPerPflopYear * groundLatencyPenalty, // Explicit: pure capex
      capacityDeliveryPremium: capacityDeliveryPremiumPerPflopYear * groundLatencyPenalty, // Explicit: scarcity premium
      timeToEnergizePenalty: timeToEnergizePenaltyPerPflopYear * groundLatencyPenalty, // Explicit: WACC-based penalty (not in headline cost)
      totalCostPerPflopYear: groundTotalCost, // Base cost (excludes delay penalty - handled via capacity gating)
      totalCostPerPflopYearEffective: groundTotalCostEffective, // Effective/all-in cost (includes delay penalty)
      constraintMultiplier: 1.0, // NOT APPLIED - kept for backward compat only
      breakdown: constraintBreakdown,
      constraints: {
        method: 'adders',
        capacityDeliveryPremium: capacityDeliveryPremiumPerPflopYear * groundLatencyPenalty,
        delayPenalty: timeToEnergizePenaltyPerPflopYear * groundLatencyPenalty,
        appliedMultipliers: {
          constraintMultiplierUsed: false,
          energyMultiplierUsed: false,
          siteMultiplierUsed: false,
        },
      },
      supplyMetrics: {
        demandGw: currentSupplyState.demandGw,
        capacityGw: currentSupplyState.capacityGw,
        pipelineGw: currentSupplyState.pipelineGw,
        maxBuildRateGwYear: currentSupplyState.maxBuildRateGwYear,
        avgWaitYears: currentSupplyState.avgWaitYears,
        utilizationPct: currentSupplyState.utilizationPct,
      },
      constraintComponents: {
        queuePressure: currentSupplyState.avgWaitYears > 0 ? 1 + currentSupplyState.avgWaitYears / 2 : 1,
        utilizationPressure: currentSupplyState.utilizationPct > 0.85 ? 1 + (currentSupplyState.utilizationPct - 0.85) * 5 : 1,
        scarcityPremium: penalties.siteMultiplier,
      },
      // Debug fields for WACC penalties
      backlogGw: penalties.backlogGw,
      avgWaitYears: penalties.avgWaitYears,
      capexAtRiskPerMW: penalties.capexAtRiskPerMW,
      carryCostPerMW: penalties.carryCostPerMW,
      lostMarginPerMW: penalties.lostMarginPerMW,
      timeToEnergizePenaltyPerPflopYear: penalties.timeToEnergizePenaltyPerPflopYear,
      pueMultiplier: penalties.pueMultiplier,
      smrEnabled: false,
      smrRampFactor: 0,
      effectiveElectricityCost: groundElectricityPricePerMwh,
      constraintRelief: { grid: 0, cooling: 0, water: 0, land: 0 },
    };
  } else if (useBuildoutModel) {
    // NEW: Ramping Mobilization Model
    // Replaces constraint multiplier with explicit buildout capex premium and delay penalties
    // Uses ramping buildout capacity with smooth interpolation
    
    // Get mobilization parameters (use defaults if not provided)
    const mobilizationParams: MobilizationScenarioParams = params.mobilizationParams ? {
      ...DEFAULT_MOBILIZATION_PARAMS,
      ...params.mobilizationParams,
      demandCurve: (params.mobilizationParams.demandCurve || DEFAULT_MOBILIZATION_PARAMS.demandCurve) as 'piecewise_exponential',
    } : DEFAULT_MOBILIZATION_PARAMS;
    
    // Get previous mobilization state from params (passed from trajectory)
    // If not provided, calculate from previous year's demand
    const prevMobilizationState: MobilizationState | null = (params as any).prevMobilizationState ?? null;
    
    // Step mobilization state forward
    const mobilizationResult = stepMobilizationState(
      prevMobilizationState,
      mobilizationParams,
      year,
      effectivePueGround,
      0 // retirementsGW = 0 for now
    );
    
    // Extract values from mobilization model
    const demandNewGW = mobilizationResult.demandNewGW;
    const buildRateGWyr = mobilizationResult.buildRateGWyr;
    const buildableGW = buildRateGWyr; // buildable = build rate
    const capacityGW = mobilizationResult.capacityGW;
    const pipelineGW = mobilizationResult.pipelineGW;
    const backlogGW = mobilizationResult.backlogGW;
    const avgWaitYears = mobilizationResult.avgWaitYears;
    
    // Default buildout parameters
    const WACC = 0.10; // 10% WACC
    const PROJECT_LIFETIME = 20; // 20 years
    const BUILDOUT_CAPEX_BASE = 2000; // $2k/kW base buildout capex (reduced from 3k)
    const DEFAULT_SCARCITY_CURVE = {
      k: 2.0, // buildoutK (increased from 0.5 for sharper scaling)
      exponent: 1.7, // buildoutExponent (increased from 1.5 for sharper scaling)
      thresholdUtil: 0.0, // Premium kicks in immediately
    };
    const PANIC_EXPONENT = 1.3; // Exponent for delay penalty panic regime
    
    // Calculate buildout constraints
    const buildoutParams = {
      demandNewGWByYear: demandNewGW,
      buildableGWByYear: buildableGW,
      backlogGW: backlogGW, // Pass from mobilization model
      avgWaitYears: avgWaitYears, // Pass from mobilization model
      baseEnergyPricePerMwhByYear: groundElectricityPricePerMwh,
      pueGroundByYear: effectivePueGround,
      wacc: WACC,
      projectLifetimeYears: params.buildoutProjectLifetimeYears ?? PROJECT_LIFETIME,
      valueOfTimeMode: params.valueOfTimeMode ?? 'wacc_on_capex', // Default to wacc_on_capex
      buildoutCapexBase_$PerkW: params.buildoutCapexBase_$PerkW ?? BUILDOUT_CAPEX_BASE,
      buildoutCapexScarcityCurve: params.buildoutCapexScarcityCurve ?? DEFAULT_SCARCITY_CURVE,
      panicExponent: params.buildoutPanicExponent ?? PANIC_EXPONENT,
      hardwareCapexPerPflopYear: groundHardwareCapexPerPflopYear, // Pass directly (not converted to kW)
      siteCapexAmortPerPflopYear: BASE_SITE_2025, // Pass directly (not converted to kW)
      // Legacy fields (kept for backward compat, but not used in new calculation)
      computeHardwareCapex: groundHardwareCapexPerPflopYear * (groundEffectiveGflopsPerW * capacityFactorGround / effectivePueGround / 1e6),
      siteCapex: BASE_SITE_2025 * (groundEffectiveGflopsPerW * capacityFactorGround / effectivePueGround / 1e6),
      marginPerGpuHour: 0.5,
      annualGpuHoursDelivered: 8760 * capacityFactorGround,
      hybridWeights: params.buildoutHybridWeights ?? { waccWeight: 0.5, marginWeight: 0.5 },
    };
    
    const buildoutResult = calculateBuildoutConstraints(
      null, // State is now managed by mobilization model
      buildoutParams,
      year,
      groundEffectiveGflopsPerW,
      effectivePueGround,
      capacityFactorGround
    );
    
    // Energy cost: base energy only (NOT affected by buildout constraints)
    const energyCost = groundEnergyCostPerPflopYear;
    
    // Site cost: base capex + buildout premium + delay penalty
    const siteCapexAmortPerPflopYear = BASE_SITE_2025;
    const buildoutPremiumPerPflopYear = buildoutResult.buildoutPremiumPerPflopYear;
    const delayPenaltyPerPflopYear = buildoutResult.delayPenaltyPerPflopYear;
    
    // CRITICAL: Remove double counting
    // Do NOT include timeToEnergizePenalty in headline cost used for crossover
    // (capacity gating in market share already accounts for backlog)
    // Compute both base and effective costs:
    const siteCostPerPflopYear_base = siteCapexAmortPerPflopYear + buildoutPremiumPerPflopYear;
    const siteCostPerPflopYear_effective = siteCapexAmortPerPflopYear + buildoutPremiumPerPflopYear + delayPenaltyPerPflopYear;
    
    // Validation: ensure no double counting
    if (params.useQueueBasedConstraint !== false) {
      console.warn(`[BUILDOUT] useQueueBasedConstraint should be false when useBuildoutModel is true to avoid double counting`);
    }
    
    const hardwareCost = groundHardwareCapexPerPflopYear;
    
    // Headline cost for crossover: base only (excludes delay penalty, which is handled via capacity gating)
    groundTotalCost = (energyCost + siteCostPerPflopYear_base + hardwareCost) * groundLatencyPenalty;
    // Effective/all-in cost: includes delay penalty (for reference/debug)
    const groundTotalCostEffective = (energyCost + siteCostPerPflopYear_effective + hardwareCost) * groundLatencyPenalty;
    energyConstraintMultiplier = 1.0; // Energy NOT affected by buildout constraints
    
    // Constraint breakdown: all 1.0 (no multipliers, use buildout terms instead)
    constraintBreakdown = {
      grid: 1.0,
      cooling: 1.0,
      water: 1.0,
      land: 1.0,
      energyMultiplier: 1.0, // Energy NOT affected
      siteMultiplier: 1.0, // No multiplier, use buildout premium
      capacityDeliveryMultiplier: 1.0, // No multiplier, use buildout premium
    };
    
    groundResult = {
      energyCost: energyCost * groundLatencyPenalty,
      siteCost: siteCostPerPflopYear_base * groundLatencyPenalty,
      hardwareCost: hardwareCost * groundLatencyPenalty,
      siteCapexAmortPerPflopYear: siteCapexAmortPerPflopYear * groundLatencyPenalty,
      capacityDeliveryPremium: buildoutPremiumPerPflopYear * groundLatencyPenalty, // Buildout premium replaces old capacityDeliveryPremium
      timeToEnergizePenalty: delayPenaltyPerPflopYear * groundLatencyPenalty, // Delay penalty replaces old timeToEnergizePenalty
      totalCostPerPflopYear: groundTotalCost, // Base cost (excludes delay penalty - handled via capacity gating)
      totalCostPerPflopYearEffective: groundTotalCostEffective, // Effective/all-in cost (includes delay penalty)
      constraintMultiplier: 1.0, // No constraint multiplier - use buildout terms
      breakdown: constraintBreakdown,
      supplyMetrics: {
        demandGw: mobilizationResult.demandGW,
        capacityGw: capacityGW,
        pipelineGw: pipelineGW,
        maxBuildRateGwYear: buildRateGWyr,
        avgWaitYears: avgWaitYears,
        utilizationPct: capacityGW > 0 ? mobilizationResult.demandGW / capacityGW : 0,
      },
      // Buildout debug fields (from ramping mobilization model)
      backlogGw: backlogGW,
      avgWaitYears: avgWaitYears,
      buildoutDebug: {
        demandNewGW: demandNewGW,
        buildableGW: buildableGW,
        buildRateGWyr: buildRateGWyr,
        capacityGW: capacityGW,
        pipelineGW: pipelineGW,
        scarcityIndex: buildoutResult.factors.scarcityIndex,
        buildoutCapex_$PerkW: buildoutResult.factors.buildoutCapex_$PerkW,
        annualizedBuildoutPremium_$PerkWyr: buildoutResult.factors.annualizedBuildoutPremium_$PerkWyr,
        timeToPowerYears: avgWaitYears,
        valueOfTime_$PerYear: buildoutResult.factors.valueOfTime_$PerYear,
        delayPenalty_$PerYear: buildoutResult.factors.delayPenalty_$PerYear,
        buildoutPremiumPerPflopYear: buildoutPremiumPerPflopYear,
        delayPenaltyPerPflopYear: delayPenaltyPerPflopYear,
        // Additional mobilization debug fields
        demandGW: mobilizationResult.demandGW,
        demandGrowthRate: mobilizationResult.demandGrowthRate,
        backlogGW: mobilizationResult.backlogGW,
        avgWaitYears: mobilizationResult.avgWaitYears,
      },
      smrEnabled: false,
      smrRampFactor: 0,
      effectiveElectricityCost: groundElectricityPricePerMwh,
      constraintRelief: { grid: 0, cooling: 0, water: 0, land: 0 },
      constraints: {
        method: 'adders',
        capacityDeliveryPremium: buildoutPremiumPerPflopYear * groundLatencyPenalty,
        delayPenalty: delayPenaltyPerPflopYear * groundLatencyPenalty,
        appliedMultipliers: {
          constraintMultiplierUsed: false,
          energyMultiplierUsed: false,
          siteMultiplierUsed: false,
        },
        debug: {
          doubleCountCheck: {
            mode: 'adders',
            multiplierApplied: false,
            addersApplied: true,
            invariantOk: true,
            notes: 'Buildout model uses adders only (capacityDeliveryPremium + delayPenalty)',
          },
        },
      },
    };
    
    // Invariant: If using adders, multipliers must not be applied
    if (process.env.NODE_ENV === 'development') {
      const hasMultiplier = groundResult.constraintMultiplier !== 1.0;
      const hasAdder = (groundResult.capacityDeliveryPremium > 0) || (groundResult.timeToEnergizePenalty > 0);
      if (hasMultiplier && hasAdder) {
        throw new Error(
          `[DOUBLE COUNTING DETECTED] Year ${year}: constraintMultiplier=${groundResult.constraintMultiplier} != 1.0 ` +
          `AND adders > 0 (capacityDeliveryPremium=${groundResult.capacityDeliveryPremium}, ` +
          `delayPenalty=${groundResult.timeToEnergizePenalty}). Both cannot be applied simultaneously.`
        );
      }
    }
  } else if (useRegionalModel) {
    const demandPflops = getGlobalDemandPflops(year, groundEffectiveGflopsPerW);
    const regionalResult = calculateRegionalGroundCost(
      year,
      demandPflops,
      groundEffectiveGflopsPerW,
      effectivePueGround,
      capacityFactorGround,
      groundHardwareCapexPerPflopYear,
      undefined // Use default regions
    );
    
    // REFACTORED: Regional model - energy cost should NOT have constraint multiplier
    // Regional model already separates energy (raw) from site (with constraint)
    const energyCost = regionalResult.energyCostPerPflopYear; // Raw electricity (NO constraint multiplier)
    const siteCost = regionalResult.siteCostPerPflopYear; // Site costs WITH constraint multiplier
    
    // GROUND COST ACCOUNTING: Explicit separation for regional model
    const siteCostBase = BASE_SITE_2025;
    
    // 1. siteCapexAmortPerPflopYear: Base site capex (NOT affected by constraint)
    const siteCapexAmortPerPflopYear = siteCostBase;
    
    // 2. capacityDeliveryPremiumPerPflopYear: Premium above base (from constraint multiplier)
    const capacityDeliveryPremiumPerPflopYear = Math.max(0, siteCost - siteCostBase);
    
    // 3. timeToEnergizePenaltyPerPflopYear: Regional model doesn't model queue delay separately (0 for now)
    const timeToEnergizePenaltyPerPflopYear = 0;
    
    // INVARIANT: siteCostPerPflopYear = siteCapexAmort + timeToEnergizePenalty + capacityDeliveryPremium
    const siteCostPerPflopYear = siteCapexAmortPerPflopYear + timeToEnergizePenaltyPerPflopYear + capacityDeliveryPremiumPerPflopYear;
    
    // Validation (allow small tolerance for regional model approximation)
    const siteCostCheck = Math.abs(siteCost - siteCostPerPflopYear);
    if (siteCostCheck > 1.0) {
      throw new Error(`Site cost accounting error (regional model): siteCost=${siteCost} != sum(components)=${siteCostPerPflopYear}, diff=${siteCostCheck}`);
    }
    
    // CRITICAL FIX: Regional model already separates energy (no multiplier) from site (with premium)
    // Do NOT apply constraintMultiplier - it's already reflected in siteCostPerPflopYear
    const constraintMultiplier = 1.0; // Not applied - kept for backward compat only
    
    groundTotalCost = regionalResult.totalCostPerPflopYear;
    energyConstraintMultiplier = 1.0; // Never applied
    constraintBreakdown = {
      grid: 1.0, // Not applied
      cooling: 1.0, // Not applied
      water: 1.0, // Not applied
      land: 1.0, // Not applied
      energyMultiplier: 1.0, // Never applied
      siteMultiplier: 1.0, // Not applied - constraint effects already in siteCost
      capacityDeliveryMultiplier: 1.0, // Not applied - constraint effects already in siteCost
    };
    
    groundResult = {
      energyCost: energyCost, // Raw electricity cost (NO constraint multiplier)
      siteCost: siteCostPerPflopYear, // Site = sum of components (INVARIANT)
      siteCapexAmortPerPflopYear: siteCapexAmortPerPflopYear, // Explicit: pure capex
      capacityDeliveryPremium: capacityDeliveryPremiumPerPflopYear, // Explicit: scarcity premium
      timeToEnergizePenalty: timeToEnergizePenaltyPerPflopYear, // Regional model: 0 (not modeled separately)
      hardwareCost: regionalResult.hardwareCapexPerPflopYear,
      totalCostPerPflopYear: groundTotalCost,
      constraintMultiplier: 1.0, // NOT APPLIED - kept for backward compat only
      constraints: {
        method: 'adders',
        capacityDeliveryPremium: capacityDeliveryPremiumPerPflopYear, // From regional model siteCost - siteCostBase
        delayPenalty: 0, // Regional model doesn't model delay separately
        appliedMultipliers: {
          constraintMultiplierUsed: false,
          energyMultiplierUsed: false,
          siteMultiplierUsed: false,
        },
        debug: {
          doubleCountCheck: {
            mode: 'adders',
            multiplierApplied: false,
            addersApplied: capacityDeliveryPremiumPerPflopYear > 0,
            invariantOk: true,
            notes: 'Regional model uses adders only (capacityDeliveryPremium from siteCost - siteCostBase)',
          },
        },
      },
      breakdown: constraintBreakdown,
      smrEnabled: false,
      smrRampFactor: 0,
      effectiveElectricityCost: regionalResult.averageEnergyCostMwh,
      constraintRelief: { grid: 0, cooling: 0, water: 0, land: 0 },
      // Ensure backlogGw and avgWaitYears are always set (use supplyMetrics as fallback)
      backlogGw: regionalResult.supplyMetrics?.pipelineGw ?? 0, // TEMP proxy: use pipeline as placeholder
      avgWaitYears: regionalResult.supplyMetrics?.avgWaitYears ?? 0,
      supplyMetrics: regionalResult.supplyMetrics ?? {
        demandGw: 0,
        capacityGw: 0,
        pipelineGw: 0,
        maxBuildRateGwYear: 0,
        avgWaitYears: 0,
        utilizationPct: 0,
      },
    };
  } else {
    groundResult = calculateGroundTotal(
      year,
      params,
      ENERGY_COST_BASE_2025,
      groundHardwareCapexPerPflopYear,
      params.isStaticMode,
      effectiveGroundScenario,
      groundLatencyPenalty,
      smrParams,
      firstCapYear ?? null,
      groundEnergyCostPerPflopYear,
      groundElectricityPricePerMwh
    );

    // CRITICAL FIX: Ensure backlogGw and avgWaitYears are always set (even if calculateGroundTotal doesn't provide them)
    // Use supplyMetrics as fallback if available, otherwise 0
    // Type assertion needed because calculateGroundTotal may not include these fields
    const groundResultWithBacklog = groundResult as any;
    if (!('backlogGw' in groundResultWithBacklog) || groundResultWithBacklog.backlogGw === undefined) {
      groundResultWithBacklog.backlogGw = groundResultWithBacklog.supplyMetrics?.pipelineGw ?? 0; // TEMP proxy
    }
    if (!('avgWaitYears' in groundResultWithBacklog) || groundResultWithBacklog.avgWaitYears === undefined) {
      groundResultWithBacklog.avgWaitYears = groundResultWithBacklog.supplyMetrics?.avgWaitYears ?? 0;
    }
    // Ensure supplyMetrics exists
    if (!groundResultWithBacklog.supplyMetrics) {
      groundResultWithBacklog.supplyMetrics = {
        demandGw: 0,
        capacityGw: 0,
        pipelineGw: groundResultWithBacklog.backlogGw ?? 0,
        maxBuildRateGwYear: 0,
        avgWaitYears: groundResultWithBacklog.avgWaitYears ?? 0,
        utilizationPct: 0,
      };
    }
    groundResult = groundResultWithBacklog;

    groundTotalCost = groundResult.totalCostPerPflopYear;
    // CRITICAL FIX: Never apply multipliers - all set to 1.0
    energyConstraintMultiplier = 1.0; // Never applied
    
    // Invariant: If using adders, multipliers must not be applied
    if (process.env.NODE_ENV === 'development' && groundResult.constraints) {
      const hasMultiplier = groundResult.constraintMultiplier !== 1.0;
      const hasAdder = (groundResult.constraints.capacityDeliveryPremium > 0) || (groundResult.constraints.delayPenalty > 0);
      if (hasMultiplier && hasAdder) {
        throw new Error(
          `[DOUBLE COUNTING DETECTED] Year ${year}: constraintMultiplier=${groundResult.constraintMultiplier} != 1.0 ` +
          `AND adders > 0 (capacityDeliveryPremium=${groundResult.constraints.capacityDeliveryPremium}, ` +
          `delayPenalty=${groundResult.constraints.delayPenalty}). Both cannot be applied simultaneously.`
        );
      }
    }
    constraintBreakdown = {
      grid: 1.0, // Not applied
      cooling: 1.0, // Not applied
      water: 1.0, // Not applied
      land: 1.0, // Not applied
      energyMultiplier: 1.0, // Never applied
      siteMultiplier: 1.0, // Not applied
      capacityDeliveryMultiplier: 1.0, // Not applied
    };
    
    // Invariant: Check for double counting
    if (process.env.NODE_ENV === 'development') {
      const hasMultiplier = (groundResult.constraintMultiplier !== 1.0) || 
                           (groundResult.breakdown.energyMultiplier !== 1.0) ||
                           (groundResult.breakdown.siteMultiplier !== 1.0);
      const hasPremium = (groundResult.capacityDeliveryPremium || 0) > 0 ||
                        (groundResult.timeToEnergizePenalty || 0) > 0;
      if (hasMultiplier && hasPremium) {
        console.warn(
          `[DOUBLE COUNTING DETECTED] Year ${year}: ` +
          `Multipliers (constraint=${groundResult.constraintMultiplier}, ` +
          `energy=${groundResult.breakdown.energyMultiplier}, ` +
          `site=${groundResult.breakdown.siteMultiplier}) AND ` +
          `premiums (capacity=${groundResult.capacityDeliveryPremium}, ` +
          `delay=${groundResult.timeToEnergizePenalty}) are both present. ` +
          `This indicates double counting.`
        );
      }
    }
  }

  const launchCostPerKg = getLaunchCostPerKg(year, baseLaunchCost) * launchDiscount;
  const lifetimeYears = 6;
  
  // Fusion toggle params
  const fusionParams = params.fusionToggleEnabled 
    ? (params.fusionToggleParams || { ...DEFAULT_FUSION_PARAMS, enabled: true })
    : undefined;

  // CONSTELLATION SIZING: Design constellation to meet compute requirements
  // Convert target compute (GW) to power (kW) for constellation sizing
  const targetComputeKw = satellitePowerKW;
  let constellation = designConstellation(
    targetComputeKw,
    SATELLITE_CONSTRAINTS,
    100000, // Starship: 100t to LEO
    trajSpecificPower
  );
  
  // Use per-satellite compute power for cost calculation
  let computePowerPerSatKw = constellation.computePerSatKw;

  let hybridResult = computeSatelliteHybridCost(
    year, 
    launchCostPerKg, 
    {
      ...DEFAULT_CONFIG,
      computePowerKw: computePowerPerSatKw, // Use per-satellite power
      altitudeKm: orbitalAltitude,
      lifetimeYears: lifetimeYears,
      specificPowerWKg: trajSpecificPower,
      useRadHardChips: useRadHardChips,
      sunFraction: sunFraction,
      workloadType: workloadType || 'inference'
    }, 
    fusionParams,
    params.useCorrectedSpecificPower,
    params.useCorrectedThermal
  );
  
  // CRITICAL FIX: Calculate delivered efficiency with ALL delivery derates
  // delivered = systemEffective * thermalCapFactor * radiationDerate * availability
  // Single source of truth for all three factors:
  const thermalCapFactor = hybridResult.thermalSystem.thermalCapFactor;
  const radiationDerate = hybridResult.degradationFactor || 1.0; // Hardware degradation from radiation (chip failures, ECC overhead)
  const availability = hybridResult.capacityFactor || 1.0; // Capacity factor is uptime-inclusive (includes eclipse, degradation, radiation downtime, uptime)
  
  // Calculate delivered efficiency (all derates applied multiplicatively)
  // This is the true "delivered" efficiency that accounts for all operational constraints
  let orbitDeliveredGflopsPerWatt = orbitSystemEffectiveGflopsPerWatt * thermalCapFactor * radiationDerate * availability;
  
  // CRITICAL: If thermal constraint causes delivered efficiency to drop below minimum (20 GFLOPS/W),
  // this indicates a severe thermal constraint that should be handled by expanding radiator or reducing compute
  // For now, we clamp to minimum to prevent validation errors, but log a warning
  if (orbitDeliveredGflopsPerWatt < CONSTANTS.MIN_DELIVERED_GFLOPS_PER_W) {
    const originalDelivered = orbitDeliveredGflopsPerWatt;
    orbitDeliveredGflopsPerWatt = CONSTANTS.MIN_DELIVERED_GFLOPS_PER_W;
    
    // Log warning about severe thermal constraint
    if (process.env.NODE_ENV === 'development') {
      console.warn(
        `[THERMAL CONSTRAINT] Severe thermal cap: delivered efficiency would be ${originalDelivered.toFixed(2)} GFLOPS/W ` +
        `(systemEffective=${orbitSystemEffectiveGflopsPerWatt.toFixed(2)}, thermalCapFactor=${thermalCapFactor.toFixed(3)}). ` +
        `Clamped to minimum ${CONSTANTS.MIN_DELIVERED_GFLOPS_PER_W} GFLOPS/W. ` +
        `Consider expanding radiator area or reducing compute power.`
      );
    }
  }
  
  // Use delivered efficiency for all cost calculations
  let orbitEffectiveGflopsPerW = validateGflopsPerWatt(
    orbitDeliveredGflopsPerWatt,
    'orbital delivered efficiency calculation'
  );
  
  // Power scaling calculation
  const powerScalingParams = params.powerScalingParams || DEFAULT_POWER_SCALING;
  const scalingResult = calculateScaledMass(computePowerPerSatKw, powerScalingParams);

  // CONSTELLATION SCALING: Apply constellation multiplier to mass and costs
  // Per-satellite mass (already calculated for one satellite)
  let massPerSatKg = hybridResult.totalMassKg * massMultiplier;
  
  // CRITICAL FIX: Check if actual mass exceeds limit and re-split constellation if needed
  // The simplified mass model in designConstellation may underestimate actual mass
  // If actual mass exceeds limit, we need to split into smaller satellites
  const MAX_SATELLITE_MASS_KG = SATELLITE_CONSTRAINTS.maxMassKg; // 10,000 kg from constraints
  if (massPerSatKg > MAX_SATELLITE_MASS_KG) {
    // Calculate required compute per satellite to stay under mass limit
    // Mass scales roughly with compute power, so: massPerSatKg / computePowerPerSatKw = massPerKw
    const massPerKw = massPerSatKg / computePowerPerSatKw;
    const maxComputePerSatKw = MAX_SATELLITE_MASS_KG / massPerKw;
    
    // Recalculate constellation with smaller satellites
    const adjustedConstellation = designConstellation(
      targetComputeKw,
      {
        ...SATELLITE_CONSTRAINTS,
        maxComputeKw: maxComputePerSatKw * 0.9, // Use 90% of max to leave margin
      },
      100000, // Starship: 100t to LEO
      trajSpecificPower
    );
    
    // Recalculate hybrid cost with adjusted compute per satellite
    const adjustedHybridResult = computeSatelliteHybridCost(
      year, 
      launchCostPerKg, 
      {
        ...DEFAULT_CONFIG,
        computePowerKw: adjustedConstellation.computePerSatKw,
        altitudeKm: orbitalAltitude,
        lifetimeYears: lifetimeYears,
        specificPowerWKg: trajSpecificPower,
        useRadHardChips: useRadHardChips,
        sunFraction: sunFraction,
        workloadType: workloadType || 'inference'
      }, 
      fusionParams,
      params.useCorrectedSpecificPower,
      params.useCorrectedThermal
    );
    
    // Update with adjusted values
    const adjustedMassPerSatKg = adjustedHybridResult.totalMassKg * massMultiplier;
    if (adjustedMassPerSatKg > MAX_SATELLITE_MASS_KG) {
      // Still too heavy - this shouldn't happen, but log a warning
      console.warn(
        `Satellite mass ${adjustedMassPerSatKg.toFixed(0)}kg still exceeds limit ${MAX_SATELLITE_MASS_KG}kg ` +
        `even after splitting to ${adjustedConstellation.computePerSatKw.toFixed(1)}kW per satellite. ` +
        `Consider further reducing compute per satellite or improving specific power.`
      );
    }
    
    // Use adjusted constellation and hybrid result
    constellation = adjustedConstellation;
    hybridResult = adjustedHybridResult;
    computePowerPerSatKw = adjustedConstellation.computePerSatKw;
    massPerSatKg = adjustedMassPerSatKg;
    
    // Recalculate delivered efficiency with adjusted thermal cap (all derates applied)
    const adjustedThermalCapFactor = hybridResult.thermalSystem.thermalCapFactor;
    const adjustedRadiationDerate = hybridResult.degradationFactor || 1.0;
    const adjustedAvailability = hybridResult.capacityFactor || 1.0;
    let adjustedDeliveredGflopsPerWatt = orbitSystemEffectiveGflopsPerWatt * adjustedThermalCapFactor * adjustedRadiationDerate * adjustedAvailability;
    
    // Clamp to minimum if thermal constraint is too severe
    if (adjustedDeliveredGflopsPerWatt < CONSTANTS.MIN_DELIVERED_GFLOPS_PER_W) {
      adjustedDeliveredGflopsPerWatt = CONSTANTS.MIN_DELIVERED_GFLOPS_PER_W;
    }
    
    orbitEffectiveGflopsPerW = validateGflopsPerWatt(
      adjustedDeliveredGflopsPerWatt,
      'orbital delivered efficiency (after constellation split)'
    );
  }
  
  // Scale costs by number of satellites and apply constellation overhead
  // Calculate AFTER mass check so we use the adjusted constellation if it was split
  const constellationMultiplier = constellation.numSatellites;
  const constellationOverheadMultiplier = constellation.constellationOverhead;
  
  // Total constellation mass
  const effectiveTotalMassKg = massPerSatKg * constellation.numSatellites;
  const effectiveTotalLaunchCost = effectiveTotalMassKg * launchCostPerKg;

  // Apply Elon Scenario: Discounts
  const effectivePowerFabCost = hybridResult.powerSystem.fabCostUsd * powerDiscount;
  const effectiveNetworkingFabCost = hybridResult.networking.fabCostUsd * networkingDiscount;
  const effectiveNetworkingOpEx = (hybridResult.networking.annualOpExUsd || 0) * networkingDiscount;

  // Effective PFLOPs: per-satellite PFLOPs × number of satellites
  const effectivePflopsPerSat = hybridResult.effectivePflops;
  const totalEffectivePflops = effectivePflopsPerSat * constellation.numSatellites;
  
  // Launch cost: total constellation launch cost / total PFLOPs
  const launchCostPerPflopYear = effectiveTotalLaunchCost / totalEffectivePflops / lifetimeYears;

  // CRITICAL FIX 1: Cost Accounting - ensure breakdown sums to total
  // Calculate each component explicitly, scaled by constellation
  // Per-satellite costs × number of satellites × constellation overhead
  const constellationCostMultiplier = constellation.numSatellites * constellationOverheadMultiplier;
  
  const powerCost = (effectivePowerFabCost * constellationCostMultiplier) / totalEffectivePflops / lifetimeYears;
  const computeCost = ((hybridResult.computePayload.chipCostUsd + hybridResult.computePayload.qualificationCostUsd) * constellationCostMultiplier) / totalEffectivePflops / lifetimeYears;
  const thermalCost = (hybridResult.thermalSystem.fabCostUsd * constellationCostMultiplier) / totalEffectivePflops / lifetimeYears;
  const radiationCost = (hybridResult.radiationProtection.fabCostUsd * constellationCostMultiplier) / totalEffectivePflops / lifetimeYears;
  const busCost = (hybridResult.bus.fabCostUsd * constellationCostMultiplier) / totalEffectivePflops / lifetimeYears;
  const networkingCost = (effectiveNetworkingFabCost * constellationCostMultiplier) / totalEffectivePflops / lifetimeYears;
  const interconnectCost = (hybridResult.interconnect.totalAnnualCost * constellationCostMultiplier) / totalEffectivePflops;
  const regulatoryCost = ((hybridResult.regulatory?.annualCostUsd || 0) * constellationCostMultiplier) / totalEffectivePflops;
  
  // Ops cost scales with constellation overhead (more satellites = more ops complexity)
  const baseOpsCostPerSat = hybridResult.opsPerPflopYear * effectivePflopsPerSat; // Total ops cost per satellite
  const networkingOpsCostPerSat = (hybridResult.networking.annualOpExUsd || 0) - effectiveNetworkingOpEx; // Already per-sat
  const adjustedNetworkingOpsCostPerSat = effectiveNetworkingOpEx; // Already per-sat
  const opsCostPerSat = baseOpsCostPerSat - networkingOpsCostPerSat + adjustedNetworkingOpsCostPerSat;
  
  // Scale ops cost by constellation (with overhead for coordination)
  const opsCostMultiplier = constellation.numSatellites * (1 + 0.1 * Math.log10(constellation.numSatellites));
  const opsCost = (opsCostPerSat * opsCostMultiplier) / totalEffectivePflops;

  const orbitalBreakdown = {
    power: powerCost,
    compute: computeCost,
    thermal: thermalCost,
    radiation: radiationCost,
    bus: busCost,
    ops: opsCost,
    congestion: 0, // Calculated below
    networking: networkingCost,
    interconnect: interconnectCost,
    regulatory: regulatoryCost,
    launch: launchCostPerPflopYear
  };

  const totalSatelliteCost = hybridResult.totalSatelliteCost * constellationCostMultiplier;
  const satelliteCount = constellation.numSatellites; // Use actual constellation size
  const congestion = calculateCongestion(satelliteCount, totalSatelliteCost, year, 10000 + satelliteCount, spaceTrafficEnabled);
  
  // Total fleet PFLOPS: use constellation total PFLOPs
  // Already calculated as totalEffectivePflops above
  orbitalBreakdown.congestion = spaceTrafficEnabled ? (congestion.congestionCostPerPflopYear / totalEffectivePflops) : 0;

  // PATCH G: Cost Accounting Invariants
  // Use assertCostAccounting to ensure breakdown sums to total exactly
  const orbitalComponents = [
    { name: 'power', value: orbitalBreakdown.power },
    { name: 'compute', value: orbitalBreakdown.compute },
    { name: 'thermal', value: orbitalBreakdown.thermal },
    { name: 'radiation', value: orbitalBreakdown.radiation },
    { name: 'bus', value: orbitalBreakdown.bus },
    { name: 'ops', value: orbitalBreakdown.ops },
    { name: 'networking', value: orbitalBreakdown.networking },
    { name: 'interconnect', value: orbitalBreakdown.interconnect },
    { name: 'regulatory', value: orbitalBreakdown.regulatory },
    { name: 'launch', value: orbitalBreakdown.launch },
    { name: 'congestion', value: orbitalBreakdown.congestion },
  ];
  
  const breakdownSum = Object.values(orbitalBreakdown).reduce((a, b) => a + b, 0);
  const realisticCostPerPflop = breakdownSum;
  
  // Track applied multipliers for debugging
  const appliedMultipliers: Array<{ name: string; value: number; appliedTo: string }> = [
    { name: 'launchDiscount', value: launchDiscount, appliedTo: 'launch cost' },
    { name: 'powerDiscount', value: powerDiscount, appliedTo: 'power fab cost' },
    { name: 'networkingDiscount', value: networkingDiscount, appliedTo: 'networking cost' },
    { name: 'massMultiplier', value: massMultiplier, appliedTo: 'total mass' },
  ];
  
  // Assert cost accounting (throws if invalid)
  const orbitalAccounting = assertCostAccounting(realisticCostPerPflop, orbitalComponents, appliedMultipliers);
  const costAccountingValid = orbitalAccounting.valid;
  const costAccountingErrorPct = orbitalAccounting.errorPct;

  // FIX 5: GPU-hour breakdown must derive from annual cost breakdown
  // CRITICAL: Include constraint adders (delayPenalty + buildoutPremium) in GPU-hour pricing
  // Get constraint adders from groundResult (may be in buildoutDebug or directly in constraints)
  const buildoutDebug = 'buildoutDebug' in groundResult ? groundResult.buildoutDebug : undefined;
  const constraintAdderPerPflopYear = (groundResult.capacityDeliveryPremium || 0) + 
                                      (groundResult.timeToEnergizePenalty || 0) +
                                      (buildoutDebug?.buildoutPremiumPerPflopYear || 0) +
                                      (buildoutDebug?.delayPenaltyPerPflopYear || 0);
  
  // Convert constraint adders to $/GPU-hour
  const pflopsPerGpu = 2.0;
  const utilizationTarget = 0.85;
  const hoursPerYear = 8760;
  const annualGpuHoursPerPFLOP = hoursPerYear * utilizationTarget / pflopsPerGpu;
  const constraintAdderPerGpuHour = constraintAdderPerPflopYear / annualGpuHoursPerPFLOP;
  
  const groundGpuHour = (sla: SLAConfig) => {
    const basePricing = calculateGpuHourPricing(groundTotalCost, {
      pflopsPerGpu,
      utilizationTarget,
      operatorMarginPct: operatorMargin,
      sla,
      location: 'ground'
    }, {
      compute: groundResult.hardwareCost,
      power: groundResult.energyCost,
      site: groundResult.siteCost,
      // Ground cooling included in energy, interconnect minimal
    });
    
    // Add constraint adder to cost breakdown
    const gridScarcity = constraintAdderPerGpuHour;
    const totalCostWithScarcity = basePricing.costBreakdown.hardwareAmortization + 
                                  basePricing.costBreakdown.power + 
                                  basePricing.costBreakdown.cooling + 
                                  basePricing.costBreakdown.interconnect + 
                                  basePricing.costBreakdown.operations +
                                  gridScarcity;
    const margin = totalCostWithScarcity * operatorMargin;
    const pricePerGpuHour = totalCostWithScarcity + margin;
    
    return {
      ...basePricing,
      pricePerGpuHour,
      costBreakdown: {
        ...basePricing.costBreakdown,
        gridScarcity, // Add constraint adder
      },
    };
  };

  const orbitalGpuHour = (sla: SLAConfig) => calculateGpuHourPricing(realisticCostPerPflop, {
    pflopsPerGpu: 2.0,
    utilizationTarget: 0.85,
    operatorMarginPct: operatorMargin,
    sla,
    location: 'orbital'
  }, orbitalBreakdown); // Use full orbital breakdown

  const groundTokens = {
    llama70B: calculateTokenPricing(groundTotalCost, { params: 70e9, precision: 'fp16' }),
    llama405B: calculateTokenPricing(groundTotalCost, { params: 405e9, precision: 'fp16' })
  };

  const orbitalTokens = {
    llama70B: calculateTokenPricing(realisticCostPerPflop, { params: 70e9, precision: 'fp16' }),
    llama405B: calculateTokenPricing(realisticCostPerPflop, { params: 405e9, precision: 'fp16' })
  };

  const edgeInference = params.edgeInference?.enabled 
    ? computeEdgeInferenceCosts(year, params.edgeInference, launchCostPerKg, totalEffectivePflops / effectiveTotalMassKg)
    : undefined;

  const gpuHourCrossover = orbitalGpuHour(SLA_TIERS.standard).pricePerGpuHour < groundGpuHour(SLA_TIERS.standard).pricePerGpuHour;

  // CRITICAL FIX: Validate delivered efficiency by comparing like-for-like only
  // expectedDelivered = systemEffectiveGflopsPerWatt * thermalCapFactor * radiationDerate * availability
  // ratio = deliveredGflopsPerWatt / expectedDelivered
  // If ratio is finite and |1 - ratio| <= tolerance (0.02), then valid=true, warning=null
  // Else valid=false, warning describes the mismatch
  // Remove any other comparisons (e.g., delivered vs systemEffective, delivered vs peak*utilization without overhead, etc.)
  const expectedDelivered = orbitSystemEffectiveGflopsPerWatt * thermalCapFactor * radiationDerate * availability;
  const ratio = orbitDeliveredGflopsPerWatt / Math.max(expectedDelivered, 1e-6);
  const TOLERANCE = 0.02; // 2% tolerance
  const ratioError = Math.abs(1 - ratio);
  
  // CRITICAL: Fix validator logic - if ratio is finite and |1 - ratio| <= tolerance, then valid=true
  const isRatioValid = isFinite(ratio) && ratioError <= TOLERANCE;
  
  // Escalate: if mismatch > 5%, mark as invalid (don't just warn)
  const ESCALATE_THRESHOLD = 0.05; // 5%
  const isInvalid = !isRatioValid && ratioError > ESCALATE_THRESHOLD;
  
  // Debug invariants: assert delivered <= systemEffective + eps
  const deliveredVsSystemError = orbitDeliveredGflopsPerWatt - orbitSystemEffectiveGflopsPerWatt;
  if (deliveredVsSystemError > 1e-6) {
    console.warn(
      `[INVARIANT VIOLATION] Delivered efficiency (${orbitDeliveredGflopsPerWatt.toFixed(2)}) > systemEffective (${orbitSystemEffectiveGflopsPerWatt.toFixed(2)}). ` +
      `Delivered must be <= systemEffective.`
    );
  }
  
  // Log the three factors and their product each year (in dev mode)
  if (process.env.NODE_ENV === 'development') {
    console.log(
      `[EFFICIENCY DEBUG] Year ${year}: ` +
      `systemEffective=${orbitSystemEffectiveGflopsPerWatt.toFixed(2)}, ` +
      `thermalCap=${thermalCapFactor.toFixed(3)}, ` +
      `radiationDerate=${radiationDerate.toFixed(3)}, ` +
      `availability=${availability.toFixed(3)}, ` +
      `product=${(thermalCapFactor * radiationDerate * availability).toFixed(3)}, ` +
      `delivered=${orbitDeliveredGflopsPerWatt.toFixed(2)}, ` +
      `expected=${expectedDelivered.toFixed(2)}, ` +
      `ratio=${ratio.toFixed(4)}, ` +
      `valid=${isRatioValid}`
    );
  }
  
  // CRITICAL: Validate delivered efficiency - compare delivered vs expectedDelivered only
  // Make validator debug explicit with all factors
  // If mismatch > 5%, mark run invalid and stop chart rendering (escalate, don't silently warn)
  const deliveredValidation = {
    valid: isRatioValid,
    warning: isRatioValid 
      ? undefined // Empty/null when valid
      : `Power/Efficiency mismatch: ${ratio.toFixed(2)}x discrepancy (expected=${expectedDelivered.toFixed(2)}, delivered=${orbitDeliveredGflopsPerWatt.toFixed(2)})`,
    expectedDelivered,
    delivered: orbitDeliveredGflopsPerWatt,
    ratio,
    factorsUsed: {
      thermalCapFactor,
      radiationDerate,
      availability,
      utilization: orbitalEfficiencyResult.debug.utilizationFactor,
      systemOverheadFactor: orbitalEfficiencyResult.debug.systemOverheadFactor,
    },
    // Escalate: if ratio is way off (> 5%), mark as invalid
    invalid: !isRatioValid && Math.abs(1 - ratio) > 0.05,
  };
  
  const efficiencyValidation = validateComputeEfficiency(orbitEffectiveGflopsPerW, params.efficiencyLevel);
  const consistencyCheck = assertComputePowerConsistency(orbitEffectiveGflopsPerW, targetComputeKw, totalEffectivePflops, MODEL_UNITS);

  // SANITY PANEL: Comprehensive debug block per year
  const sanityPanel = {
    ground: {
      effectiveGflopsPerW: groundEffectiveGflopsPerW,
      energyCostPerPflopYear: groundResult.energyCost,
      siteCapexAmort: groundResult.siteCapexAmortPerPflopYear ?? (groundResult.siteCost - (groundResult.capacityDeliveryPremium ?? 0) - (groundResult.timeToEnergizePenalty ?? 0)),
      delayPenalty: groundResult.timeToEnergizePenalty ?? 0,
      capacityPremium: groundResult.capacityDeliveryPremium ?? 0,
      constraintMultiplier: groundResult.constraintMultiplier,
      total: groundTotalCost,
    },
    orbit: {
      effectiveSpecificPower: hybridResult.specificPowerMultipliers?.effective ?? (satellitePowerKW * 1000 / hybridResult.totalMassKg),
      massMultiplier: hybridResult.specificPowerMultipliers?.massMultiplier ?? 1.0,
      requiredAreaM2: hybridResult.thermalSystem.qPerM2_W ? (hybridResult.thermalSystem.wasteHeatW ?? hybridResult.thermalSystem.wasteHeatKw * 1000) / (hybridResult.thermalSystem.qPerM2_W ?? 1) : hybridResult.thermalSystem.physicalAreaM2,
      areaAvailableM2: hybridResult.thermalSystem.areaAvailableM2 ?? hybridResult.thermalSystem.physicalAreaM2,
      thermalCapFactor: hybridResult.thermalSystem.thermalCapFactor,
      total: realisticCostPerPflop,
    },
    allInvariantsPassed: (() => {
      // Check key invariants
      const siteCostCheck = Math.abs(groundResult.siteCost - ((groundResult.siteCapexAmortPerPflopYear ?? 0) + (groundResult.timeToEnergizePenalty ?? 0) + (groundResult.capacityDeliveryPremium ?? 0))) < 0.01;
      const thermalAreaCheck = hybridResult.thermalSystem.areaAvailableM2 ? Math.abs(hybridResult.thermalSystem.areaAvailableM2 - hybridResult.thermalSystem.physicalAreaM2) / hybridResult.thermalSystem.physicalAreaM2 < 0.01 : true;
      const specificPowerCheck = hybridResult.specificPowerMultipliers ? hybridResult.specificPowerMultipliers.effective <= hybridResult.specificPowerMultipliers.baseSpecificPower * 1.01 : true;
      const thermalCapCheck = hybridResult.thermalSystem.thermalCapFactor >= 0 && hybridResult.thermalSystem.thermalCapFactor <= 1;
      return siteCostCheck && thermalAreaCheck && specificPowerCheck && thermalCapCheck;
    })(),
  };

  return {
    year,
    mode: params.isStaticMode ? 'STATIC' : 'DYNAMIC',
    sanityPanel,
    ground: {
      electricityPricePerMwh: groundElectricityPricePerMwh,
      pue: effectivePueGround,
      capacityFactor: capacityFactorGround,
      // HARD ASSERT: All ground efficiency fields must be populated and finite
      gflopsPerWatt: (() => {
        const value = groundEffectiveGflopsPerW;
        if (!isFinite(value) || value <= 0) {
          throw new Error(`ground.gflopsPerWatt is invalid: ${value}. actualGroundInput=${actualGroundInput}`);
        }
        return value;
      })(), // Effective (system) GFLOPS/W
      computeDefinition: (() => {
        // CRITICAL FIX: Validate all computeDefinition fields to catch unit corruption
        const peak = validateGflopsPerWatt(
          groundEfficiencyResult.debug.chipPeakGflopsPerW,
          'ground.computeDefinition.peakGflopsPerWatt'
        );
        const effective = validateGflopsPerWatt(
          groundEfficiencyResult.debug.effectiveGflopsPerW,
          'ground.computeDefinition.effectiveGflopsPerWatt'
        );
        const utilization = groundEfficiencyResult.debug.utilizationFactor;
        
        if (!isFinite(utilization) || utilization <= 0 || utilization > 1) {
          throw new Error(`ground.computeDefinition.utilizationFactor is invalid: ${utilization}`);
        }
        
        return {
          chipName: 'NVIDIA H100 SXM',
          precision: 'FP16',
          peakGflopsPerWatt: peak,
          utilizationFactor: utilization,
          effectiveGflopsPerWatt: effective,
          notes: 'Datacenter deployment, system-level efficiency',
        };
      })(),
      energyCostPerPflopYear: (() => {
        const value = groundResult.energyCost;
        if (!isFinite(value) || value < 0) {
          throw new Error(
            `ground.energyCostPerPflopYear is invalid: ${value}. ` +
            `Check: groundEffectiveGflopsPerW=${groundEffectiveGflopsPerW}, ` +
            `groundElectricityPricePerMwh=${groundElectricityPricePerMwh}, ` +
            `effectivePueGround=${effectivePueGround}`
          );
        }
        return value;
      })(), // Raw electricity (NO constraint multiplier)
      siteCostPerPflopYear: (() => {
        const value = groundResult.siteCost;
        if (!isFinite(value) || value < 0) {
          throw new Error(`ground.siteCostPerPflopYear is invalid: ${value}`);
        }
        return value;
      })(), // Site costs = sum of components (INVARIANT)
      siteCapexAmortPerPflopYear: groundResult.siteCapexAmortPerPflopYear ?? (groundResult.siteCost - (groundResult.capacityDeliveryPremium ?? 0) - (groundResult.timeToEnergizePenalty ?? 0)), // Pure capex amortization
      capacityDeliveryPremium: groundResult.capacityDeliveryPremium ?? 0, // Explicit capacity/delivery premium (independent)
      timeToEnergizePenalty: groundResult.timeToEnergizePenalty ?? 0, // Queue delay penalty (WACC-based, independent)
      hardwareCapexPerPflopYear: groundResult.hardwareCost,
      constraintMultiplier: 1.0, // NOT APPLIED - kept for backward compat only
      constraintBreakdown: {
        ...constraintBreakdown,
        capacityDeliveryMultiplier: 1.0, // Not applied
      },
      constraints: (groundResult.constraints ? {
        ...groundResult.constraints,
        method: 'adders' as const,
      } : {
        method: 'adders' as const,
        capacityDeliveryPremium: (groundResult.capacityDeliveryPremium || 0),
        delayPenalty: (groundResult.timeToEnergizePenalty || 0),
        appliedMultipliers: {
          constraintMultiplierUsed: false,
          energyMultiplierUsed: false,
          siteMultiplierUsed: false,
        },
      }) as { method: 'adders'; capacityDeliveryPremium: number; delayPenalty: number; appliedMultipliers: { constraintMultiplierUsed: boolean; energyMultiplierUsed: boolean; siteMultiplierUsed: boolean; }; debug?: any },
      supplyMetrics: (groundResult as any).supplyMetrics,
      constraintComponents: (groundResult as any).constraintComponents,
      totalCostPerPflopYear: (() => {
        const value = groundTotalCost;
        if (!isFinite(value) || value <= 0) {
          throw new Error(
            `ground.totalCostPerPflopYear is invalid: ${value}. ` +
            `Components: energy=${groundResult.energyCost}, site=${groundResult.siteCost}, hardware=${groundResult.hardwareCost}, ` +
            `groundEffectiveGflopsPerW=${groundEffectiveGflopsPerW}, actualGroundInput=${actualGroundInput}`
          );
        }
        return value;
      })(),
      gpuHourPricing: {
        basic: groundGpuHour(SLA_TIERS.basic),
        standard: groundGpuHour(SLA_TIERS.standard),
        premium: groundGpuHour(SLA_TIERS.premium),
      },
      tokenPricing: groundTokens,
      smrEnabled: groundResult.smrEnabled,
      smrRampFactor: groundResult.smrRampFactor,
      effectiveElectricityCost: groundResult.effectiveElectricityCost,
      constraintRelief: groundResult.constraintRelief
    },
    orbit: {
      lcoePerMwh: (hybridResult.powerSystem.totalCostUsd) / (satellitePowerKW * PHYSICS_CONSTANTS.HOURS_PER_YEAR * lifetimeYears * hybridResult.capacityFactor / 1000),
      pue: pueOrbital,
      capacityFactor: hybridResult.capacityFactor,
      capacityFactorProvenance: hybridResult.computePayload?.capacityFactorProvenance, // Debug: CF breakdown
      gflopsPerWatt: orbitEffectiveGflopsPerW, // Delivered GFLOPS/W (systemEffective × thermalCap × radiationDerate × availability)
      computeDefinition: {
        chipName: 'H100-equivalent (rad-tolerant)',
        precision: 'FP16',
        peakGflopsPerWatt: validateGflopsPerWatt(
          orbitPeakGflopsPerWatt,
          'orbit.computeDefinition.peakGflopsPerWatt'
        ),
        utilizationFactor: orbitalEfficiencyResult.debug.utilizationFactor,
        effectiveGflopsPerWatt: orbitSystemEffectiveGflopsPerWatt, // System-effective = peak * utilization / systemOverheadFactor (SYSTEM-LEVEL EFFECTIVE)
        // deliveredGflopsPerWatt is stored in orbit.computeEfficiency.gflopsPerWatt, not here
        notes: 'Commercial rad-tolerant variant. peakGflopsPerWatt = chip peak. effectiveGflopsPerWatt = peak * utilization / systemOverheadFactor (system-level effective). deliveredGflopsPerWatt = systemEffective × thermalCapFactor × radiationDerate × availability',
      },
      computeEfficiencyProvenance: {
        peakGflopsPerWatt: orbitalEfficiencyResult.debug.chipPeakGflopsPerW,
        utilizationFactor: orbitalEfficiencyResult.debug.utilizationFactor,
        systemOverheadFactor: orbitalEfficiencyResult.debug.systemOverheadFactor,
        effectiveGflopsPerWatt: orbitalEfficiencyResult.debug.effectiveGflopsPerW,
      }, // Debug: GFLOPS/W breakdown
      launchCostPerKg: launchCostPerKg,
      specificPowerWPerKg: hybridResult.specificPowerWPerKg, // Deprecated: use specificPower_subsystem_WPerKg
      specificPower_subsystem_WPerKg: hybridResult.specificPowerWPerKg, // Subsystem-level (solar array only)
      specificPower_effective_WPerKg: hybridResult.specificPowerMultipliers?.effective ?? scalingResult.effectiveSpecificPower, // Effective spacecraft-level (from multipliers calculation)
      // Use specificPowerMultipliers from hybridResult (calculated in orbitalPhysics.ts with correct mass fraction accounting)
      specificPowerMultipliers: hybridResult.specificPowerMultipliers,
      energyCostPerPflopYear: orbitalBreakdown.power,
      hardwareCostPerPflopYear: orbitalBreakdown.compute,
      launchCostPerPflopYear: orbitalBreakdown.launch,
      radiationMultiplier: 1.0,
      thermalCapFactor: hybridResult.thermalSystem.thermalCapFactor,
      congestionCostPerPflopYear: orbitalBreakdown.congestion,
      totalCostPerPflopYear: realisticCostPerPflop, 
      thermalCapped: hybridResult.thermalSystem.thermalCapped,
      computePowerKw: targetComputeKw, // Total constellation compute power
      maxRejectableKw: hybridResult.thermalSystem.maxRejectableKw || hybridResult.thermalSystem.wasteHeatKw * 1.25,
      collisionRisk: congestion.collisionRisk,
      bodyMountedAreaM2: 0,
      deployableAreaM2: hybridResult.thermalSystem.physicalAreaM2,
      totalRadiatorAreaM2: hybridResult.thermalSystem.physicalAreaM2,
      radiatorCostPerPflopYear: (hybridResult.thermalSystem.totalCostUsd * constellationCostMultiplier) / totalEffectivePflops / lifetimeYears,
      radiatorMassKg: hybridResult.thermalSystem.totalMassKg,
      optimisticCostPerPflop: orbitalBreakdown.power + orbitalBreakdown.compute + orbitalBreakdown.bus,
      radiationShieldingCost: orbitalBreakdown.radiation,
      thermalSystemCost: orbitalBreakdown.thermal,
      replacementRateCost: orbitalBreakdown.ops,
      eccOverheadCost: 0,
      redundancyCost: 0,
      realisticCostPerPflop,
      hybridBreakdown: orbitalBreakdown,
      gpuHourPricing: {
        basic: orbitalGpuHour(SLA_TIERS.basic),
        standard: orbitalGpuHour(SLA_TIERS.standard),
        premium: orbitalGpuHour(SLA_TIERS.premium),
      },
      tokenPricing: orbitalTokens,
      radiationDegradation: {
        annualFailureRate: useRadHardChips ? 0.09 : 0.15,
        effectiveComputePercent: hybridResult.degradationFactor,
        eccOverheadPct: 0.05,
        applied: true
      },
      powerSystemType: hybridResult.powerSystemType,
      scalingPenalty: scalingResult.scalingPenalty,
      effectiveSpecificPower: scalingResult.effectiveSpecificPower,
      fusionDetails: hybridResult.fusionDetails,
      
      // Constellation sizing
      constellation: {
        design: {
          numSatellites: constellation.numSatellites,
          computePerSatKw: constellation.computePerSatKw,
          massPerSatKg: massPerSatKg,
          radiatorAreaPerSatM2: constellation.radiatorAreaPerSatM2,
        },
        launch: {
          satsPerLaunch: constellation.satsPerLaunch,
          launchesRequired: constellation.launchesRequired,
          totalMassKg: effectiveTotalMassKg,
        },
        scaling: {
          constellationOverhead: constellation.constellationOverhead,
          scalingEfficiency: constellation.scalingEfficiency,
        },
        warnings: constellation.warnings,
      },
      
      // Debug blocks for analysis - explicitly track all efficiency levels
      // Single source of truth: define orbit.computeEfficiencyLevels each year
      // Note: computeEfficiencyLevels is stored in metadata, not directly on orbit
      effectiveComputeMultipliers: {
        thermalCapFactor: hybridResult.thermalSystem.thermalCapFactor,
        radiationDerate: hybridResult.degradationFactor || 1.0,
        availability: hybridResult.capacityFactor || 1.0,
        utilization: orbitalEfficiencyResult.debug.utilizationFactor,
      },
      costShares: (() => {
        const total = realisticCostPerPflop;
        return {
          launch: (orbitalBreakdown.launch / total) * 100,
          power: (orbitalBreakdown.power / total) * 100,
          compute: (orbitalBreakdown.compute / total) * 100,
          thermal: (orbitalBreakdown.thermal / total) * 100,
          bus: (orbitalBreakdown.bus / total) * 100,
          ops: (orbitalBreakdown.ops / total) * 100,
          networking: (orbitalBreakdown.networking / total) * 100,
          groundSegment: (orbitalBreakdown.regulatory / total) * 100, // Regulatory includes ground segment
        };
      })(),
      localSensitivity: (() => {
        // Calculate local sensitivity: dCost/dParameter (approximate derivatives)
        
        // dCost_dLaunch: launch cost scales linearly with launchCostPerKg
        const dCost_dLaunch = orbitalBreakdown.launch / launchCostPerKg;
        
        // dCost_dSpecificPower: power cost scales inversely with specific power (negative)
        const dCost_dSpecificPower = -(orbitalBreakdown.power / trajSpecificPower);
        
        // dCost_dGflopsPerW: power cost scales inversely with GFLOPS/W (negative)
        const dCost_dGflopsPerW = -(orbitalBreakdown.power / orbitEffectiveGflopsPerW);
        
        // dCost_dFailureRate: ops cost scales with failure rate
        const baseFailureRate = useRadHardChips ? 0.09 : 0.15;
        const dCost_dFailureRate = orbitalBreakdown.ops / baseFailureRate;
        
        // dCost_dPue: power cost scales linearly with PUE
        const dCost_dPue = orbitalBreakdown.power / pueOrbital;
        
        return {
          dCost_dLaunch,
          dCost_dSpecificPower,
          dCost_dGflopsPerW,
          dCost_dFailureRate,
          dCost_dPue,
        };
      })(),
    },
    edgeInference,
    crossover: realisticCostPerPflop < groundTotalCost,
    crossoverDetails: {
      gpuHourCrossover,
      tokenCrossover: orbitalTokens.llama70B.costPer1kTokens < groundTokens.llama70B.costPer1kTokens,
      marketPosition: gpuHourCrossover 
        ? `Orbital ${((1 - orbitalGpuHour(SLA_TIERS.standard).pricePerGpuHour / groundGpuHour(SLA_TIERS.standard).pricePerGpuHour) * 100).toFixed(1)}% cheaper`
        : `Ground ${((1 - groundGpuHour(SLA_TIERS.standard).pricePerGpuHour / orbitalGpuHour(SLA_TIERS.standard).pricePerGpuHour) * 100).toFixed(1)}% cheaper`,
    },
    costAccountingValid,
    costAccountingErrorPct,
    metadata: {
      groundUnits: [
        {
          metric: 'gflopsPerWatt',
          unit: 'GFLOPS/W',
          level: 'system',
          notes: 'Ground system-level efficiency including memory, network, power delivery overhead',
        },
      ],
      orbitUnits: [
        {
          metric: 'gflopsPerWatt',
          unit: 'GFLOPS/W',
          level: 'delivered',
          notes: 'Orbital delivered efficiency: systemEffective × thermalCapFactor × radiationDerate × availability',
        },
      ],
      units: [
        {
          metric: 'gflopsPerWatt',
          unit: 'GFLOPS/W',
          level: 'system',
          notes: 'System-level efficiency including memory, network, power delivery overhead',
        },
        {
          metric: 'costPerPflopYear',
          unit: 'USD/PFLOP-year',
          level: 'infrastructure',
          notes: 'Total cost to operate 1 PFLOP of sustained compute for one year',
        },
        {
          metric: 'pricePerGpuHour',
          unit: 'USD/GPU-hour',
          level: 'market',
          notes: 'Market price with SLA, including margin and risk buffer',
        },
        {
          metric: 'costPer1kTokens',
          unit: 'USD/1K tokens',
          level: 'application',
          notes: 'Inference cost for specified model size (70B or 405B)',
        },
      ],
      debug: {
        groundLifetime: groundLifetime,
        gpuFailureRateAnnual: params.gpuFailureRateAnnual,
        totalCostExcludesDelayPenalty: true, // Headline cost excludes delay penalty (handled via capacity gating)
        totalCostEffectiveIncludesDelayPenalty: groundResult.totalCostPerPflopYearEffective !== undefined,
      },
      computeEfficiency: {
        gflopsPerWatt: orbitEffectiveGflopsPerW, // Delivered efficiency (alias)
        efficiencyLevel: 'delivered', // Changed from 'system' to 'delivered'
        validation: {
          // CRITICAL: Use deliveredValidation as primary - it compares like-for-like
          // Only fail if deliveredValidation fails (ratio mismatch) OR efficiencyValidation fails (range check)
          // consistencyCheck is for power/compute consistency, not efficiency validation
          valid: efficiencyValidation.valid && deliveredValidation.valid,
          warning: efficiencyValidation.warning || deliveredValidation.warning || undefined, // Only efficiency or delivered mismatch warnings
          expectedDelivered: deliveredValidation.expectedDelivered,
          delivered: deliveredValidation.delivered,
          ratio: deliveredValidation.ratio,
          factorsUsed: deliveredValidation.factorsUsed,
        }
      },
      // Chart inputs for power buildout constraints (replaces energyCostComparison)
      chartInputs: {
        powerBuildout: {
          demandGw: ('buildoutDebug' in groundResult ? groundResult.buildoutDebug?.demandGW : undefined) ?? 
                    ('supplyMetrics' in groundResult ? groundResult.supplyMetrics?.demandGw : undefined) ?? 0,
          supplyGw: ('supplyMetrics' in groundResult ? groundResult.supplyMetrics?.capacityGw : undefined) ?? 0,
          maxBuildRateGwYear: ('supplyMetrics' in groundResult ? groundResult.supplyMetrics?.maxBuildRateGwYear : undefined) ?? 
                              ('buildoutDebug' in groundResult ? groundResult.buildoutDebug?.buildRateGWyr : undefined) ?? 0,
          pipelineGw: ('supplyMetrics' in groundResult ? groundResult.supplyMetrics?.pipelineGw : undefined) ?? 0,
          backlogGw: ('backlogGw' in groundResult ? groundResult.backlogGw : undefined) ?? 
                     ('buildoutDebug' in groundResult ? groundResult.buildoutDebug?.backlogGW : undefined) ?? 0,
          avgWaitYears: ('avgWaitYears' in groundResult ? groundResult.avgWaitYears : undefined) ?? 
                        ('buildoutDebug' in groundResult ? groundResult.buildoutDebug?.timeToPowerYears : undefined) ?? 0,
        },
      }
    }
  };
}
