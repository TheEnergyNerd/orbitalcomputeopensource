/**
 * Ground Constraint Penalties Model
 * 
 * Calculates WACC-based penalties and multipliers from backlog/wait time:
 * - timeToEnergizePenaltyPerPflopYear: WACC carry + lost margin
 * - siteMultiplier: land + interconnect scarcity
 * - pueMultiplier: cooling/water stress
 */

import { GroundSupplyState } from './ground_queue_model';

/**
 * Hill function: saturating sigmoid-like curve
 * @param x Input value
 * @param x50 Half-saturation point
 * @param n Hill coefficient (steepness)
 * @returns Value between 0 and 1
 */
function hill(x: number, x50: number, n: number): number {
  if (x <= 0) return 0;
  const xn = Math.pow(x, n);
  const x50n = Math.pow(x50, n);
  return xn / (x50n + xn);
}

/**
 * Threshold Hill function: 0 until x exceeds x0, then Hill on the excess
 * @param x Input value
 * @param x0 Threshold (must exceed this before Hill activates)
 * @param x50 Half-saturation point for excess
 * @param n Hill coefficient
 * @returns Value between 0 and 1
 */
function thresholdHill(x: number, x0: number, x50: number, n: number): number {
  const excess = Math.max(0, x - x0);
  return hill(excess, x50, n);
}

export interface GroundConstraintPenalties {
  // Time-to-energize penalty (WACC carry + lost margin)
  timeToEnergizePenaltyPerPflopYear: number;
  
  // Site multiplier (land + interconnect scarcity)
  siteMultiplier: number;
  
  // PUE multiplier (cooling/water stress)
  pueMultiplier: number;
  
  // Debug fields
  backlogGw: number;
  avgWaitYears: number;
  capexAtRiskPerMW: number;
  carryCostPerMW: number;
  lostMarginPerMW: number;
  // WACC debug fields
  waccBase?: number;
  waccEffective?: number;
}

/**
 * Calculate saturating scarcity rent using Hill function (prevents exponential blow-up)
 * 
 * @param waitYears Average wait time (years) - NO CLAMP applied
 * @param utilizationPct Utilization percentage (0-1) - optional threshold gate
 * @param waitThresholdYears Threshold for half-saturation (default 3.0)
 * @param rentMaxFracOfCapexAnnual Maximum rent as fraction of reference base (default 0.65)
 * @param rentShapeP Hill function shape parameter (default 2.0)
 * @returns Scarcity rent per PFLOP-year and debug fields
 */
export function calculateScarcityRent(
  waitYears: number,
  utilizationPct?: number,
  params?: {
    waitThresholdYears?: number; // w50 parameter for Hill function
    rentMaxFracOfCapexAnnual?: number; // rentMax parameter
    rentShapeP?: number; // n parameter for Hill function
  }
): {
  scarcityRentPerPflopYear: number;
  rentFrac: number;
  waitEffYears: number;
  // Debug fields
  scarcityHill: {
    h: number; // Hill function value
    rentFrac: number; // Rent fraction after applying rentMax
  };
  avgWaitYearsRaw: number; // Raw wait years (no clamp)
  avgWaitYearsClamped: number; // Same as raw (no clamp applied)
} {
  // THRESHOLD GATE: No scarcity rent until utilization > 85%
  const UTIL_THRESHOLD = 0.85;
  if (utilizationPct !== undefined && utilizationPct < UTIL_THRESHOLD) {
    return {
      scarcityRentPerPflopYear: 0,
      rentFrac: 0,
      waitEffYears: waitYears,
      scarcityHill: { h: 0, rentFrac: 0 },
      avgWaitYearsRaw: waitYears,
      avgWaitYearsClamped: waitYears,
    };
  }
  
  // THRESHOLD GATE: No scarcity rent until wait > 1 year
  if (waitYears < 1.0) {
    return {
      scarcityRentPerPflopYear: 0,
      rentFrac: 0,
      waitEffYears: waitYears,
      scarcityHill: { h: 0, rentFrac: 0 },
      avgWaitYearsRaw: waitYears,
      avgWaitYearsClamped: waitYears,
    };
  }
  
  // Hill function parameters: w50=3.0, n=2.0, rentMax=0.65
  const w50 = params?.waitThresholdYears ?? 3.0; // Half-saturation point (years) - increased from 2.0
  const n = params?.rentShapeP ?? 2.0; // Hill coefficient
  const rentMax = params?.rentMaxFracOfCapexAnnual ?? 0.65; // Max rent = 65% of reference base
  
  // Store raw wait years for debug (NO CLAMP)
  const avgWaitYearsRaw = waitYears;
  const avgWaitYearsClamped = waitYears; // No clamp - preserves scarcity signal
  
  // Hill function: h = (w/w50)^n / (1 + (w/w50)^n)
  // This saturates at 1 as wait increases, preventing exponential growth
  const w = avgWaitYearsClamped;
  const x = w / w50;
  const h = x > 0 ? Math.pow(x, n) / (1 + Math.pow(x, n)) : 0;
  
  // Rent fraction: max fraction of reference base
  const rentFrac = rentMax * h;
  
  // FIX: Use fixed reference base that doesn't decline with tech (market clearing price)
  // This ensures scarcity rent INCREASES with scarcity, not decreases
  const SCARCITY_RENT_REFERENCE_BASE = 6500; // $/PFLOP-yr (fixed market clearing reference)
  const scarcityRentPerPflopYear = rentFrac * SCARCITY_RENT_REFERENCE_BASE;
  
  return {
    scarcityRentPerPflopYear,
    rentFrac,
    waitEffYears: avgWaitYearsClamped,
    scarcityHill: {
      h,
      rentFrac,
    },
    avgWaitYearsRaw,
    avgWaitYearsClamped,
  };
}

/**
 * Calculate ground constraint penalties from supply state
 * 
 * @param state Current ground supply state
 * @param flopsPerWattGround GFLOPS/W for ground compute
 * @param pueGround PUE for ground datacenters
 * @param capacityFactorGround Capacity factor for ground
 * @param waccParams Optional WACC parameters for capital rationing
 * @returns Penalties and multipliers
 */
export function calculateGroundConstraintPenalties(
  state: GroundSupplyState,
  flopsPerWattGround: number,
  pueGround: number,
  capacityFactorGround: number,
  waccParams?: {
    baseWacc?: number;
    waccBacklogK?: number;
    waccBacklogExponent?: number;
    criticalBacklogGW?: number;
  }
): GroundConstraintPenalties {
  const backlogGw = state.backlogGw; // Pipeline is not backlog. If backlog is missing, treat as 0 and let chartInputs/buildoutDebug supply the real number elsewhere.
  const avgWaitYears = state.avgWaitYears;
  const maxBuildRateGwYear = state.maxBuildRateGwYear;
  const utilizationPct = state.utilizationPct;
  
  // Convert GW to MW
  const backlogMw = backlogGw * 1000;
  
  // UNIT GUARD: Fix units mismatch (flopsPerWattGround might be TFLOPS/W instead of GFLOPS/W)
  let gflopsPerWatt = flopsPerWattGround;
  if (flopsPerWattGround < 50) {
    // Likely TFLOPS/W (e.g., 2 TFLOPS/W), convert to GFLOPS/W
    gflopsPerWatt = flopsPerWattGround * 1000;
    if (process.env.NODE_ENV === 'development') {
      console.warn(`[UNIT CONVERSION] flopsPerWattGround=${flopsPerWattGround} < 50, treating as TFLOPS/W and converting to ${gflopsPerWatt} GFLOPS/W`);
    }
  }
  // Clamp insane values
  if (gflopsPerWatt > 20000) {
    if (process.env.NODE_ENV === 'development') {
      console.warn(`[UNIT CLAMP] gflopsPerWatt=${gflopsPerWatt} > 20000, clamping to 20000`);
    }
    gflopsPerWatt = 20000;
  }
  
  // WACC parameters (capital rationing: WACC rises with backlog)
  const baseWacc = waccParams?.baseWacc ?? 0.10; // 10% base WACC
  const waccBacklogK = waccParams?.waccBacklogK ?? 0.5; // Scaling factor
  const waccBacklogExponent = waccParams?.waccBacklogExponent ?? 1.2; // Exponent for convexity
  const criticalBacklogGW = waccParams?.criticalBacklogGW ?? 50; // Critical backlog threshold
  
  // Compute effective WACC (rises with backlog)
  // waccEffective = baseWacc * (1 + waccBacklogK * (backlogGW/criticalBacklogGW)^waccBacklogExponent)
  const backlogRatio = Math.max(0, backlogGw / criticalBacklogGW);
  const waccMultiplier = 1 + waccBacklogK * Math.pow(backlogRatio, waccBacklogExponent);
  const waccEffective = baseWacc * waccMultiplier;
  
  // Constants
  const WACC = 0.10;
  const CAPEX_PER_MW = 3_000_000; // $3M/MW capex at risk
  
  // Replace the huge lost-margin number with something defensible + capped
  const LOST_MARGIN_PER_MW_YEAR = 600_000;      // was 2,000,000, now 600k
  const LOST_MARGIN_CAP_PER_MW = 1_800_000;     // cap total lost margin component
  
  const MAX_WAIT_FOR_CARRY = 4;                 // years, cap compounding horizon
  const MAX_TOTAL_PENALTY_PER_MW_YEAR = 2_500_000; // hard cap so it never goes vertical
  
  const BASE_SITE_COST_PER_MW_YEAR = 150_000; // $150k/MW-year base site cost
  const BASE_PUE = 1.3; // Baseline PUE
  
  // Reference capex amort for capping (used to prevent penalty from dominating)
  const CAPEX_AMORT_PER_PFLOP_YEAR_REFERENCE = 1500; // Base site cost per PFLOP-year
  
  // 1. Bounded Delay Penalty: Linear WACC carry (NOT exponential)
  // delayPenaltyPerPflopYear = capexPerPflopYear * wacc * avgWaitYears
  // Cap it: delayPenaltyPerPflopYear = min(delayPenaltyPerPflopYear, delayCapFrac * capexPerPflopYear)
  let timeToEnergizePenaltyPerPflopYear = 0;
  let capexAtRiskPerMW = 0;
  let carryCostPerMW = 0;
  let lostMarginPerMW = 0;
  
  // Convert capex to per-PFLOP-year for penalty calculation
  const pflopsPerMW = (gflopsPerWatt * capacityFactorGround) / pueGround;
  const CAPEX_PER_PFLOP_YEAR = (CAPEX_PER_MW / Math.max(pflopsPerMW, 1e-6));
  
  if (avgWaitYears > 0.01) {
    // Linear delay penalty: WACC * capex * waitYears (NOT exponential)
    const delayPenaltyUncapped = CAPEX_PER_PFLOP_YEAR * baseWacc * avgWaitYears;
    
    // Cap at delayCapFrac of capex (0.5-1.0 range)
    const DELAY_CAP_FRAC = 0.75; // Cap at 75% of capex
    timeToEnergizePenaltyPerPflopYear = Math.min(delayPenaltyUncapped, DELAY_CAP_FRAC * CAPEX_PER_PFLOP_YEAR);
    
    // For debug fields (MW-based)
    capexAtRiskPerMW = CAPEX_PER_MW;
    carryCostPerMW = CAPEX_PER_MW * baseWacc * avgWaitYears;
    lostMarginPerMW = 0; // Not used in bounded model
  }
  
  // 2. Site Multiplier: land + interconnect scarcity (Hill-shaped, thresholded)
  // Backlog rent: Hill on avgWaitYears (this creates the "hump" shape)
  const waitRent = hill(avgWaitYears, 2.0, 2.0);          // 50% rent at 2 years
  const backlogRent = hill(backlogGw, 30, 2.0);           // kicks in around ~30 GW backlog
  
  // Utilization rent: strictly 0 until > 85% utilization
  const utilRent = thresholdHill(utilizationPct, 0.85, 0.05, 2.0); // x50 is 5% above threshold
  
  const landScarcityFactor = 1 + 0.35 * backlogRent;
  const interconnectScarcityFactor = 1 + 0.45 * Math.max(waitRent, utilRent);
  
  // Site multiplier should be ~1 when backlog=0, wait=0, util<0.85
  const siteMultiplier = landScarcityFactor * interconnectScarcityFactor;
  
  // 3. PUE Multiplier: cooling/water stress (thresholded)
  const coolingStressFactor = 1 + 0.25 * utilRent;
  const waterStressFactor = 1 + 0.20 * backlogRent;
  const pueMultiplier = 1 + (coolingStressFactor - 1) + (waterStressFactor - 1); // Additive stress
  
  return {
    timeToEnergizePenaltyPerPflopYear,
    siteMultiplier,
    pueMultiplier,
    backlogGw,
    avgWaitYears,
    capexAtRiskPerMW,
    carryCostPerMW,
    lostMarginPerMW,
    waccBase: baseWacc,
    waccEffective,
  };
}

/**
 * Calculate Hill-based scarcity premium from queue pressure + utilization
 * 
 * Scarcity multiplier (NOT exponential):
 * - queuePressure = backlogGW / (backlogGW + K_backlogGW) where K_backlogGW ~ 50-150
 * - utilPressure = 1 / (1 + exp(-k*(utilizationPct - u0))) with u0 ~ 0.85-0.92, k ~ 12-20
 * - scarcity = 1 + rentFracMax * (queuePressure^h) * utilPressure
 * 
 * @param backlogGw Backlog in GW
 * @param utilizationPct Utilization percentage (0-1)
 * @param baseCostPerPflopYear Base cost per PFLOP-year (for rent calculation)
 * @param params Optional parameters
 * @returns Scarcity rent and debug fields
 */
export function calculateHillScarcityPremium(
  backlogGw: number,
  utilizationPct: number,
  baseCostPerPflopYear: number,
  params?: {
    kBacklogGw?: number; // K_backlogGW ~ 50-150
    u0?: number; // u0 ~ 0.85-0.92
    k?: number; // k ~ 12-20
    rentFracMax?: number; // rentFracMax ~ 0.3-0.8
    h?: number; // h ~ 1-3 (steepness)
  }
): {
  scarcityRentPerPflopYear: number;
  scarcityMultiplier: number;
  queuePressure: number;
  utilPressure: number;
} {
  const kBacklogGw = params?.kBacklogGw ?? 100; // K_backlogGW ~ 50-150
  const u0 = params?.u0 ?? 0.88; // u0 ~ 0.85-0.92 (scarcity starts at 88% utilization)
  const k = params?.k ?? 16; // k ~ 12-20 (steepness of utilization curve)
  const rentFracMax = params?.rentFracMax ?? 0.5; // rentFracMax ~ 0.3-0.8 (max rent fraction)
  const h = params?.h ?? 2.0; // h ~ 1-3 (steepness of queue pressure)
  
  // Queue pressure: backlogGW / (backlogGW + K_backlogGW)
  // Saturates at 1 as backlog grows
  const queuePressure = backlogGw / (backlogGw + kBacklogGw);
  
  // Utilization pressure: 1 / (1 + exp(-k*(utilizationPct - u0)))
  // Sigmoid that rises sharply around u0
  const utilExcess = utilizationPct - u0;
  const utilPressure = 1 / (1 + Math.exp(-k * utilExcess));
  
  // Scarcity multiplier: 1 + rentFracMax * (queuePressure^h) * utilPressure
  const scarcityMultiplier = 1 + rentFracMax * Math.pow(queuePressure, h) * utilPressure;
  
  // Scarcity rent = base cost * (scarcity - 1)
  const scarcityRentPerPflopYear = baseCostPerPflopYear * (scarcityMultiplier - 1);
  
  return {
    scarcityRentPerPflopYear,
    scarcityMultiplier,
    queuePressure,
    utilPressure,
  };
}

