"use client";

import { useSandboxStore } from "../store/sandboxStore";
import { getOrbitalComputeKw } from "../lib/sim/orbitConfig";
import { formatSigFigs, formatDecimal } from "../lib/utils/formatNumber";
import OrbitalAdvantagePanelV2 from "./OrbitalAdvantagePanelV2";
import MissionBar from "./MissionBar";
import OrbitScore from "./OrbitScore";
import SimpleControls from "./SimpleControls";

/**
 * SimpleView - Clean, minimal view showing only:
 * - Top controls (orbital share, pod tech, launch capacity, ground energy)
 * - Globe
 * - Metrics panel (2x2 grid)
 * - Deployment summary sentence
 */
export default function SimpleView() {
  const { simState } = useSandboxStore();

  if (!simState) {
    return <div className="text-xs text-gray-500">Loading...</div>;
  }

  // Calculate deployment metrics
  const podsPerMonth = (simState.resources.pods?.prodPerMin ?? 0) * 60 * 24 * 30;
  const launchesPerMonth = (simState.resources.launches?.prodPerMin ?? 0) * 60 * 24 * 30;
  const launchesPerYear = launchesPerMonth * 12;
  const podsPerYear = podsPerMonth * 12;

  // Calculate orbital share
  const podsInOrbit = Math.floor(simState.podsInOrbit);
  const orbitalComputeKw = getOrbitalComputeKw(
    podsInOrbit,
    simState.orbitalPodSpec,
    simState.podDegradationFactor
  );
  const targetComputeKw = simState.targetComputeKw;
  const orbitalShare = targetComputeKw > 0 ? (orbitalComputeKw / targetComputeKw) * 100 : 0;

  return (
    <div className="fixed inset-0 flex flex-col pointer-events-none">
      {/* Mission Bar - Top */}
      <MissionBar />
      
      {/* Orbit Score - Below Mission Bar */}
      <OrbitScore />

      {/* Simple Controls - 3-4 global sliders */}
      <SimpleControls />

      {/* Globe - Center (already rendered in page.tsx) */}
      {/* Metrics Panel - Bottom Center */}
      <OrbitalAdvantagePanelV2 />

      {/* Deployment Summary - Bottom */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-30 panel max-w-2xl pointer-events-auto">
        <p className="text-xs text-gray-300 text-center mb-2">
          To reach <span className="text-white font-semibold">{formatDecimal(orbitalShare, 1)}%</span> orbital share, 
          you're deploying about <span className="text-white font-semibold">{formatDecimal(podsPerYear, 0)}</span> pods 
          and <span className="text-white font-semibold">{formatDecimal(launchesPerYear, 0)}</span> launches/year.
        </p>
        <div className="text-center">
          <button
            onClick={() => {
              // Switch to Advanced tab via ModeTabs
              const event = new CustomEvent('switchMode', { detail: 'advanced' });
              window.dispatchEvent(event);
            }}
            className="text-[10px] text-gray-400 hover:text-cyan-400 underline pointer-events-auto"
          >
            Deep dive: industrial / advanced view →
          </button>
        </div>
      </div>
    </div>
  );
}

