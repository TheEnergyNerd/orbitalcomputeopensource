"use client";

import React, { useState, useMemo, useCallback, useEffect, useRef } from 'react';
import { useSimulationStore } from '../../store/simulationStore';
import { useOrbitSim } from '../../state/orbitStore';
import { getDebugStateEntry } from '../../lib/orbitSim/debugState';
import { ThermalViz, BackhaulViz, MaintenanceViz, CostViz } from './PhysicsViz';
import { ComputeViz, PowerViz } from './PhysicsVizExtra';

/**
 * PhysicsSandbox - Interactive physics calculator with cyberpunk aesthetic
 * 
 * Usage:
 * <PhysicsSandbox 
 *   baselineData={perScenario.BASELINE} 
 *   currentYear="2033"
 *   onApplyToGlobe={(params) => { update globe }}
 * />
 */

// ============================================================================
// PHYSICS CALCULATIONS
// ============================================================================

const STEFAN_BOLTZMANN = 5.67e-8;
const T_SINK = 200;
const BITS_PER_FLOP = 0.1;

interface PhysicsParams {
  year?: string;
  radiatorAreaPerSat: number;
  emissivity: number;
  radiatorTempC: number;
  busPowerKw: number;
  mooresLawDoublingYears: number;
  opticalTerminals: number;
  linkCapacityGbps: number;
  groundStations: number;
  fleetSize: number;
  failureRatePercent: number;
  servicerDrones: number;
  launchesPerYear: number;
  satsPerLaunch: number;
  launchCostPerKg: number;
  launchCostImprovementRate?: number; // Annual improvement rate (e.g., 0.15 = 15% per year)
  satelliteBaseCost: number;
  processNode?: number;
  chipTdp?: number;
  radiationHardening?: number;
  memoryPerNode?: number;
  solarEfficiency?: number;
  degradationRate?: number;
  batteryBuffer?: number;
  powerMargin?: number;
  batteryDensity?: number;
  batteryCost?: number;
  structuralPenaltyExponent?: number; // Structural scaling exponent (1.0 = linear, 1.2 = 20% penalty)
  structuralThresholdKW?: number; // Power level where structural penalty kicks in
}

interface PhysicsResults {
  heatRejectionPerSat_kW: number;
  heatGenPerSat_kW: number;
  thermalMargin: number;
  thermalOK: boolean;
  radiatorUtilization: number;
  gflopsPerWatt: number;
  computePerSat_TFLOPS: number;
  fleetCompute_PFLOPS: number;
  computeOK: boolean;
  computeMemoryRatio: number;
  backhaulPerSat_Gbps: number;
  backhaulUtilization: number;
  backhaulOK: boolean;
  groundStationCoverage: number;
  failuresPerYear: number;
  repairsPerYear: number;
  replacementsPerYear: number;
  netAttrition: number;
  survivalRate10yr: number;
  maintenanceOK: boolean;
  totalMassPerSat_kg: number;
  radiatorMass_kg: number;
  solarMass_kg: number;
  computeMass_kg: number;
  batteryMass_kg: number;
  annualOpex: number;
  costPerPflop: number;
  carbonIntensity: number;
  solarArraySize_m2: number;
  degradationAfter10yr: number;
  effectivePowerYear10: number;
  batteryCapacity_kWh: number;
  powerOK: boolean;
  eclipseHandlingOK: boolean;
  allSystemsOK: boolean;
  // Structural scaling debug fields
  solarMassLinear_kg?: number;
  solarMassPenalized_kg?: number;
  solarPenaltyPercent?: number;
  radiatorMassLinear_kg?: number;
  radiatorMassPenalized_kg?: number;
  radiatorPenaltyPercent?: number;
}

/**
 * Calculate array mass with structural scaling penalty for large arrays
 */
function calculateArrayMassWithScaling(
  powerKW: number,
  baseMassPerKW: number,
  thresholdKW: number,
  exponent: number
): number {
  const referenceKW = thresholdKW;
  const referenceMass = referenceKW * baseMassPerKW;
  return referenceMass * Math.pow(powerKW / referenceKW, exponent);
}

const calculatePhysics = (params: PhysicsParams): PhysicsResults => {
  const T_rad_K = params.radiatorTempC + 273.15;
  const heatRejectionPerM2_kW = params.emissivity * STEFAN_BOLTZMANN * 
    (Math.pow(T_rad_K, 4) - Math.pow(T_SINK, 4)) / 1000;
  
  const heatRejectionPerSat_kW = heatRejectionPerM2_kW * params.radiatorAreaPerSat;
  const heatGenPerSat_kW = params.busPowerKw * 0.85;
  
  const thermalMargin = (heatRejectionPerSat_kW - heatGenPerSat_kW) / heatGenPerSat_kW;
  const thermalOK = thermalMargin > 0;
  const radiatorUtilization = Math.min(1, heatGenPerSat_kW / heatRejectionPerSat_kW);

  const yearsFrom2024 = parseInt(params.year || '2033') - 2024;
  const processNode = params.processNode ?? 5;
  const radiationHardening = params.radiationHardening ?? 1;
  const processScaling = Math.pow(0.7, (7 - processNode) / 2);
  const hardeningPenalty = [1.0, 0.7, 0.4][radiationHardening];
  const mooresLawMultiplier = Math.pow(2, yearsFrom2024 / params.mooresLawDoublingYears);
  const baseEfficiency = 3;
  const gflopsPerWatt = baseEfficiency * mooresLawMultiplier * processScaling * hardeningPenalty;
  
  const chipTdp = params.chipTdp ?? 300;
  const chipPowerPerSat = chipTdp * Math.ceil(params.busPowerKw / chipTdp * 0.7);
  const computePerSat_TFLOPS = (chipPowerPerSat * gflopsPerWatt) / 1000;
  
  const memoryPerNode = params.memoryPerNode ?? 128;
  const memoryBandwidth_TBs = memoryPerNode * 3.2 / 1000;
  const computeMemoryRatio = computePerSat_TFLOPS / memoryBandwidth_TBs;
  const computeOK = computeMemoryRatio < 500 && radiationHardening > 0;
  
  const solarEfficiency = params.solarEfficiency ?? 32;
  const solarPowerGenerated = params.busPowerKw / (solarEfficiency / 100);
  const solarArraySize_m2 = solarPowerGenerated / 0.2;
  const degradationRate = params.degradationRate ?? 1.5;
  const degradationAfter10yr = Math.pow(1 - degradationRate / 100, 10);
  const effectivePowerYear10 = params.busPowerKw * degradationAfter10yr;
  
  const batteryBuffer = params.batteryBuffer ?? 45;
  const batteryCapacity_kWh = (params.busPowerKw * batteryBuffer) / 60;
  const batteryDensity = params.batteryDensity ?? 300;
  const batteryMass_kg = batteryCapacity_kWh * 1000 / batteryDensity;
  const batteryCost = params.batteryCost ?? 120;
  const batteryCost_total = batteryCapacity_kWh * batteryCost;
  
  const powerMargin = params.powerMargin ?? 20;
  const eclipseHandlingOK = batteryBuffer >= 35 || powerMargin >= 25;
  const powerOK = degradationAfter10yr > 0.7 && eclipseHandlingOK;
  
  const backhaulPerSat_Gbps = params.opticalTerminals * params.linkCapacityGbps;
  const computeOutputPerSat_Gbps = computePerSat_TFLOPS * 1e12 * BITS_PER_FLOP / 1e9;
  const backhaulUtilization = Math.min(1, computeOutputPerSat_Gbps / backhaulPerSat_Gbps);
  const backhaulOK = backhaulUtilization < 0.95;
  
  const groundStationCoverage = Math.min(1, params.groundStations / 80);

  const failuresPerYear = params.fleetSize * (params.failureRatePercent / 100);
  const repairsPerYear = params.servicerDrones * 3;
  const replacementsPerYear = params.launchesPerYear * params.satsPerLaunch;
  
  const netAttrition = Math.max(0, failuresPerYear - repairsPerYear - replacementsPerYear);
  const survivalRate10yr = Math.pow(Math.max(0.01, 1 - (netAttrition / params.fleetSize)), 10);
  const maintenanceOK = netAttrition <= failuresPerYear * 0.1;

  // Structural scaling parameters
  const structuralPenaltyExponent = params.structuralPenaltyExponent ?? 1.2;
  const structuralThresholdKW = params.structuralThresholdKW ?? 50;
  
  // Calculate solar array mass with structural scaling
  const SOLAR_BASE_MASS_PER_KW = 5; // kg/kW at small scale
  const solarMassLinear_kg = params.busPowerKw * SOLAR_BASE_MASS_PER_KW;
  const solarMassPenalized_kg = calculateArrayMassWithScaling(
    params.busPowerKw,
    SOLAR_BASE_MASS_PER_KW,
    structuralThresholdKW,
    structuralPenaltyExponent
  );
  const solarMass_kg = solarMassPenalized_kg;
  const solarPenaltyPercent = ((solarMassPenalized_kg / solarMassLinear_kg) - 1) * 100;
  
  // Calculate radiator mass with structural scaling
  // Base mass per kW of heat rejection: ~10 kg/kW (radiators are heavier than solar)
  const RADIATOR_BASE_MASS_PER_KW = 10; // kg/kW at small scale
  const radiatorMassLinear_kg = heatGenPerSat_kW * RADIATOR_BASE_MASS_PER_KW;
  const radiatorMassPenalized_kg = calculateArrayMassWithScaling(
    heatGenPerSat_kW,
    RADIATOR_BASE_MASS_PER_KW,
    structuralThresholdKW,
    structuralPenaltyExponent
  );
  const radiatorMass_kg = radiatorMassPenalized_kg;
  const radiatorPenaltyPercent = ((radiatorMassPenalized_kg / radiatorMassLinear_kg) - 1) * 100;
  
  const computeMass_kg = (memoryPerNode * 0.5) + (chipPowerPerSat * 0.1);
  const structureMass_kg = 200;
  const shieldingMass_kg = 50 + radiationHardening * 75;
  const totalMassPerSat_kg = radiatorMass_kg + solarMass_kg + computeMass_kg + batteryMass_kg + structureMass_kg + shieldingMass_kg;

  const launchCostPerSat = totalMassPerSat_kg * params.launchCostPerKg;
  const satelliteCost = params.satelliteBaseCost + (computePerSat_TFLOPS * 1000) + batteryCost_total;
  const totalCostPerSat = launchCostPerSat + satelliteCost;
  
  const annualReplacementCost = netAttrition * totalCostPerSat;
  const servicerCost = params.servicerDrones * 500000;
  const groundStationCost = params.groundStations * 2000000;
  const annualOpex = annualReplacementCost + servicerCost + groundStationCost;
  
  const fleetCompute_PFLOPS = (params.fleetSize * computePerSat_TFLOPS) / 1000;
  const fleetCapex = params.fleetSize * totalCostPerSat;
  const costPerPflop = fleetCompute_PFLOPS > 0 ? (annualOpex + (fleetCapex / 10)) / fleetCompute_PFLOPS : 0;

  const launchCarbonPerKg = 50;
  const annualLaunchCarbon_tCO2 = (replacementsPerYear * totalMassPerSat_kg * launchCarbonPerKg) / 1000;
  const carbonIntensity = params.fleetSize > 0 && params.busPowerKw > 0 
    ? (annualLaunchCarbon_tCO2 * 1e6) / (params.fleetSize * params.busPowerKw * 8760)
    : 0;

  return {
    heatRejectionPerSat_kW,
    heatGenPerSat_kW,
    thermalMargin,
    thermalOK,
    radiatorUtilization,
    gflopsPerWatt,
    computePerSat_TFLOPS,
    fleetCompute_PFLOPS,
    backhaulPerSat_Gbps,
    backhaulUtilization,
    backhaulOK,
    groundStationCoverage,
    failuresPerYear,
    repairsPerYear,
    replacementsPerYear,
    netAttrition,
    survivalRate10yr,
    maintenanceOK,
    totalMassPerSat_kg,
    radiatorMass_kg,
    solarMass_kg,
    computeMass_kg,
    annualOpex,
    costPerPflop,
    carbonIntensity,
    solarArraySize_m2,
    degradationAfter10yr,
    effectivePowerYear10,
    batteryCapacity_kWh,
    batteryMass_kg,
    powerOK,
    eclipseHandlingOK,
    computeOK,
    computeMemoryRatio,
    allSystemsOK: thermalOK && backhaulOK && maintenanceOK && computeOK && powerOK,
    // Structural scaling debug fields
    solarMassLinear_kg,
    solarMassPenalized_kg,
    solarPenaltyPercent,
    radiatorMassLinear_kg,
    radiatorMassPenalized_kg,
    radiatorPenaltyPercent,
  };
};


const styles: Record<string, React.CSSProperties> = {
  container: {
    background: 'linear-gradient(180deg, rgba(10, 15, 28, 0.98) 0%, rgba(15, 23, 42, 0.95) 100%)',
    border: '1px solid rgba(0, 240, 255, 0.15)',
    borderRadius: '16px',
    padding: '32px',
    fontFamily: "'IBM Plex Mono', 'Fira Code', 'Courier New', monospace",
    position: 'relative',
    overflow: 'hidden',
  },
  
  // Animated background grid
  gridOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundImage: `
      linear-gradient(rgba(0, 240, 255, 0.03) 1px, transparent 1px),
      linear-gradient(90deg, rgba(0, 240, 255, 0.03) 1px, transparent 1px)
    `,
    backgroundSize: '40px 40px',
    pointerEvents: 'none',
  },
  
  // Scanning line animation
  scanLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '2px',
    background: 'linear-gradient(90deg, transparent, rgba(0, 240, 255, 0.4), transparent)',
    animation: 'scan 4s ease-in-out infinite',
    pointerEvents: 'none',
  },
  
  header: {
    display: 'flex',
    flexDirection: 'column',
    gap: '16px',
    marginBottom: '32px',
    position: 'relative',
    zIndex: 1,
  },
  
  headerTop: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    flexWrap: 'wrap',
    gap: '12px',
  },
  
  headerButtons: {
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: '12px',
    justifyContent: 'flex-end',
  },
  
  title: {
    color: '#00f0ff',
    fontSize: '13px',
    fontWeight: 600,
    textTransform: 'uppercase',
    letterSpacing: '3px',
    margin: 0,
    textShadow: '0 0 20px rgba(0, 240, 255, 0.5)',
  },
  
  subtitle: {
    color: '#64748b',
    fontSize: '11px',
    letterSpacing: '1px',
    marginTop: '8px',
  },
  
  button: {
    padding: '10px 20px',
    borderRadius: '4px',
    border: '1px solid rgba(0, 240, 255, 0.3)',
    background: 'rgba(0, 240, 255, 0.1)',
    color: '#00f0ff',
    fontSize: '11px',
    fontFamily: "'IBM Plex Mono', 'Courier New', monospace",
    fontWeight: 600,
    letterSpacing: '1px',
    textTransform: 'uppercase',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
  },
  
  buttonPrimary: {
    background: 'rgba(0, 240, 255, 0.2)',
    borderColor: '#00f0ff',
    boxShadow: '0 0 20px rgba(0, 240, 255, 0.3)',
  },
  
  section: {
    background: 'rgba(0, 10, 20, 0.5)',
    border: '1px solid rgba(0, 240, 255, 0.1)',
    borderRadius: '8px',
    padding: '24px',
    position: 'relative',
    zIndex: 1,
  },
  
  sectionHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px',
    paddingBottom: '12px',
    borderBottom: '1px solid rgba(0, 240, 255, 0.1)',
  },
  
  sectionTitle: {
    color: '#e2e8f0',
    fontSize: '11px',
    fontWeight: 600,
    textTransform: 'uppercase',
    letterSpacing: '2px',
    margin: 0,
  },
  
  sliderContainer: {
    marginBottom: '20px',
  },
  
  sliderLabel: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '8px',
  },
  
  sliderLabelText: {
    color: '#94a3b8',
    fontSize: '11px',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
  },
  
  sliderValue: {
    color: '#00f0ff',
    fontSize: '14px',
    fontWeight: 600,
    fontFamily: "'IBM Plex Mono', 'Courier New', monospace",
  },
  
  sliderTrack: {
    width: '100%',
    height: '4px',
    borderRadius: '2px',
    background: 'rgba(0, 240, 255, 0.1)',
    position: 'relative',
    cursor: 'pointer',
  },
  
  sliderHelp: {
    color: '#475569',
    fontSize: '10px',
    marginTop: '6px',
    fontStyle: 'italic',
  },
  
  statusBadge: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '6px',
    padding: '6px 12px',
    borderRadius: '4px',
    fontSize: '10px',
    fontWeight: 600,
    letterSpacing: '1px',
    textTransform: 'uppercase',
  },
  
  statusOK: {
    background: 'rgba(16, 185, 129, 0.15)',
    border: '1px solid rgba(16, 185, 129, 0.3)',
    color: '#10b981',
  },
  
  statusFail: {
    background: 'rgba(239, 68, 68, 0.15)',
    border: '1px solid rgba(239, 68, 68, 0.3)',
    color: '#ef4444',
    animation: 'pulse 2s ease-in-out infinite',
  },
  
  gauge: {
    width: '100%',
    height: '8px',
    borderRadius: '4px',
    background: 'rgba(0, 0, 0, 0.3)',
    overflow: 'hidden',
    position: 'relative',
  },
  
  gaugeFill: {
    height: '100%',
    borderRadius: '4px',
    transition: 'width 0.5s ease, background 0.3s ease',
  },
  
  resultBox: {
    background: 'rgba(0, 240, 255, 0.05)',
    border: '1px solid rgba(0, 240, 255, 0.15)',
    borderRadius: '8px',
    padding: '16px',
    marginTop: '16px',
  },
  
};

// CSS animations - inject into document
const injectStyles = () => {
  if (typeof document === 'undefined') return;
  if (document.getElementById('physics-sandbox-styles')) return;
  
  const styleSheet = document.createElement('style');
  styleSheet.id = 'physics-sandbox-styles';
  styleSheet.textContent = `
    @keyframes scan {
      0%, 100% { transform: translateY(0); opacity: 0; }
      10% { opacity: 1; }
      90% { opacity: 1; }
      100% { transform: translateY(100vh); opacity: 0; }
    }
    
    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.6; }
    }
    
    @keyframes glow {
      0%, 100% { box-shadow: 0 0 5px rgba(0, 240, 255, 0.3); }
      50% { box-shadow: 0 0 20px rgba(0, 240, 255, 0.6); }
    }
    
    @keyframes dataFlow {
      0% { background-position: 0% 50%; }
      100% { background-position: 200% 50%; }
    }
    
    .physics-slider::-webkit-slider-thumb {
      -webkit-appearance: none;
      width: 16px;
      height: 16px;
      border-radius: 50%;
      background: #00f0ff;
      cursor: pointer;
      box-shadow: 0 0 10px rgba(0, 240, 255, 0.5);
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    
    .physics-slider::-webkit-slider-thumb:hover {
      transform: scale(1.2);
      box-shadow: 0 0 20px rgba(0, 240, 255, 0.8);
    }
    
    .physics-slider::-webkit-slider-runnable-track {
      height: 4px;
      border-radius: 2px;
    }
    
    .physics-button:hover {
      background: rgba(0, 240, 255, 0.2) !important;
      box-shadow: 0 0 30px rgba(0, 240, 255, 0.4);
      transform: translateY(-1px);
    }
    
    .data-flow-line {
      background: linear-gradient(90deg, transparent, rgba(0, 240, 255, 0.6), transparent);
      background-size: 200% 100%;
      animation: dataFlow 2s linear infinite;
    }
  `;
  document.head.appendChild(styleSheet);
};

// ============================================================================
// COMPONENTS
// ============================================================================

const Slider = ({ label, value, onChange, min, max, step = 1, unit = '', help = '', disabled = false, sourceId }: {
  label: string;
  value: number;
  onChange: (value: number) => void;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  help?: string;
  disabled?: boolean;
  sourceId?: string;
}) => {
  const percentage = ((value - min) / (max - min)) * 100;
  
  const scrollToSource = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (sourceId) {
      const element = document.getElementById(`math-section-${sourceId}`);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        // Expand the section if collapsed
        const button = element.querySelector('button');
        if (button && button.getAttribute('aria-expanded') === 'false') {
          button.click();
        }
      }
    }
  };
  
  return (
    <div style={styles.sliderContainer}>
      <div style={styles.sliderLabel}>
        <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
        <span style={styles.sliderLabelText}>{label}</span>
          {sourceId && (
            <a
              href={`#math-section-${sourceId}`}
              onClick={scrollToSource}
              style={{
                color: '#64748b',
                fontSize: '10px',
                textDecoration: 'none',
                cursor: 'pointer',
                transition: 'color 0.2s ease',
              }}
              onMouseEnter={(e) => e.currentTarget.style.color = '#00f0ff'}
              onMouseLeave={(e) => e.currentTarget.style.color = '#64748b'}
              title="View source"
            >
              ⓘ
            </a>
          )}
        </span>
        <span style={styles.sliderValue}>
          {typeof value === 'number' ? value.toLocaleString(undefined, { maximumFractionDigits: 2 }) : value}
          <span style={{ color: '#64748b', fontWeight: 400 }}>{unit}</span>
        </span>
      </div>
      <input
        type="range"
        className="physics-slider"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        disabled={disabled}
        style={{
          width: '100%',
          height: '4px',
          borderRadius: '2px',
          background: `linear-gradient(to right, #00f0ff 0%, #00f0ff ${percentage}%, rgba(0, 240, 255, 0.1) ${percentage}%, rgba(0, 240, 255, 0.1) 100%)`,
          appearance: 'none',
          cursor: 'pointer',
          outline: 'none',
        }}
      />
      {help && <div style={styles.sliderHelp}>{help}</div>}
    </div>
  );
};

const StatusBadge = ({ ok, value, okLabel = 'NOMINAL', failLabel = 'CRITICAL' }: {
  ok: boolean;
  value: string;
  okLabel?: string;
  failLabel?: string;
}) => (
  <div style={{
    ...styles.statusBadge,
    ...(ok ? styles.statusOK : styles.statusFail),
  }}>
    <span style={{ fontSize: '12px' }}>{ok ? '◆' : '▲'}</span>
    {ok ? `${okLabel} ${value}` : failLabel}
  </div>
);

const UtilizationGauge = ({ value, label, thresholds = { warning: 0.7, critical: 0.9 } }: {
  value: number;
  label: string;
  thresholds?: { warning: number; critical: number };
}) => {
  const percentage = Math.min(100, value * 100);
  const color = value >= thresholds.critical ? '#ef4444' 
    : value >= thresholds.warning ? '#f59e0b' 
    : '#10b981';
  
  return (
    <div style={{ marginTop: '16px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
        <span style={{ color: '#64748b', fontSize: '10px', textTransform: 'uppercase' }}>{label}</span>
        <span style={{ color, fontSize: '12px', fontWeight: 600, fontFamily: "'IBM Plex Mono', 'Courier New', monospace" }}>
          {percentage.toFixed(1)}%
        </span>
      </div>
      <div style={styles.gauge}>
        <div 
          style={{
            ...styles.gaugeFill,
            width: `${percentage}%`,
            background: `linear-gradient(90deg, ${color}88, ${color})`,
            boxShadow: `0 0 10px ${color}66`,
          }}
        />
      </div>
    </div>
  );
};

const LiveValue = ({ label, value, unit = '', sourceId }: { label: string; value: string | number; unit?: string; sourceId?: string }) => {
  const [flash, setFlash] = useState(false);
  
  useEffect(() => {
    setFlash(true);
    const timer = setTimeout(() => setFlash(false), 300);
    return () => clearTimeout(timer);
  }, [value]);
  
  const scrollToSource = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (sourceId) {
      const element = document.getElementById(`math-section-${sourceId}`);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        // Expand the section if collapsed
        const button = element.querySelector('button');
        if (button && button.getAttribute('aria-expanded') === 'false') {
          button.click();
        }
      }
    }
  };
  
  return (
    <div style={{ 
      display: 'flex', 
      justifyContent: 'space-between', 
      alignItems: 'center',
      padding: '8px 12px',
      background: flash ? 'rgba(0, 240, 255, 0.1)' : 'transparent',
      borderRadius: '4px',
      transition: 'background 0.3s ease',
    }}>
      <span style={{ color: '#64748b', fontSize: '10px', textTransform: 'uppercase' }}>{label}</span>
      <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
      <span style={{ 
        color: '#00f0ff', 
        fontSize: '13px', 
        fontWeight: 600,
        fontFamily: "'IBM Plex Mono', 'Courier New', monospace",
      }}>
        {typeof value === 'number' ? value.toLocaleString(undefined, { maximumFractionDigits: 1 }) : value}
        <span style={{ color: '#64748b', fontWeight: 400, marginLeft: '2px' }}>{unit}</span>
        </span>
        {sourceId && (
          <a
            href={`#math-section-${sourceId}`}
            onClick={scrollToSource}
            style={{
              color: '#64748b',
              fontSize: '12px',
              textDecoration: 'none',
              cursor: 'pointer',
              marginLeft: '4px',
              transition: 'color 0.2s ease',
            }}
            onMouseEnter={(e) => e.currentTarget.style.color = '#00f0ff'}
            onMouseLeave={(e) => e.currentTarget.style.color = '#64748b'}
            title="View source"
          >
            ⓘ
          </a>
        )}
      </span>
    </div>
  );
};

// Equations and sources data organized by section
const EQUATIONS_AND_SOURCES = {
  thermal: {
    equations: `Heat Rejected:     Q = εσAT⁴

                   Q = heat rejected (W)
                   ε = emissivity (0-1)
                   σ = 5.67 × 10⁻⁸ W/m²K⁴ (Stefan-Boltzmann constant)
                   A = radiator area (m²)
                   T = temperature (K)

Radiator Area:     A_rad = Q_waste / (εσT⁴)

Utilization:       U = Q_generated / Q_max_rejection

Margin:            M = 1 - U`,
    sources: [
      { parameter: 'Emissivity', value: '0.85-0.95', source: 'NASA Thermal Control Handbook, Chapter 4' },
      { parameter: 'Operating Temp', value: '25-80°C', source: 'GPU thermal limits (NVIDIA H100 spec: 83°C max)' },
      { parameter: 'Stefan-Boltzmann', value: '5.67×10⁻⁸ W/m²K⁴', source: 'Physical constant' },
      { parameter: 'Thin-film radiators', value: '2-5 kg/m²', source: 'Roccor & NASA deployable radiator studies' },
    ],
  },
  compute: {
    equations: `Compute per Sat:   C = TDP × efficiency
                   C = compute (FLOPS)
                   TDP = thermal design power (W)
                   efficiency = GFLOPS/W

Efficiency Trend:  η(t) = η₀ × 2^(t/doubling_time)
                   (Moore's Law for compute efficiency)

Radiation Loss:    C_effective = C × (1 - ECC_overhead) × (1 - failure_rate)^years

Process Scaling:   Radiation sensitivity ∝ 1/node_size
                   (Smaller = more vulnerable)`,
    sources: [
      { parameter: 'GFLOPS/W', value: '3-5 (current)', source: 'NVIDIA H100: 3.9 TFLOPS/W (FP8)' },
      { parameter: "Moore's Law pace", value: '2-3 yr doubling', source: 'Historical trend 1965-2024; slowing to ~2.5yr' },
      { parameter: 'ECC overhead', value: '10-15%', source: 'IBM/NASA radiation studies for LEO' },
      { parameter: 'Failure rate', value: '2-5%/yr', source: 'Starlink failure data, ESA reliability reports' },
      { parameter: 'Radiation hardening penalty', value: '2-10x perf loss', source: 'BAE, Cobham rad-hard chip specs' },
    ],
  },
  power: {
    equations: `Power Generated:   P = A × S × η × cos(θ) × (1-d)^t
                   A = array area (m²)
                   S = 1,361 W/m² (solar constant, AM0)
                   η = cell efficiency
                   θ = sun angle (0° for sun-tracking)
                   d = degradation rate per year
                   t = years in orbit

Battery Sizing:    E_batt = P_load × t_eclipse / η_discharge
                   t_eclipse ≈ 35 min max in LEO

10-Year Power:     P_10yr = P_initial × (1-d)^10`,
    sources: [
      { parameter: 'Solar constant', value: '1,361 W/m²', source: 'NASA, measured at 1 AU' },
      { parameter: 'Triple-junction efficiency', value: '30-32%', source: 'SpectroLab, Azur Space datasheets' },
      { parameter: 'Perovskite tandem', value: '40%+', source: 'NREL efficiency chart 2024, Oxford PV' },
      { parameter: 'Degradation rate', value: '1-3%/yr', source: 'NASA LDEF data, Starlink estimates' },
      { parameter: 'Battery density', value: '250-300 Wh/kg', source: 'Li-ion current; 350+ for solid-state roadmap' },
      { parameter: 'Battery cost', value: '$100-200/kWh', source: 'BloombergNEF 2024, space-rated 2-3x premium' },
      { parameter: 'Eclipse duration', value: '35 min max', source: 'Orbital mechanics, LEO worst case' },
    ],
  },
  backhaul: {
    equations: `Link Capacity:     C_link = N_terminals × BW_per_link × utilization

Latency:           t = 2h/c + t_routing + t_processing
                   h = altitude (km)
                   c = 3×10⁸ m/s (speed of light)
                   t_routing = hops × switch_delay

Aggregate BW:      BW_total = satellites × links_per_sat × capacity_per_link

Ground Coverage:   Must have line-of-sight to ground station
                   LEO sat visible ~3-5 min per pass`,
    sources: [
      { parameter: 'Optical link capacity', value: '100 Gbps', source: 'Starlink laser links (Mynaric, Tesat specs)' },
      { parameter: 'Roadmap capacity', value: '200+ Gbps', source: 'ESA ScyLight program, CACI studies' },
      { parameter: 'Starlink laser links', value: '42,000 deployed', source: 'SpaceX FCC filings 2024' },
      { parameter: 'LEO latency', value: '20-40ms', source: 'Starlink measured performance' },
      { parameter: 'GEO latency', value: '600ms+', source: 'HughesNet/Viasat measured' },
      { parameter: 'Ground stations', value: '100+ needed', source: 'Based on coverage geometry' },
    ],
  },
  maintenance: {
    equations: `Failures per Year: F = N × r
                   N = fleet size
                   r = failure rate (%/yr)

Replacement Rate:  R = F - repairs

Steady State:      dN/dt = launches - failures - deorbits
                   For stable fleet: launches ≥ failures

Fleet Half-life:   t_½ = ln(2) / failure_rate

Survival Rate:     S(t) = (1 - r)^t
                   10yr survival at 4.5%/yr = 63%`,
    sources: [
      { parameter: 'Starlink failure rate', value: '3-5%/yr', source: 'Jonathan McDowell tracking data' },
      { parameter: 'Design lifetime', value: '5-7 years', source: 'SpaceX FCC filings' },
      { parameter: 'Deorbit compliance', value: '95%+', source: 'SpaceX reported, FCC requirement' },
      { parameter: 'Servicer drones', value: 'Concept phase', source: 'Northrop MEV, Astroscale demos' },
      { parameter: 'Launches per year', value: '100+ possible', source: 'SpaceX 2024 cadence: 100+ launches' },
    ],
  },
  cost: {
    equations: `Cost per PFLOP:    $/PFLOP = (C_launch + C_hardware + C_ops) / Compute

Launch Cost:       C_launch = mass × $/kg

Learning Curve:    Cost(t) = Cost₀ × (cumulative_units)^(-b)
                   b ≈ 0.15-0.25 (15-25% reduction per doubling)

                   Or exponential: Cost(t) = Cost₀ × (1-rate)^t

Total OPEX:        OPEX = fleet × (replacement_rate × sat_cost + ops_cost)

Crossover Point:   When $/PFLOP_orbital < $/PFLOP_terrestrial`,
    sources: [
      { parameter: 'Falcon 9 cost', value: '~$2,700/kg', source: 'SpaceX public pricing' },
      { parameter: 'Starship target', value: '$100-200/kg', source: 'Elon Musk statements, Sandy Munro analysis' },
      { parameter: 'Starship floor', value: '$10-50/kg', source: 'Long-term aspirational (propellant cost ~$10/kg)' },
      { parameter: 'Starlink sat cost', value: '$250-500k', source: 'Estimated from SpaceX financials' },
      { parameter: 'Learning rate', value: '15-20%', source: "Wright's Law historical data for aerospace" },
      { parameter: 'Ground DC cost', value: '$10-15/W', source: 'McKinsey, Uptime Institute data center reports' },
      { parameter: 'Ground LCOE', value: '$30-50/MWh', source: 'EIA, Lazard LCOE analysis 2024' },
    ],
  },
};

const ShowMathSection = ({ sectionId, title }: { sectionId: keyof typeof EQUATIONS_AND_SOURCES; title: string }) => {
  const [isOpen, setIsOpen] = useState(false);
  const data = EQUATIONS_AND_SOURCES[sectionId];
  
  if (!data) return null;
  
  return (
    <div id={`math-section-${sectionId}`} style={{ marginTop: '16px', borderTop: '1px solid rgba(0, 240, 255, 0.1)', paddingTop: '16px' }}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        style={{
          width: '100%',
          padding: '8px 12px',
          background: 'rgba(0, 240, 255, 0.05)',
          border: '1px solid rgba(0, 240, 255, 0.2)',
          borderRadius: '4px',
          color: '#00f0ff',
          fontSize: '10px',
          fontWeight: 600,
          textTransform: 'uppercase',
          letterSpacing: '1px',
          cursor: 'pointer',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          transition: 'all 0.2s ease',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = 'rgba(0, 240, 255, 0.1)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = 'rgba(0, 240, 255, 0.05)';
        }}
        aria-expanded={isOpen}
      >
        <span>Show Math</span>
        <span style={{ fontSize: '14px', transition: 'transform 0.2s ease', transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)' }}>
          ▼
        </span>
      </button>
      
      {isOpen && (
        <div style={{ marginTop: '16px', padding: '16px', background: 'rgba(0, 10, 20, 0.5)', borderRadius: '8px', border: '1px solid rgba(0, 240, 255, 0.1)' }}>
          <div style={{ marginBottom: '20px' }}>
            <h4 style={{ color: '#00f0ff', fontSize: '11px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '12px' }}>
              Equations
            </h4>
            <pre style={{
              color: '#94a3b8',
              fontSize: '10px',
              fontFamily: "'IBM Plex Mono', 'Courier New', monospace",
              lineHeight: '1.6',
              whiteSpace: 'pre-wrap',
              margin: 0,
            }}>
              {data.equations}
            </pre>
          </div>
          
          <div>
            <h4 style={{ color: '#00f0ff', fontSize: '11px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '12px' }}>
              Sources
            </h4>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '10px', fontFamily: "'IBM Plex Mono', 'Courier New', monospace" }}>
              <thead>
                <tr style={{ borderBottom: '1px solid rgba(0, 240, 255, 0.2)' }}>
                  <th style={{ textAlign: 'left', padding: '8px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Parameter</th>
                  <th style={{ textAlign: 'left', padding: '8px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Value</th>
                  <th style={{ textAlign: 'left', padding: '8px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Source</th>
                </tr>
              </thead>
              <tbody>
                {data.sources.map((source, idx) => (
                  <tr key={idx} style={{ borderBottom: '1px solid rgba(0, 240, 255, 0.05)' }}>
                    <td style={{ padding: '8px', color: '#94a3b8' }}>{source.parameter}</td>
                    <td style={{ padding: '8px', color: '#00f0ff', fontFamily: "'IBM Plex Mono', 'Courier New', monospace" }}>{source.value}</td>
                    <td style={{ padding: '8px', color: '#64748b', fontSize: '9px' }}>{source.source}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

const Section = ({ title, status, children }: { title: string; status?: React.ReactNode; children: React.ReactNode }) => (
  <div style={styles.section}>
    <div style={styles.sectionHeader}>
      <h3 style={styles.sectionTitle}>{title}</h3>
      {status}
    </div>
    {children}
  </div>
);


// ============================================================================
// MAIN COMPONENT
// ============================================================================

interface PhysicsSandboxProps {
  baselineData?: unknown;
  currentYear?: string;
  onApplyToGlobe?: (data: { params: PhysicsParams; results: PhysicsResults }) => void;
}

// Calculate safe defaults based on year (accounting for improvement rate)
const calculateSafeDefaults = (year: string) => {
    // Calculate thermally-safe defaults
    // Start with a conservative bus power that's definitely thermally feasible
    const yearNum = parseInt(year || '2033');
    const hasDeployable = yearNum >= 2028;
    const MAX_BODY_MOUNTED_M2 = 20;
    const MAX_DEPLOYABLE_M2 = 100;
    const maxRadiatorArea = hasDeployable ? MAX_DEPLOYABLE_M2 : MAX_BODY_MOUNTED_M2;
    
    // Match baseline scenario: POWER_PROGRESSION[2025] = 5kW * busPowerMultiplier(0.92) = 4.6kW
    // For 2025 baseline: 5kW * 0.92 = 4.6kW, but we'll use 5kW as a safe default
    // For other years, calculate from progression
    const POWER_PROGRESSION: Record<number, number> = {
      2025: 5,    // Conservative start (body-mounted radiators)
      2028: 15,   // Early deployables becoming available
      2030: 35,   // Mid-term (Starlink V3 level)
      2033: 80,   // Advanced deployables for compute-optimized
      2035: 110,  // High-power compute satellites
      2040: 150,  // Target: 150 kW for aggressive compute satellites
    };
    
    // Get base power from progression
    let basePowerKw = 5; // Default to 2025 value
    if (POWER_PROGRESSION[yearNum]) {
      basePowerKw = POWER_PROGRESSION[yearNum];
    } else {
      // Interpolate between years
      const years = Object.keys(POWER_PROGRESSION).map(Number).sort((a, b) => a - b);
      if (yearNum <= years[0]) {
        basePowerKw = POWER_PROGRESSION[years[0]];
      } else if (yearNum >= years[years.length - 1]) {
        basePowerKw = POWER_PROGRESSION[years[years.length - 1]];
      } else {
        for (let i = 0; i < years.length - 1; i++) {
          if (yearNum >= years[i] && yearNum <= years[i + 1]) {
            const lower = POWER_PROGRESSION[years[i]];
            const upper = POWER_PROGRESSION[years[i + 1]];
            const t = (yearNum - years[i]) / (years[i + 1] - years[i]);
            basePowerKw = lower + (upper - lower) * t;
            break;
          }
        }
      }
    }
    
    // Apply baseline multiplier (0.92)
    const busPowerKw = basePowerKw * 0.92;
    const emissivity = 0.90; // High emissivity for better heat rejection
    const radiatorTempC = 25; // Slightly higher temp for better rejection
    
    // Calculate required radiator area for thermal balance with 20% margin
    const T_rad_K = radiatorTempC + 273.15;
    const heatGenPerSat_kW = busPowerKw * 0.85;
    const heatRejectionPerM2_kW = emissivity * STEFAN_BOLTZMANN * 
      (Math.pow(T_rad_K, 4) - Math.pow(T_SINK, 4)) / 1000;
    const requiredRadiatorArea = (heatGenPerSat_kW * 1.2) / heatRejectionPerM2_kW; // 20% margin
    
    // Cap at thermal limits
    const safeRadiatorArea = Math.min(Math.ceil(requiredRadiatorArea), maxRadiatorArea);
    
    // If required area exceeds max, reduce bus power to fit
    let finalBusPowerKw = busPowerKw;
    if (requiredRadiatorArea > maxRadiatorArea) {
      // Calculate max power that fits in available radiator area
      const maxHeatRejection_kW = heatRejectionPerM2_kW * maxRadiatorArea;
      const maxHeatGen_kW = maxHeatRejection_kW / 1.2; // 20% margin
      finalBusPowerKw = maxHeatGen_kW / 0.85; // Convert back to bus power
    }
    
    // Conservative backhaul defaults to avoid constraint violations
    // Backhaul capacity scales with optical terminals and link capacity
    // Use lower values to ensure we don't exceed backhaul capacity
    const conservativeOpticalTerminals = 4; // Lower end (1-16 range)
    const conservativeLinkCapacityGbps = 50; // Lower end (10-200 range)
    
    return {
      year: year,
      // Thermally-safe defaults that pass all checks
      radiatorAreaPerSat: safeRadiatorArea,
      emissivity: emissivity,
      radiatorTempC: radiatorTempC,
      busPowerKw: finalBusPowerKw,
      mooresLawDoublingYears: 3.25, // Middle of 1.5-5 range
      opticalTerminals: conservativeOpticalTerminals, // Conservative: 4 (lower end)
      linkCapacityGbps: conservativeLinkCapacityGbps, // Conservative: 50 Gbps (lower end)
      groundStations: 100, // Middle of 20-150 range (slightly higher for better backhaul)
      fleetSize: 5500, // Middle of 1000-10000 range
      failureRatePercent: 4.5, // Baseline: failureRateBase = 0.045 = 4.5%
      servicerDrones: 50, // Middle of 0-100 range
      launchesPerYear: 29, // Middle of 6-52 range
      satsPerLaunch: 55, // Middle of 10-100 range
      launchCostPerKg: 200, // Baseline: $200/kg (matches baseline scenario base_cost_per_kg_to_leo)
      launchCostImprovementRate: 0.07, // Baseline: launchCostDeclinePerYear = 0.93 means 7% decline per year
      satelliteBaseCost: 275000, // Middle of 50k-500k range (275k)
      // Compute / Silicon
      processNode: 8, // Middle of 3-14 range (rounded to integer)
      chipTdp: 300, // Middle of 100-500 range
      radiationHardening: 1, // Middle of 0-2 range
      memoryPerNode: 256, // Middle of 64-512 range (standard memory size)
      // Power / Solar
      solarEfficiency: 35, // Middle of 25-45 range
      degradationRate: 1.75, // Middle of 0.5-3 range
      batteryBuffer: 40, // Increased to pass eclipse check (needs >= 35)
      powerMargin: 25, // Increased to pass eclipse check (needs >= 25)
      batteryDensity: 275, // Middle of 150-400 range
      batteryCost: 175, // Middle of 50-300 range
      // Structural scaling parameters
      structuralPenaltyExponent: 1.2, // Default 20% superlinear penalty
      structuralThresholdKW: 50, // Default threshold at 50 kW
    };
};

const PhysicsSandbox = ({ baselineData, currentYear = '2033', onApplyToGlobe }: PhysicsSandboxProps) => {
  useEffect(() => { injectStyles(); }, []);
  
  const { timeline, config, recomputeWithPlans, recompute, yearPlans } = useSimulationStore();
  const simTime = useOrbitSim((s) => s.simTime);
  const setSimPaused = useOrbitSim((s) => s.setSimPaused);
  const actualYear = timeline.length > 0 ? timeline[timeline.length - 1]?.year.toString() || currentYear : currentYear;
  
  const satellites = useOrbitSim((s) => s.satellites);
  const hasSimulationStarted = (timeline.length > 1 && timeline[timeline.length - 1]?.year > (config?.startYear || 2025)) || 
                                satellites.length > 0;
  
  const resetSimulation = useCallback(() => {
    if (typeof window !== 'undefined') {
      (window as { __physicsSandboxParams?: unknown }).__physicsSandboxParams = null;
    }
    
    // Reset orbit sim state first
    useOrbitSim.setState({ 
      simTime: 0, 
      satellites: [], 
      routes: [],
      year: 2025,
    });
    
    // Reset simulation store - reset to initial yearPlans and recompute
    const initialPlans = [{
      deploymentIntensity: 1.0,
      computeStrategy: "balanced" as const,
      launchStrategy: "medium" as const,
    }];
    
    // Use recomputeWithPlans to fully reset the timeline
    recomputeWithPlans(initialPlans);
    
    // Small delay to ensure state updates propagate before resetting params
    setTimeout(() => {
      const newDefaults = calculateSafeDefaults('2025');
      setParams(newDefaults);
    }, 100);
  }, [recomputeWithPlans]);
  
  const workingDefaults = useMemo(() => calculateSafeDefaults(actualYear), [actualYear]);
  
  // Initialize params from existing sandbox params if available, otherwise use defaults
  const initializeParams = useCallback((): PhysicsParams => {
    if (typeof window !== 'undefined') {
      const existing = (window as { __physicsSandboxParams?: { params?: PhysicsParams } }).__physicsSandboxParams;
      if (existing?.params) {
        // Merge with defaults to ensure all required fields are present
        const defaults = calculateSafeDefaults(actualYear);
        return {
          ...defaults,
          ...existing.params,
        };
      }
    }
    return calculateSafeDefaults(actualYear);
  }, [actualYear]);
  
  const [params, setParams] = useState<PhysicsParams>(initializeParams);
  
  // Sync params when component mounts or when sandbox params change externally
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const existing = (window as { __physicsSandboxParams?: { params?: PhysicsParams } }).__physicsSandboxParams;
      if (existing?.params) {
        const defaults = calculateSafeDefaults(actualYear);
        setParams({
          ...defaults,
          ...existing.params,
        });
      } else {
        // Only reset to defaults if no existing params (don't overwrite user changes)
        const newDefaults = calculateSafeDefaults(actualYear);
        setParams(newDefaults);
      }
    }
  }, [actualYear]);
  
  // Listen for external changes to sandbox params (e.g., when applied from another component)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    
    const handleSandboxApplied = () => {
      const existing = (window as { __physicsSandboxParams?: { params?: PhysicsParams } }).__physicsSandboxParams;
      if (existing?.params) {
        const defaults = calculateSafeDefaults(actualYear);
        setParams({
          ...defaults,
          ...existing.params,
        });
      }
    };
    
    window.addEventListener('physics-sandbox-applied', handleSandboxApplied);
    return () => {
      window.removeEventListener('physics-sandbox-applied', handleSandboxApplied);
    };
  }, [actualYear]);

  const updateParam = useCallback((key: string, value: number) => {
    setParams(prev => ({ ...prev, [key]: value }));
  }, []);

  const resetToDefaults = useCallback(() => {
    const newDefaults = calculateSafeDefaults(actualYear);
    setParams(newDefaults);
  }, [actualYear]);

  const results = useMemo(() => calculatePhysics(params), [params]);
  const baselineResults = useMemo(() => calculatePhysics(workingDefaults), []);

  // Track if this is the initial mount to avoid triggering re-run on mount
  const isInitialMount = useRef(true);

  // CRITICAL FIX: When sandbox params change, update window.__physicsSandboxParams and trigger simulation re-run
  // This ensures charts and exports reflect the new parameters
  useEffect(() => {
    if (typeof window === 'undefined') return;
    
    // Skip on initial mount - params are already set from initialization
    if (isInitialMount.current) {
      isInitialMount.current = false;
      return;
    }

    // Debounce simulation re-run to avoid excessive computation
    const timeoutId = setTimeout(() => {
      // Update window.__physicsSandboxParams with current params
      const physicsOverrides = {
        radiatorArea_m2: params.radiatorAreaPerSat,
        emissivity: params.emissivity,
        busPowerKw: params.busPowerKw,
        radiatorTempC: params.radiatorTempC,
        opticalTerminals: params.opticalTerminals,
        linkCapacityGbps: params.linkCapacityGbps,
        groundStations: params.groundStations,
        mooresLawDoublingYears: params.mooresLawDoublingYears,
        launchCostPerKg: params.launchCostPerKg,
        launchCostImprovementRate: params.launchCostImprovementRate ?? 0.15,
        satelliteBaseCost: params.satelliteBaseCost,
        processNode: params.processNode,
        chipTdp: params.chipTdp,
        radiationHardening: params.radiationHardening,
        memoryPerNode: params.memoryPerNode,
        solarEfficiency: params.solarEfficiency,
        degradationRate: params.degradationRate,
        batteryBuffer: params.batteryBuffer,
        powerMargin: params.powerMargin,
        batteryDensity: params.batteryDensity,
        batteryCost: params.batteryCost,
      };

      (window as { __physicsSandboxParams?: unknown }).__physicsSandboxParams = {
        params,
        results,
        physicsOverrides,
      };

      // Trigger simulation re-run with current year plans
      // This will recalculate all time series data with the new physics parameters
      if (yearPlans && yearPlans.length > 0) {
        recomputeWithPlans(yearPlans);
      } else {
        // Fallback: use recompute if no plans available
        recompute();
      }

      // Dispatch event to notify other components
      window.dispatchEvent(new CustomEvent('physics-sandbox-applied', {
        detail: {
          params,
          results,
          physicsOverrides,
        }
      }));
    }, 500); // 500ms debounce

    return () => clearTimeout(timeoutId);
  }, [params, results, recompute, recomputeWithPlans, yearPlans]);

  const handleApplyToGlobe = () => {
    if (!results.allSystemsOK) {
      const violations = [];
      if (!results.thermalOK) violations.push('OVERHEATING: Heat rejection < heat generation');
      if (!results.backhaulOK) violations.push('BACKHAUL SATURATED: Bandwidth capacity < compute output');
      if (!results.maintenanceOK) violations.push('FLEET DECLINING: Net attrition > 10% of failures');
      if (!results.computeOK) violations.push('UNPROTECTED: Radiation hardening required for space');
      if (!results.powerOK) violations.push('ECLIPSE FAIL: Battery buffer insufficient or degradation too high');
      
      const message = `⚠️ PHYSICS CONSTRAINT VIOLATED\n\n` +
        `These parameters are physically impossible:\n${violations.join('\n')}\n\n` +
        `Adjust parameters to satisfy physics constraints before deploying.\n\n` +
        `Note: High costs are allowed (economically nonsensical is OK), but physics must be valid.`;
      
      alert(message);
      return;
    }
    
    if (hasSimulationStarted) {
      if (!confirm('Simulation has already started. Reset the world to apply sandbox changes?')) {
        return;
      }
      resetSimulation();
      setTimeout(() => {
        applySandboxToGlobe();
      }, 100);
    } else {
      applySandboxToGlobe();
    }
  };
  
  const applySandboxToGlobe = () => {
    if (typeof window !== 'undefined') {
      const physicsOverrides = {
        radiatorArea_m2: params.radiatorAreaPerSat,
        emissivity: params.emissivity,
        busPowerKw: params.busPowerKw,
        radiatorTempC: params.radiatorTempC,
        opticalTerminals: params.opticalTerminals,
        linkCapacityGbps: params.linkCapacityGbps,
        groundStations: params.groundStations,
        mooresLawDoublingYears: params.mooresLawDoublingYears,
        launchCostPerKg: params.launchCostPerKg,
        launchCostImprovementRate: params.launchCostImprovementRate ?? 0.15,
        satelliteBaseCost: params.satelliteBaseCost,
        processNode: params.processNode,
        chipTdp: params.chipTdp,
        radiationHardening: params.radiationHardening,
        memoryPerNode: params.memoryPerNode,
        solarEfficiency: params.solarEfficiency,
        degradationRate: params.degradationRate,
        batteryBuffer: params.batteryBuffer,
        powerMargin: params.powerMargin,
        batteryDensity: params.batteryDensity,
        batteryCost: params.batteryCost,
      };

      (window as { __physicsSandboxParams?: unknown }).__physicsSandboxParams = {
        params,
        results,
        physicsOverrides,
      };
      
      window.dispatchEvent(new CustomEvent('physics-sandbox-applied', {
        detail: {
          params,
          results,
          physicsOverrides,
        }
      }));
      
      window.dispatchEvent(new CustomEvent('navigate-surface', { detail: { surface: 'overview' } }));
    }
    
    if (onApplyToGlobe) {
      onApplyToGlobe({
        params,
        results,
      });
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 sm:p-6" style={styles.container}>
      {/* Animated background */}
      <div style={styles.gridOverlay} />
      <div style={styles.scanLine} />
      
      {/* Header */}
      <div style={styles.header}>
        <div style={styles.headerTop}>
          <div style={{ flex: '1', minWidth: '200px' }}>
            <h2 style={styles.title}>Physics Sandbox</h2>
            <p style={styles.subtitle}>Stress-test the constraints. Break the physics.</p>
            {hasSimulationStarted && (
              <div style={{
                marginTop: '12px',
                padding: '12px',
                background: 'rgba(239, 68, 68, 0.15)',
                border: '1px solid rgba(239, 68, 68, 0.3)',
                borderRadius: '6px',
                fontSize: '11px',
                color: '#ef4444',
              }}>
                ⚠ Simulation has started. Changes require resetting the world.
              </div>
            )}
          </div>
          <div style={styles.headerButtons}>
            <button
              className="physics-button"
              onClick={resetToDefaults}
              style={styles.button}
              disabled={hasSimulationStarted}
            >
              Reset Params
            </button>
            {hasSimulationStarted && (
              <button
                className="physics-button"
                onClick={resetSimulation}
                style={{
                  ...styles.button,
                  background: 'rgba(239, 68, 68, 0.2)',
                  borderColor: '#ef4444',
                  color: '#ef4444',
                }}
              >
                Reset World
              </button>
            )}
            <button
              className="physics-button"
              onClick={handleApplyToGlobe}
              disabled={!results.allSystemsOK}
              style={{
                ...styles.button,
                ...styles.buttonPrimary,
                animation: results.allSystemsOK ? 'glow 2s ease-in-out infinite' : 'none',
                opacity: results.allSystemsOK ? 1 : 0.5,
                cursor: results.allSystemsOK ? 'pointer' : 'not-allowed',
              }}
              title={!results.allSystemsOK ? 'Fix physics constraints before deploying' : 'Apply parameters to simulation'}
            >
              View on Globe →
            </button>
          </div>
        </div>
      </div>

      {/* Constraint Sections */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', 
        gap: '20px',
        position: 'relative',
        zIndex: 1,
      }}>
        
        {/* THERMAL */}
        <Section 
          title="Thermal / Radiators"
          status={
            <StatusBadge 
              ok={results.thermalOK} 
              value={`${(results.thermalMargin * 100).toFixed(0)}%`}
              okLabel="MARGIN"
              failLabel="OVERHEATING"
            />
          }
        >
          <div style={{ marginBottom: '20px' }}>
            <ThermalViz
              radiatorArea={params.radiatorAreaPerSat}
              utilization={results.radiatorUtilization}
              tempC={params.radiatorTempC}
            />
          </div>
          <Slider
            label="Radiator Area"
            value={params.radiatorAreaPerSat}
            onChange={(v) => updateParam('radiatorAreaPerSat', v)}
            min={10} max={800} unit=" m²"
            help="Thin-film deployable radiator panels"
            disabled={hasSimulationStarted}
            sourceId="thermal"
          />
          <Slider
            label="Emissivity"
            value={params.emissivity}
            onChange={(v) => updateParam('emissivity', v)}
            min={0.7} max={0.95} step={0.01}
            help="Surface coating efficiency (0.95 = state of art)"
            disabled={hasSimulationStarted}
            sourceId="thermal"
          />
          <Slider
            label="Operating Temp"
            value={params.radiatorTempC}
            onChange={(v) => updateParam('radiatorTempC', v)}
            min={-20} max={60} unit="°C"
            help="Higher temp = more heat rejection"
            disabled={hasSimulationStarted}
            sourceId="thermal"
          />
          <Slider
            label="Bus Power"
            value={params.busPowerKw}
            onChange={(v) => updateParam('busPowerKw', v)}
            min={1} max={500} step={1} unit=" kW"
            help="Uncapped to test structural scaling penalties at high power"
            disabled={hasSimulationStarted}
          />
          
          <UtilizationGauge 
            value={results.radiatorUtilization} 
            label="Radiator Utilization"
          />
          
          <div style={styles.resultBox}>
            <LiveValue label="Heat Generated" value={results.heatGenPerSat_kW.toFixed(1)} unit=" kW" sourceId="thermal" />
            <LiveValue label="Heat Rejected" value={results.heatRejectionPerSat_kW.toFixed(1)} unit=" kW" sourceId="thermal" />
          </div>
          
          <ShowMathSection sectionId="thermal" title="Thermal / Radiators" />
        </Section>

        {/* BACKHAUL */}
        <Section 
          title="Backhaul / Bandwidth"
          status={
            <StatusBadge 
              ok={results.backhaulOK} 
              value={`${((1 - results.backhaulUtilization) * 100).toFixed(0)}%`}
              okLabel="HEADROOM"
              failLabel="SATURATED"
            />
          }
        >
          <div style={{ marginBottom: '20px' }}>
            <BackhaulViz
              opticalTerminals={params.opticalTerminals}
              linkCapacity={params.linkCapacityGbps}
              groundStations={params.groundStations}
              utilization={results.backhaulUtilization}
            />
          </div>
          <Slider
            label="Optical Terminals"
            value={params.opticalTerminals}
            onChange={(v) => updateParam('opticalTerminals', v)}
            min={1} max={1200} unit="/sat"
            help="Laser communication links per satellite"
            disabled={hasSimulationStarted}
            sourceId="backhaul"
          />
          <Slider
            label="Link Capacity"
            value={params.linkCapacityGbps}
            onChange={(v) => updateParam('linkCapacityGbps', v)}
            min={10} max={200} unit=" Gbps"
            help="100 Gbps = current tech, 200+ = roadmap"
            disabled={hasSimulationStarted}
            sourceId="backhaul"
          />
          <Slider
            label="Ground Stations"
            value={params.groundStations}
            onChange={(v) => updateParam('groundStations', v)}
            min={20} max={150}
            help="Worldwide receive stations"
            disabled={hasSimulationStarted}
            sourceId="backhaul"
          />
          
          <UtilizationGauge 
            value={results.backhaulUtilization} 
            label="Backhaul Utilization"
          />
          
          <div style={styles.resultBox}>
            <LiveValue label="Capacity/Sat" value={results.backhaulPerSat_Gbps} unit=" Gbps" sourceId="backhaul" />
            <LiveValue label="Coverage" value={(results.groundStationCoverage * 100).toFixed(0)} unit="%" sourceId="backhaul" />
          </div>
          
          <ShowMathSection sectionId="backhaul" title="Backhaul / Bandwidth" />
        </Section>

        {/* MAINTENANCE */}
        <Section 
          title="Maintenance / Fleet"
          status={
            <StatusBadge 
              ok={results.maintenanceOK} 
              value={`${(results.survivalRate10yr * 100).toFixed(0)}%`}
              okLabel="10YR SURVIVAL"
              failLabel="FLEET DECLINING"
            />
          }
        >
          <div style={{ marginBottom: '20px' }}>
            <MaintenanceViz
              fleetSize={params.fleetSize}
              failureRate={params.failureRatePercent}
              servicerDrones={params.servicerDrones}
              survivalRate={results.survivalRate10yr}
            />
          </div>
          <Slider
            label="Fleet Size"
            value={params.fleetSize}
            onChange={(v) => updateParam('fleetSize', v)}
            min={1000} max={10000} step={100} unit=" sats"
            disabled={hasSimulationStarted}
            sourceId="maintenance"
          />
          <Slider
            label="Failure Rate"
            value={params.failureRatePercent}
            onChange={(v) => updateParam('failureRatePercent', v)}
            min={0.5} max={10} step={0.5} unit="%/yr"
            help="Radiation, debris, component wear"
            disabled={hasSimulationStarted}
            sourceId="maintenance"
          />
          <Slider
            label="Servicer Drones"
            value={params.servicerDrones}
            onChange={(v) => updateParam('servicerDrones', v)}
            min={0} max={100}
            help="Autonomous repair robots"
            disabled={hasSimulationStarted}
            sourceId="maintenance"
          />
          <Slider
            label="Launches / Year"
            value={params.launchesPerYear}
            onChange={(v) => updateParam('launchesPerYear', v)}
            min={6} max={52}
            disabled={hasSimulationStarted}
            sourceId="maintenance"
          />
          
          <div style={styles.resultBox}>
            <LiveValue label="Failures/yr" value={results.failuresPerYear.toFixed(0)} sourceId="maintenance" />
            <LiveValue label="Repairs/yr" value={results.repairsPerYear.toFixed(0)} sourceId="maintenance" />
            <LiveValue label="Replacements/yr" value={results.replacementsPerYear.toFixed(0)} sourceId="maintenance" />
          </div>
          
          <ShowMathSection sectionId="maintenance" title="Maintenance / Fleet" />
        </Section>

        {/* COST ASSUMPTIONS */}
        <Section title="Cost Assumptions">
          <div style={{ marginBottom: '20px' }}>
            <CostViz
              launchCostPerKg={params.launchCostPerKg}
              launchesPerYear={params.launchesPerYear}
              satsPerLaunch={params.satsPerLaunch}
              massPerSat={results.totalMassPerSat_kg}
            />
          </div>
          <Slider
            label="Launch Cost"
            value={params.launchCostPerKg}
            onChange={(v) => updateParam('launchCostPerKg', v)}
            min={20} max={500} unit=" $/kg"
            help="Starship target: $50-100/kg"
            disabled={hasSimulationStarted}
            sourceId="cost"
          />
          <Slider
            label="Moore's Law Pace"
            value={params.mooresLawDoublingYears}
            onChange={(v) => updateParam('mooresLawDoublingYears', v)}
            min={1.5} max={5} step={0.5} unit=" yr"
            help="Compute efficiency doubling time"
            disabled={hasSimulationStarted}
            sourceId="compute"
          />
          <Slider
            label="Satellite Base Cost"
            value={params.satelliteBaseCost / 1000}
            onChange={(v) => updateParam('satelliteBaseCost', v * 1000)}
            min={50} max={500} unit="k $"
            disabled={hasSimulationStarted}
            sourceId="cost"
          />
          <Slider
            label="Sats per Launch"
            value={params.satsPerLaunch}
            onChange={(v) => updateParam('satsPerLaunch', v)}
            min={10} max={100}
            disabled={hasSimulationStarted}
            sourceId="cost"
          />
          
          <div style={styles.resultBox}>
            <LiveValue label="Mass/Sat" value={results.totalMassPerSat_kg.toFixed(0)} unit=" kg" sourceId="cost" />
            <LiveValue label="Compute/Sat" value={results.computePerSat_TFLOPS.toFixed(0)} unit=" TFLOPS" sourceId="cost" />
          </div>
          
          <ShowMathSection sectionId="cost" title="Cost Assumptions" />
        </Section>

        {/* COMPUTE / SILICON */}
        <Section 
          title="Compute / Silicon"
          status={
            <StatusBadge 
              ok={results.computeOK} 
              value={`${results.gflopsPerWatt.toFixed(0)} GF/W`}
              okLabel=""
              failLabel="UNPROTECTED"
            />
          }
        >
          <div style={{ marginBottom: '20px' }}>
            <ComputeViz
              processNode={params.processNode || 5}
              chipTdp={params.chipTdp || 300}
              radiationHardening={params.radiationHardening || 1}
              memoryPerNode={params.memoryPerNode || 128}
              efficiency={results.gflopsPerWatt}
            />
          </div>
          
          <Slider
            label="Process Node"
            value={params.processNode || 5}
            onChange={(v) => updateParam('processNode', v)}
            min={3} max={14} unit="nm"
            help="Smaller = more efficient but more radiation sensitive"
            disabled={hasSimulationStarted}
            sourceId="compute"
          />
          <Slider
            label="Chip TDP"
            value={params.chipTdp || 300}
            onChange={(v) => updateParam('chipTdp', v)}
            min={100} max={500} unit=" W"
            help="Power per compute module"
            disabled={hasSimulationStarted}
            sourceId="compute"
          />
          <Slider
            label="Radiation Hardening"
            value={params.radiationHardening || 1}
            onChange={(v) => updateParam('radiationHardening', v)}
            min={0} max={2} step={1}
            help={['Soft (consumer)', 'Standard (space-rated)', 'Full (rad-hard)'][params.radiationHardening || 1]}
            disabled={hasSimulationStarted}
            sourceId="compute"
          />
          <Slider
            label="Memory / Node"
            value={params.memoryPerNode || 128}
            onChange={(v) => updateParam('memoryPerNode', v)}
            min={64} max={512} unit=" GB"
            help="HBM capacity per satellite"
            disabled={hasSimulationStarted}
            sourceId="compute"
          />
          
          <div style={styles.resultBox}>
            <LiveValue label="Efficiency" value={results.gflopsPerWatt.toFixed(1)} unit=" GFLOPS/W" sourceId="compute" />
            <LiveValue label="Compute/Sat" value={results.computePerSat_TFLOPS.toFixed(0)} unit=" TFLOPS" sourceId="compute" />
          </div>
          
          <ShowMathSection sectionId="compute" title="Compute / Silicon" />
        </Section>

        {/* POWER / SOLAR */}
        <Section 
          title="Power / Solar"
          status={
            <StatusBadge 
              ok={results.powerOK} 
              value={`${(results.degradationAfter10yr * 100).toFixed(0)}% @10yr`}
              okLabel=""
              failLabel="ECLIPSE FAIL"
            />
          }
        >
          <div style={{ marginBottom: '20px' }}>
            <PowerViz
              solarEfficiency={params.solarEfficiency || 32}
              degradationRate={params.degradationRate || 1.5}
              batteryBuffer={params.batteryBuffer || 45}
              powerMargin={params.powerMargin || 20}
              batteryDensity={params.batteryDensity || 300}
              batteryCost={params.batteryCost || 120}
            />
          </div>
          
          <Slider
            label="Solar Efficiency"
            value={params.solarEfficiency || 32}
            onChange={(v) => updateParam('solarEfficiency', v)}
            min={25} max={45} unit="%"
            help="Triple-junction: 32%, Perovskite tandem: 40%+"
            disabled={hasSimulationStarted}
            sourceId="power"
          />
          <Slider
            label="Degradation Rate"
            value={params.degradationRate || 1.5}
            onChange={(v) => updateParam('degradationRate', v)}
            min={0.5} max={3} step={0.1} unit="%/yr"
            help="Solar cell degradation from radiation"
            disabled={hasSimulationStarted}
            sourceId="power"
          />
          <Slider
            label="Battery Buffer"
            value={params.batteryBuffer || 45}
            onChange={(v) => updateParam('batteryBuffer', v)}
            min={0} max={60} unit=" min"
            help="Eclipse duration in LEO: ~35 min max"
            disabled={hasSimulationStarted}
            sourceId="power"
          />
          <Slider
            label="Battery Density"
            value={params.batteryDensity || 300}
            onChange={(v) => updateParam('batteryDensity', v)}
            min={150} max={400} unit=" Wh/kg"
            help="Li-ion: 250, Solid-state: 350+"
            disabled={hasSimulationStarted}
            sourceId="power"
          />
          <Slider
            label="Battery Cost"
            value={params.batteryCost || 120}
            onChange={(v) => updateParam('batteryCost', v)}
            min={50} max={300} unit=" $/kWh"
            help="Space-rated cells are 2-3x ground cost"
            disabled={hasSimulationStarted}
            sourceId="power"
          />
          <Slider
            label="Structural Scaling Exponent"
            value={params.structuralPenaltyExponent ?? 1.2}
            onChange={(v) => updateParam('structuralPenaltyExponent', v)}
            min={1.0} max={1.5} step={0.05}
            help="Mass penalty for large arrays. 1.0 = linear, 1.2 = 20% superlinear penalty, 1.5 = severe penalty"
            disabled={hasSimulationStarted}
          />
          <Slider
            label="Structural Penalty Threshold"
            value={params.structuralThresholdKW ?? 50}
            onChange={(v) => updateParam('structuralThresholdKW', v)}
            min={20} max={200} step={10} unit=" kW"
            help="Power level where structural penalty kicks in"
            disabled={hasSimulationStarted}
          />
          
          <div style={styles.resultBox}>
            <LiveValue label="Battery Mass" value={(results.batteryMass_kg || 0).toFixed(0)} unit=" kg" sourceId="power" />
            <LiveValue label="10yr Power" value={(results.degradationAfter10yr * 100).toFixed(0)} unit="%" sourceId="power" />
            {results.solarPenaltyPercent !== undefined && (
              <LiveValue 
                label="Solar Penalty" 
                value={`${results.solarPenaltyPercent.toFixed(1)}%`} 
                sourceId="power"
              />
            )}
            {results.radiatorPenaltyPercent !== undefined && (
              <LiveValue 
                label="Radiator Penalty" 
                value={`${results.radiatorPenaltyPercent.toFixed(1)}%`} 
                sourceId="power"
              />
            )}
          </div>
          
          <ShowMathSection sectionId="power" title="Power / Solar" />
        </Section>
      </div>

      {/* Final Status */}
      <div style={{ 
        marginTop: '20px', 
        textAlign: 'center',
        padding: '16px',
        borderRadius: '8px',
        background: results.allSystemsOK 
          ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.15), rgba(16, 185, 129, 0.05))' 
          : 'linear-gradient(135deg, rgba(239, 68, 68, 0.15), rgba(239, 68, 68, 0.05))',
        border: `1px solid ${results.allSystemsOK ? 'rgba(16, 185, 129, 0.3)' : 'rgba(239, 68, 68, 0.3)'}`,
        position: 'relative',
        zIndex: 1,
      }}>
        <span style={{ 
          color: results.allSystemsOK ? '#10b981' : '#ef4444', 
          fontSize: '12px', 
          fontWeight: 600,
          letterSpacing: '2px',
          textTransform: 'uppercase',
        }}>
          {results.allSystemsOK 
            ? '◆ All Constraints Satisfied — Physics Checks Out'
            : '▲ Constraint Violated — Adjust Parameters'
          }
        </span>
      </div>
    </div>
  );
};

export default PhysicsSandbox;
