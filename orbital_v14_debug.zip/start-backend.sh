#!/bin/bash
# Start backend server with auto-reload
cd "$(dirname "$0")/backend"
exec ./start.sh

