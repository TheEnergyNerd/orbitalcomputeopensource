/**
 * Launch Arc Animation (Temporal Bezier)
 * Launches are animated bezier arcs over time, not static splines
 */

"use client";

import { useRef, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import { Vector3, CatmullRomCurve3, CubicBezierCurve3 } from "three";
import { Line } from "@react-three/drei";
import { useOrbitalUnitsStore } from "../store/orbitalUnitsStore";
import { useOrbitSim, type Satellite } from "../state/orbitStore";
import { latLonAltToXYZ } from "../lib/three/coordinateUtils";
import { LAUNCH_SITES } from "./LaunchSites";
import { 
  generateOrbitalState,
  getRandomInclination,
  calculateOrbitalPosition
} from "../lib/orbitSim/orbitalMechanics";

// Shell distribution types (deploymentSchedule was removed)
type ShellDistribution = {
  shell: "LEO-1" | "LEO-2" | "LEO-3";
  altitude: number;
};

function assignSatelliteToShell(index: number, total: number): ShellDistribution {
  // Simple distribution: 40% LEO-1, 35% LEO-2, 25% LEO-3
  const ratio = index / total;
  if (ratio < 0.4) {
    return { shell: "LEO-1", altitude: 400 };
  } else if (ratio < 0.75) {
    return { shell: "LEO-2", altitude: 600 };
  } else {
    return { shell: "LEO-3", altitude: 800 };
  }
}

function getAltitudeForShell(shell: ShellDistribution): number {
  return shell.altitude;
}

interface LaunchArc {
  id: string;
  launchSite: { lat: number; lon: number };
  targetShell: ShellDistribution;
  insertionPoint: Vector3;
  progress: number; // 0 to 1
  duration: number; // seconds
  startTime: number; // timestamp
  satsPerLaunch: number;
  curve: CatmullRomCurve3;
  completed: boolean;
}

const LAUNCH_SITES_LIST = [
  { lat: 28.5623, lon: -80.5774, name: "Cape Canaveral" }, // SLC-40
  { lat: 25.9971, lon: -97.1554, name: "Boca Chica" }, // SpaceX Starbase
  { lat: 5.2397, lon: -52.7686, name: "Kourou" }, // Guiana Space Centre
  { lat: 13.7333, lon: 80.2500, name: "India" }, // Sriharikota
  { lat: 39.5426, lon: 121.4558, name: "China" }, // Jiuquan
];

export function LaunchAnimationV2() {
  const launchesRef = useRef<Map<string, LaunchArc>>(new Map());
  const lastDeployedUnitsRef = useRef<Set<string>>(new Set());

  // Detect new deployments and create launch arcs
  useEffect(() => {
    const unsubscribe = useOrbitalUnitsStore.subscribe((state) => {
      const deployedUnits = state.units.filter(u => u.status === "deployed" && u.deployedAt);
      const currentDeployedIds = new Set(deployedUnits.map(u => u.id));
      
      const newDeployments = deployedUnits.filter(u => !lastDeployedUnitsRef.current.has(u.id));
      
      if (newDeployments.length > 0) {
        newDeployments.forEach((unit) => {
          if (unit.type === "leo_pod") {
            // Assign to shell based on deployment schedule
            const shell = assignSatelliteToShell(
              launchesRef.current.size,
              deployedUnits.length
            );
            
            // Pick launch site: Orange arcs (LEO-2) should come from Texas (Boca Chica)
            let launchSite;
            if (shell.shell === "LEO-2") {
              // Orange arcs come from Texas (Boca Chica, index 1)
              launchSite = LAUNCH_SITES_LIST[1]; // Boca Chica, Texas
            } else {
              // Other shells use random selection
              const launchSiteIndex = unit.id.charCodeAt(0) % LAUNCH_SITES_LIST.length;
              launchSite = LAUNCH_SITES_LIST[launchSiteIndex];
            }
            
            const altitude = getAltitudeForShell(shell);
            
            // Target insertion point (random position in shell)
            const targetLat = launchSite.lat + (Math.random() - 0.5) * 30;
            const targetLon = launchSite.lon + (Math.random() - 0.5) * 60;
            const [toX, toY, toZ] = latLonAltToXYZ(targetLat, targetLon, altitude);
            const insertionPoint = new Vector3(toX, toY, toZ);
            
            // Launch site position
            const [fromX, fromY, fromZ] = latLonAltToXYZ(launchSite.lat, launchSite.lon, 0);
            const from = new Vector3(fromX, fromY, fromZ);
            
            // Mid-arc point (high above Earth)
            const midPoint = from.clone().add(insertionPoint).multiplyScalar(0.5);
            const normal = from.clone().cross(insertionPoint).normalize();
            const arcHeight = 0.5; // Higher arc
            const midArc = midPoint.clone().add(normal.multiplyScalar(arcHeight));
            
            // Create bezier curve
            const curve = new CatmullRomCurve3([from, midArc, insertionPoint]);
            
            const launchDuration = 4 + Math.random() * 2; // 4-6 seconds
            const currentTime = useOrbitSim.getState().simTime;
            
            launchesRef.current.set(unit.id, {
              id: unit.id,
              launchSite,
              targetShell: shell,
              insertionPoint,
              progress: 0,
              duration: launchDuration,
              startTime: currentTime,
              satsPerLaunch: 60, // Starship capacity
              curve,
              completed: false,
            });
          }
        });
      }
      
      lastDeployedUnitsRef.current = currentDeployedIds;
    });
    
    return () => unsubscribe();
  }, []);

  // Animate launches and spawn satellites
  useFrame((state, delta) => {
    const { simPaused, simSpeed, simTime } = useOrbitSim.getState();
    if (simPaused) return;
    
    const effectiveDelta = delta * simSpeed;
    
    for (const [launchId, launch] of Array.from(launchesRef.current.entries())) {
      // Update progress
      const elapsed = simTime - launch.startTime;
      launch.progress = Math.min(1, elapsed / launch.duration);
      
      // Check if launch completed
      if (launch.progress >= 1 && !launch.completed) {
        launch.completed = true;
        
        // Spawn satellites at insertion point
        // Note: This will be handled by OrbitalDataSync when it detects the deployment
        // We just mark the launch as completed here
        
        // Remove completed launch
        launchesRef.current.delete(launchId);
      }
    }
  });

  // Render launch arcs
  return (
    <>
      {Array.from(launchesRef.current.values()).map((launch) => {
        if (launch.progress <= 0) return null;
        
        // Generate trail points
        const numPoints = 30;
        const trailPoints: [number, number, number][] = [];
        
        for (let i = 0; i <= numPoints; i++) {
          const t = (i / numPoints) * launch.progress;
          const point = launch.curve.getPoint(t);
          trailPoints.push([point.x, point.y, point.z]);
        }
        
        // Current position
        const currentPos = launch.curve.getPoint(launch.progress);
        
        // Arc color based on target shell
        const shellColors = {
          "LEO-1": "#4a90e2", // Blue
          "LEO-2": "#f5a623", // Orange
          "LEO-3": "#bd10e0", // Purple
        };
        const arcColor = shellColors[launch.targetShell.shell] || "#ff6600";
        
        // Arc thickness based on payload mass (satsPerLaunch)
        const arcThickness = 4 + (launch.satsPerLaunch / 60) * 4; // 4-8 based on capacity
        
        return (
          <group key={launch.id}>
            {/* Launch trail arc */}
            {trailPoints.length > 1 && (
              <Line
                points={trailPoints}
                color={arcColor}
                lineWidth={arcThickness}
                transparent
                opacity={0.9}
              />
            )}
            
            {/* Launch vehicle (cone) */}
            <mesh position={currentPos}>
              <coneGeometry args={[0.1, 0.3, 12]} />
              <meshStandardMaterial
                color={arcColor}
                emissive={arcColor}
                emissiveIntensity={5.0}
                depthWrite={true}
                depthTest={true}
              />
            </mesh>
            
            {/* Explosion ring on insertion */}
            {launch.progress >= 0.95 && (
              <mesh position={launch.insertionPoint}>
                <ringGeometry args={[0.15, 0.2, 32]} />
                <meshStandardMaterial
                  color="#ffff00"
                  emissive="#ffff00"
                  emissiveIntensity={3.0}
                  transparent
                  opacity={1 - launch.progress}
                />
              </mesh>
            )}
          </group>
        );
      })}
    </>
  );
}

