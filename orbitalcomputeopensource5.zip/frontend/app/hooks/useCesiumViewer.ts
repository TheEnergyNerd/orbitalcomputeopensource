// Hook stubbed out - Cesium removed, using Three.js OrbitalScene instead

export function useCesiumViewer() {
  return { current: null };
}

export function getGlobalViewer() {
  return null;
}

export function getSafeMode() {
  return false;
}
