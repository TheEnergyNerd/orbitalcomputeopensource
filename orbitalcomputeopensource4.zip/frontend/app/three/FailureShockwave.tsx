"use client";

/**
 * FailureShockwave Component
 * NOTE: SimState.events is string[], not structured event objects
 * This component is stubbed out until events are restructured
 */
export function FailureShockwave() {
  return null;
}
