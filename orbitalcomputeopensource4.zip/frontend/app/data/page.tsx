"use client";

import ConstraintsRiskView from "../components/constraints/ConstraintsRiskView";

export default function DataPage() {
  return (
    <div>
      <ConstraintsRiskView />
    </div>
  );
}

